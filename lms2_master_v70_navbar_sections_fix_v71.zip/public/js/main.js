document.addEventListener('DOMContentLoaded', () => {
  const csrfMeta = document.querySelector('meta[name="csrf-token"]');
  const csrfToken = csrfMeta ? csrfMeta.getAttribute('content') : '';
  if (csrfToken) {
    document.querySelectorAll('form[method="POST"], form[method="post"], form:not([method])').forEach((form) => {
      let input = form.querySelector('input[name="_csrf"]');
      if (!input) {
        input = document.createElement('input');
        input.type = 'hidden';
        input.name = '_csrf';
        form.appendChild(input);
      }
      input.value = csrfToken;
    });
  }

  const loadingMask = document.getElementById('globalLoadingMask');
  const loadingText = document.getElementById('globalLoadingText');

  function showLoading(message) {
    if (!loadingMask) return;
    if (loadingText) loadingText.textContent = message || 'Processing…';
    loadingMask.classList.add('active');
    loadingMask.setAttribute('aria-hidden', 'false');
  }

  function hideLoading() {
    if (!loadingMask) return;
    loadingMask.classList.remove('active');
    loadingMask.setAttribute('aria-hidden', 'true');
    if (loadingText) loadingText.textContent = 'Processing…';
  }

  function resetButtons() {
    document.querySelectorAll('button[type="submit"], input[type="submit"]').forEach((submitter) => {
      if (submitter.dataset.originalText) {
        if (submitter.tagName === 'BUTTON') submitter.innerHTML = submitter.dataset.originalText;
        else submitter.value = submitter.dataset.originalText;
      }
      submitter.disabled = false;
      submitter.removeAttribute('aria-busy');
    });
  }

  function clearBusyState() {
    hideLoading();
    resetButtons();
  }

  clearBusyState();
  window.addEventListener('pageshow', clearBusyState);
  window.addEventListener('popstate', clearBusyState);
  window.addEventListener('pagehide', hideLoading);
  window.addEventListener('focus', hideLoading);
  window.addEventListener('error', hideLoading);
  window.addEventListener('unhandledrejection', hideLoading);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') hideLoading();
  });

  const logoutForm = document.querySelector('form[action="/auth/logout"]');
  if (logoutForm) {
    logoutForm.addEventListener('submit', (e) => {
      const ok = confirm('Do you want to logout?');
      if (!ok) {
        e.preventDefault();
        clearBusyState();
      }
    });
  }

  const storageKey = `scroll:${window.location.pathname}${window.location.search}`;
  const savedScroll = window.sessionStorage.getItem(storageKey);
  if (savedScroll) {
    window.requestAnimationFrame(() => {
      window.scrollTo({ top: Number(savedScroll), behavior: 'auto' });
      window.sessionStorage.removeItem(storageKey);
    });
  }

  document.querySelectorAll('form.persist-scroll-form').forEach((form) => {
    form.addEventListener('submit', () => {
      window.sessionStorage.setItem(storageKey, String(window.scrollY || window.pageYOffset || 0));
    });
  });

  document.querySelectorAll('a[data-preserve-scroll="true"]').forEach((link) => {
    link.addEventListener('click', () => {
      window.sessionStorage.setItem(storageKey, String(window.scrollY || window.pageYOffset || 0));
    });
  });

  document.querySelectorAll('form').forEach((form) => {
    form.addEventListener('submit', (event) => {
      if (!form.checkValidity()) {
        clearBusyState();
        return;
      }
      const submitter = form.querySelector('button[type="submit"], input[type="submit"]');
      if (submitter && !submitter.dataset.keepEnabled) {
        const message = submitter.dataset.loadingText || form.dataset.loadingText || 'Processing…';
        submitter.disabled = true;
        submitter.setAttribute('aria-busy', 'true');
        if (submitter.tagName === 'BUTTON') {
          submitter.dataset.originalText = submitter.innerHTML;
          submitter.innerHTML = message;
        } else {
          submitter.dataset.originalText = submitter.value;
          submitter.value = message;
        }
        showLoading(message);
      }
    });
  });
});
