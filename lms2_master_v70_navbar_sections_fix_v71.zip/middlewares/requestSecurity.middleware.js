const { logSecurityEvent } = require('../utils/auditLogger');

function containsSuspiciousMongoKeys(value, seen = new WeakSet()) {
  if (!value || typeof value !== 'object') return false;
  if (seen.has(value)) return false;
  seen.add(value);

  if (Array.isArray(value)) {
    return value.some((item) => containsSuspiciousMongoKeys(item, seen));
  }

  return Object.entries(value).some(([key, child]) => {
    if (key.startsWith('$') || key.includes('.')) return true;
    return containsSuspiciousMongoKeys(child, seen);
  });
}

function rejectSuspiciousMongoPayload(req, res, next) {
  const hasSuspiciousKey = [req.body, req.query, req.params].some((part) => containsSuspiciousMongoKeys(part));
  if (!hasSuspiciousKey) return next();

  logSecurityEvent(req, 'NOSQL_INJECTION_BLOCKED', {
    message: 'Request payload contained unsafe Mongo-style operator keys.',
  });

  if (req.xhr || req.headers.accept?.includes('application/json')) {
    return res.status(400).json({
      success: false,
      message: 'Your request contains an invalid field. Please refresh the page and try again.',
    });
  }

  return res.status(400).render('error', {
    title: 'Invalid Request',
    status: 400,
    message: 'Your request contains an invalid field. Please go back, refresh the page, and try again.',
    requestId: req.requestId || null,
    stack: null,
  });
}

module.exports = {
  rejectSuspiciousMongoPayload,
};
