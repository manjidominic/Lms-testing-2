
const crypto = require('crypto');

module.exports = function requestContext(req, res, next) {
  req.requestId = req.headers['x-request-id'] || crypto.randomUUID();
  res.locals.requestId = req.requestId;
  next();
};
