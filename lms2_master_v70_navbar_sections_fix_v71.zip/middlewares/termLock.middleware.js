/**
 * Term Lock middleware
 *
 * When the active term is "closed" (Term.isResultOpen === false), teachers
 * must not be able to enter or modify scores.
 *
 * Owner/Super Admin can still view pages, but score-saving endpoints are blocked.
 */

module.exports = function requireTermOpenForScores(req, res, next) {
  try {
    // attachAcademicContext sets req.termDoc
    const term = req.termDoc;

    // If we don't have a term context yet, don't block here.
    if (!term) return next();

    if (term.isResultOpen === false) {
      const err = new Error(`Term is locked: ${term.name}. Score entry is closed.`);
      err.statusCode = 403;

      // If HTML request, render your standard error page.
      // Otherwise fall back to JSON.
      const accept = String(req.headers.accept || '');
      if (accept.includes('text/html')) {
        return res.status(403).render('error', {
          status: 403,
          message: err.message,
        });
      }

      return res.status(403).json({ message: err.message });
    }

    next();
  } catch (e) {
    next(e);
  }
};
