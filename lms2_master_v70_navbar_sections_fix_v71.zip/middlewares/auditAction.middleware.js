const { logAudit } = require('../utils/auditLogger');

function auditAction(action, detailBuilder) {
  return function auditActionMiddleware(req, res, next) {
    res.on('finish', () => {
      if (res.statusCode >= 500) return;
      if (res.statusCode < 200 || res.statusCode >= 400) return;
      try {
        const details = typeof detailBuilder === 'function' ? (detailBuilder(req, res) || {}) : {};
        logAudit(req, action, { ...details, statusCode: res.statusCode });
      } catch (err) {
        console.error('Failed to emit audit action:', err.message);
      }
    });
    next();
  };
}

module.exports = { auditAction };
