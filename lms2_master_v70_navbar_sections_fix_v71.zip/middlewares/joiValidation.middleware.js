const Joi = require('joi');
const AppError = require('../utils/AppError');

function normalizeJoiDetails(details = []) {
  return details.map((item) => ({
    field: Array.isArray(item.path) ? item.path.join('.') : String(item.path || ''),
    message: item.message.replace(/"/g, ''),
  }));
}

function buildMessage(details = [], fallback) {
  return details[0]?.message?.replace(/"/g, '') || fallback;
}

function respondValidationFailure(req, res, details, options = {}) {
  const statusCode = options.statusCode || 422;
  const message = buildMessage(details, options.message || 'Please check your input and try again.');
  const errors = normalizeJoiDetails(details);

  if (typeof options.onError === 'function') {
    return options.onError({ req, res, details: errors, statusCode, message });
  }

  if (req.xhr || req.headers.accept?.includes('application/json')) {
    return res.status(statusCode).json({
      success: false,
      message,
      errors,
    });
  }

  return res.status(statusCode).render('error', {
    title: 'Validation Error',
    status: statusCode,
    message,
    requestId: req.requestId || null,
    stack: null,
  });
}

function applyValidatedValue(req, source, value) {
  if (value && typeof value === 'object') {
    req[source] = value;
  }
}

function validateSource(source, schema, options = {}) {
  if (!['body', 'query', 'params'].includes(source)) {
    throw new AppError(`Unsupported validation source: ${source}`, 500, { expose: false });
  }

  return (req, res, next) => {
    const payload = req[source] || {};
    const result = schema.validate(payload, {
      abortEarly: false,
      allowUnknown: options.allowUnknown !== false,
      stripUnknown: options.stripUnknown !== false,
      convert: options.convert !== false,
      errors: { wrap: { label: false } },
    });

    if (result.error) {
      return Promise.resolve(respondValidationFailure(req, res, result.error.details, options)).catch(next);
    }

    applyValidatedValue(req, source, result.value);
    return next();
  };
}

module.exports = {
  Joi,
  validateBody: (schema, options) => validateSource('body', schema, options),
  validateQuery: (schema, options) => validateSource('query', schema, options),
  validateParams: (schema, options) => validateSource('params', schema, options),
};
