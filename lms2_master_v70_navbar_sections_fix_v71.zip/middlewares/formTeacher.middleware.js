const FormTeacherAssignment = require('../models/FormTeacherAssignment');

/**
 * If user is form_teacher, only allow promotion actions for the class they control.
 * Owner/Admin are allowed for all classes.
 */
exports.requireFormTeacherForClass = async (req, res, next) => {
  try {
    const role = String(req.session?.account?.role || '').toLowerCase();
    // These routes are for teachers acting as form-teachers.
    // Allow owner/admin bypass (handled in requireRole), otherwise enforce assignment for teacher/form_teacher.
    if (role !== 'form_teacher' && role !== 'teacher') return next();

    const schoolId = req.schoolId;
    const teacherId = req.session?.account?.teacher;
    const classId = req.params.classId;
    const academicYear = req.session?.currentAcademicYear;

    if (!academicYear) {
      return res.status(400).render('error', {
        title: 'Academic Year not set',
        status: 400,
        message: 'No active academic year for this school. Ask admin to set it under Academic Years.',
      });
    }

    if (!teacherId) {
      const err = new Error('Form teacher profile not linked to account.');
      err.statusCode = 403;
      throw err;
    }

    const ok = await FormTeacherAssignment.findOne({
      school: schoolId,
      teacher: teacherId,
      class: classId,
      academicYear,
    }).populate('section').populate('class').select('_id class section teacher academicYear');

    if (!ok) {
      return res.status(403).render('error', {
        title: 'Forbidden',
        status: 403,
        message: 'You are not the form teacher for this class.',
      });
    }

    req.formTeacherAssignment = ok;
    next();
  } catch (err) {
    next(err);
  }
};
