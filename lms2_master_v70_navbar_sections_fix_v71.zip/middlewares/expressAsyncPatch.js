
const express = require('express');

if (!express.__lmsAsyncPatched) {
  const methods = ['use', 'all', 'get', 'post', 'put', 'patch', 'delete'];

  function wrapHandler(handler) {
    if (!handler || typeof handler !== 'function') return handler;
    if (handler.__lmsWrappedAsync) return handler;
    const wrapped = function wrappedHandler(req, res, next) {
      try {
        const result = handler.call(this, req, res, next);
        if (result && typeof result.then === 'function') {
          result.catch(next);
        }
        return result;
      } catch (err) {
        return next(err);
      }
    };
    wrapped.__lmsWrappedAsync = true;
    return wrapped;
  }

  function wrapArgs(args) {
    return args.map((arg) => {
      if (Array.isArray(arg)) return wrapArgs(arg);
      return wrapHandler(arg);
    });
  }

  function patchPrototype(proto) {
    methods.forEach((method) => {
      const original = proto[method];
      if (typeof original !== 'function' || original.__lmsPatched) return;
      proto[method] = function patchedMethod(...args) {
        return original.apply(this, wrapArgs(args));
      };
      proto[method].__lmsPatched = true;
    });
  }

  patchPrototype(express.application);
  patchPrototype(express.Router && express.Router.prototype);
  express.__lmsAsyncPatched = true;
}

module.exports = express;
