const School = require('../models/School');
const Subscription = require('../models/Subscription');
const { addMonths, isWithin } = require('../utils/subscription.util');

// Commercial gate:
// - TRIAL (<= trialEnd): allow
// - ACTIVE (<= currentPeriodEnd): allow
// - otherwise: block for non-owner
module.exports = async function requireActiveSubscription(req, res, next) {
  try {
    const account = req.session?.account;
    const role = String(account?.role || '').toLowerCase();

    // ✅ Owner is never blocked by subscription.
    if (role === 'owner') return next();

    const schoolId = req.schoolId;
    if (!schoolId) {
      return res.status(401).render('error', {
        title: 'Unauthorized',
        status: 401,
        message: 'School context missing. Please login again.',
      });
    }

    const school = await School.findById(schoolId).select('isActive subscription createdAt name');
    if (!school) {
      return res.status(404).render('error', {
        title: 'Not Found',
        status: 404,
        message: 'School not found.',
      });
    }

    if (school.isActive === false) {
      return res.status(403).render('subscription/expired', {
        title: 'School Disabled',
        message: 'This school has been disabled. Contact the platform owner.',
        school,
        subscription: null,
      });
    }

    // Ensure subscription exists (for older DBs)
    let sub = null;
    if (school.subscription) {
      sub = await Subscription.findById(school.subscription);
    }

    if (!sub) {
      const base = school.createdAt ? new Date(school.createdAt) : new Date();
      const trialStart = base;
      const trialEnd = addMonths(base, 4);

      sub = await Subscription.create({
        school: school._id,
        status: 'TRIAL',
        trialStart,
        trialEnd,
      });
      school.subscription = sub._id;
      await school.save();
    }

    const now = new Date();

    const status = String(sub.status || '').toUpperCase();
    const isTrialValid = status === 'TRIAL' && isWithin(now, sub.trialEnd);
    const isActiveValid = status === 'ACTIVE' && isWithin(now, sub.currentPeriodEnd);

    if (isTrialValid || isActiveValid) {
      res.locals.subscription = sub;
      return next();
    }

    // Mark as expired if needed
    if (status === 'TRIAL' || status === 'ACTIVE') {
      sub.status = 'EXPIRED';
      sub.lockedReason = status === 'TRIAL' ? 'Trial expired' : 'Subscription expired';
      await sub.save();
    }

    return res.status(403).render('subscription/expired', {
      title: 'Subscription Required',
      message:
        sub.status === 'EXPIRED'
          ? 'This school subscription has expired. Please contact the school owner to renew.'
          : 'This school subscription is not active. Please contact the school owner.',
      school,
      subscription: sub,
    });
  } catch (err) {
    next(err);
  }
};
