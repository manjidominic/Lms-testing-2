const AcademicYear = require('../models/AcademicYear');
const Term = require('../models/Term');
const School = require('../models/School');
const ClassModel = require('../models/class');
const seedSchoolClasses = require('../utils/seedSchoolClasses.util');

async function ensureTermsForAcademicYear(schoolId, academicYearId) {
  const termCount = await Term.countDocuments({ school: schoolId, academicYear: academicYearId });
  if (termCount === 0) {
    const hasAnyActiveTerm = await Term.exists({ school: schoolId, isActive: true });
    await Term.insertMany([
      { school: schoolId, academicYear: academicYearId, name: 'First Term', isActive: !hasAnyActiveTerm, isResultOpen: true },
      { school: schoolId, academicYear: academicYearId, name: 'Second Term', isActive: false, isResultOpen: true },
      { school: schoolId, academicYear: academicYearId, name: 'Third Term', isActive: false, isResultOpen: true },
    ]);
  }
}

async function getActiveAcademicYearAndTerm(schoolId) {
  const year = await AcademicYear.findOne({ school: schoolId, isActive: true });
  if (!year) return { year: null, term: null };

  await ensureTermsForAcademicYear(schoolId, year._id);

  let term = await Term.findOne({ school: schoolId, academicYear: year._id, isActive: true });
  if (!term) {
    await Term.updateMany({ school: schoolId }, { $set: { isActive: false } });
    term = await Term.findOneAndUpdate(
      { school: schoolId, academicYear: year._id, name: 'First Term' },
      { $set: { isActive: true } },
      { new: true }
    );
  }

  return { year, term };
}

/**
 * Attaches the "current" academic context to each request:
 * - req.academicYearDoc / req.termDoc
 * - req.session.currentAcademicYear (string e.g. 2025/2026)
 * - req.session.currentTerm (string e.g. First Term)
 * - res.locals.currentAcademicYear / currentTerm for EJS
 *
 * This makes the whole LMS consistent: every feature uses the same active session & term.
 */
module.exports = async function attachAcademicContext(req, res, next) {
  try {
    const schoolId = req.schoolId;
    if (!schoolId) return next();

    // ----
    // Safety net: if a school has NO classes (common when switching zip versions
    // or creating schools before seeding existed), seed them automatically.
    // This prevents empty dropdowns for Register Student / Assignments, etc.
    // ----
    const hasAnyClass = await ClassModel.exists({ school: schoolId });
    if (!hasAnyClass) {
      const school = await School.findById(schoolId).select('phases');
      if (school && Array.isArray(school.phases) && school.phases.length) {
        try {
          await seedSchoolClasses({ schoolId, phases: school.phases });
        } catch (e) {
          // Ignore duplicate insert errors; this is a best-effort safeguard.
        }
      }
    }

    const { year, term } = await getActiveAcademicYearAndTerm(schoolId);

    req.academicYearDoc = year || null;
    req.termDoc = term || null;

    if (year && term) {
      req.session.currentAcademicYear = year.name;
      req.session.currentTerm = term.name;
      res.locals.currentAcademicYear = year.name;
      res.locals.currentTerm = term.name;
    } else {
      req.session.currentAcademicYear = null;
      req.session.currentTerm = null;
      res.locals.currentAcademicYear = null;
      res.locals.currentTerm = null;
    }

    res.locals.academicYearDoc = year || null;
    res.locals.termDoc = term || null;
    res.locals.academicContextMissing = !(year && term);

    next();
  } catch (err) {
    next(err);
  }
};
