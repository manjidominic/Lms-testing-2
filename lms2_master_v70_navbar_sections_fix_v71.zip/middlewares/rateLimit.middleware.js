const buckets = new Map();

function prune(now) {
  for (const [key, entry] of buckets.entries()) {
    if (entry.resetAt <= now) buckets.delete(key);
  }
}

function defaultKey(req) {
  const school = String(req.session?.account?.school || req.body?.schoolCode || '').trim().toLowerCase();
  const user = String(req.session?.account?.id || req.session?.account?.username || req.body?.identifier || req.body?.email || '').trim().toLowerCase();
  return `${req.ip}:${school}:${user}:${req.originalUrl}`;
}

function buildRateLimiter({ windowMs = 15 * 60 * 1000, max = 10, keyFn, message = 'Too many requests. Please try again later.' } = {}) {
  return function rateLimiter(req, res, next) {
    const now = Date.now();
    prune(now);
    const key = typeof keyFn === 'function' ? keyFn(req) : defaultKey(req);
    const entry = buckets.get(key) || { count: 0, resetAt: now + windowMs };
    if (entry.resetAt <= now) {
      entry.count = 0;
      entry.resetAt = now + windowMs;
    }
    entry.count += 1;
    buckets.set(key, entry);

    res.set('X-RateLimit-Limit', String(max));
    res.set('X-RateLimit-Remaining', String(Math.max(0, max - entry.count)));
    res.set('X-RateLimit-Reset', String(Math.ceil(entry.resetAt / 1000)));

    if (entry.count > max) {
      const err = new Error(message);
      err.statusCode = 429;
      err.code = 'RATE_LIMITED';
      return next(err);
    }
    return next();
  };
}

const limiters = {
  auth: buildRateLimiter({
    windowMs: 15 * 60 * 1000,
    max: 10,
    message: 'Too many authentication attempts. Please wait and try again later.',
  }),
  sensitiveWrite: buildRateLimiter({
    windowMs: 10 * 60 * 1000,
    max: 25,
    message: 'Too many changes were submitted too quickly. Please wait a moment and try again.',
  }),
  imports: buildRateLimiter({
    windowMs: 10 * 60 * 1000,
    max: 8,
    message: 'Too many import requests were sent. Please wait and try again.',
  }),
  publishing: buildRateLimiter({
    windowMs: 10 * 60 * 1000,
    max: 8,
    message: 'Too many result-processing requests were sent. Please wait and try again.',
  }),
  backupRestore: buildRateLimiter({
    windowMs: 30 * 60 * 1000,
    max: 5,
    message: 'Backup or restore requests are limited. Please wait before trying again.',
  }),
};

module.exports = { buildRateLimiter, limiters };
