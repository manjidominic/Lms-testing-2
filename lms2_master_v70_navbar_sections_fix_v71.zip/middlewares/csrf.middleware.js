const crypto = require('crypto');

function ensureCsrfToken(req) {
  if (!req.session) return null;
  if (!req.session.csrfToken) {
    req.session.csrfToken = crypto.randomBytes(24).toString('hex');
  }
  return req.session.csrfToken;
}

function attachCsrfToken(req, res, next) {
  const token = ensureCsrfToken(req);
  res.locals.csrfToken = token;
  next();
}

function verifyCsrf(req, res, next) {
  const method = String(req.method || 'GET').toUpperCase();
  if ([ 'GET', 'HEAD', 'OPTIONS' ].includes(method)) return next();
  const sessionToken = ensureCsrfToken(req);
  const provided = req.body?._csrf || req.get('x-csrf-token') || req.get('x-xsrf-token');
  if (!sessionToken || !provided || provided !== sessionToken) {
    const err = new Error('Your session security token is missing or invalid. Please refresh the page and try again.');
    err.statusCode = 403;
    return next(err);
  }
  return next();
}

module.exports = { attachCsrfToken, verifyCsrf };
