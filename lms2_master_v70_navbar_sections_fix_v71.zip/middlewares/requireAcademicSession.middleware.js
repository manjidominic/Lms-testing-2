module.exports = function requireAcademicSession(req, res, next) {
  const academicYear = req.session?.currentAcademicYear;
  const term = req.session?.currentTerm;

  if (!academicYear || !term) {
    return res.status(400).render('error', {
      title: 'Academic Session Required',
      status: 400,
      message: 'No active academic session and term are set for this school. Go to Academic Years, create or activate a session, then activate a term before continuing.',
    });
  }

  next();
};
