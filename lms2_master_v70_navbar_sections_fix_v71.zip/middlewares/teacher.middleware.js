const TeachingAssignment = require('../models/TeachingAssignment');

exports.requireTeachingAssignment = async (req, res, next) => {
  try {
    const schoolId = req.schoolId;
    const teacherId = req.session?.account?._id;

    const { classId, subjectId } = req.params;

    const found = await TeachingAssignment.findOne({
      school: schoolId,
      teacher: teacherId,
      class: classId,
      subject: subjectId,
    }).select('_id');

    if (!found) {
      return res.status(403).render('error', {
        title: 'Forbidden',
        status: 403,
        message: 'You are not assigned to this subject for this class.',
      });
    }

    next();
  } catch (err) {
    next(err);
  }
};