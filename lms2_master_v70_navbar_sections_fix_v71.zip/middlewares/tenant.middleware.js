// middlewares/tenant.middleware.js
exports.attachSchool = (req, res, next) => {
  const account = req.session?.account;
  const role = String(account?.role || '').toLowerCase();

  // ✅ Platform owner: can manage ANY school, but must select an active school context first.
  if (role === 'owner') {
    const activeSchoolId = req.session?.activeSchoolId;
    if (!activeSchoolId) {
      // Owner must pick a school before visiting school-scoped pages.
      return res.redirect('/owner/schools');
    }
    req.schoolId = activeSchoolId;
    return next();
  }

  // Everyone else: must have a school linked to their account
  const schoolId = account?.school;
  if (!schoolId) {
    const err = new Error('School context missing. Please login again.');
    err.statusCode = 401;
    throw err;
  }
  req.schoolId = schoolId;
  next();
};
exports.attachScopePhase = (req, res, next) => {
  try {
    const account = req.session?.account;

    // Not logged in
    if (!account) {
      const wantsJson = req.headers.accept?.includes('application/json');
      if (wantsJson) {
        return res.status(401).json({ success: false, message: 'Not authenticated' });
      }
      return res.redirect('/auth/login');
    }

    // ✅ Owner and parent accounts should not be controlled by scopePhase.
    // Optional: owner can filter by adding ?phase=Primary|Secondary.
    if (['owner', 'parent'].includes(String(account.role).toLowerCase())) {
      const qp = String(req.query?.phase || '').trim();
      const allowed = new Set(['Primary', 'Secondary']);
      req.scopePhase = allowed.has(qp) ? qp : null;
      res.locals.scopePhase = req.scopePhase;
      return next();
    }

    const sp = String(account.scopePhase || '').trim();
    const allowed = new Set(['Primary', 'Secondary']);

    if (!allowed.has(sp)) {
      return res.status(403).render('error', {
        title: 'Forbidden',
        status: 403,
        message: 'Your account scopePhase is missing or invalid. Contact admin.',
      });
    }

    req.scopePhase = sp;
    res.locals.scopePhase = sp; // ✅ helpful in EJS
    next();
  } catch (err) {
    next(err);
  }
};