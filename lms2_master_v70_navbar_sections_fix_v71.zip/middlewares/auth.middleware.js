const { getEffectivePermissions, hasPermission } = require('../utils/permissions');
const { logSecurityEvent } = require('../utils/auditLogger');

exports.requireAuth = (req, res, next) => {
  if (!req.session || !req.session.account) {
    return res.redirect('/auth/login');
  }
  next();
};

function renderForbidden(req, res, message = 'You are not allowed to access this page') {
  logSecurityEvent(req, 'ACCESS_DENIED', { message });
  if (req.accepts('json') && !req.accepts('html')) {
    return res.status(403).json({ success: false, message });
  }
  return res.status(403).render('error', {
    title: 'Forbidden',
    status: 403,
    message,
    requestId: req.requestId || null,
    stack: null,
  });
}

exports.requireRole = (...roles) => {
  return (req, res, next) => {
    const role = String(req.session?.account?.role || '').toLowerCase();

    if (!role) {
      return renderForbidden(req, res);
    }

    if (role === 'owner') {
      return next();
    }

    const normalizedRoles = roles.map((item) => String(item || '').toLowerCase());
    if (!normalizedRoles.includes(role)) {
      return renderForbidden(req, res);
    }

    next();
  };
};

exports.requirePermission = (...permissions) => {
  return (req, res, next) => {
    const account = req.session?.account || null;
    if (!account?.role) {
      return renderForbidden(req, res);
    }

    if (String(account.role).toLowerCase() === 'owner') {
      return next();
    }

    const missing = permissions.find((permission) => !hasPermission(account, permission));
    if (missing) {
      return renderForbidden(req, res, 'You do not have permission to perform this action.');
    }

    return next();
  };
};

exports.attachPermissions = (req, res, next) => {
  const account = req.session?.account || null;
  res.locals.effectivePermissions = account ? getEffectivePermissions(account) : [];
  res.locals.hasPermission = (permission) => hasPermission(account || {}, permission);
  next();
};
