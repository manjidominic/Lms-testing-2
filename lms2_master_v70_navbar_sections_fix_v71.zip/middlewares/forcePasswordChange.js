module.exports = function forcePasswordChange(req, res, next) {
  const openPaths = new Set([
    '/auth/login',
    '/auth/logout',
    '/auth/change-password',
    '/auth/register-owner',
    '/auth/setup-owner',
  ]);

  const currentPath = typeof req.path === 'string' ? req.path : '';
  const account = req.session && req.session.account ? req.session.account : null;

  if (openPaths.has(currentPath)) return next();
  if (!account || typeof account !== 'object') return next();

  if (account.mustChangePassword === true) {
    return res.redirect('/auth/change-password');
  }

  return next();
};
