const fs = require('fs');
const path = require('path');
const AppError = require('../utils/AppError');

function writeErrorLog(entry) {
  try {
    const dir = path.join(__dirname, '..', 'storage', 'logs');
    fs.mkdirSync(dir, { recursive: true });
    fs.appendFileSync(path.join(dir, 'application-errors.log'), `${entry}
`, 'utf8');
  } catch (e) {
    console.error('Failed to write error log:', e.message);
  }
}

function isJsonRequest(req) {
  if (req.xhr) return true;
  const accept = String(req.headers.accept || '').toLowerCase();
  const contentType = String(req.headers['content-type'] || '').toLowerCase();
  return accept.includes('application/json') || contentType.includes('application/json');
}

function mapKnownError(err) {
  if (!err) {
    return new AppError('Something went wrong. Please try again.', 500, { expose: false });
  }

  if (err instanceof AppError) return err;

  if (err.userMessage || err.statusCode || err.status) {
    const statusCode = Number(err.statusCode || err.status || 500);
    return new AppError(err.userMessage || err.message || 'Something went wrong. Please try again.', statusCode, {
      expose: statusCode < 500,
      code: err.code || null,
    });
  }

  if (err.name === 'ValidationError') {
    const first = Object.values(err.errors || {})[0];
    return new AppError(first?.message || 'Please review the highlighted information and try again.', 400, { code: 'VALIDATION_ERROR' });
  }

  if (err.name === 'CastError') {
    return new AppError('The selected record is not valid. Please refresh and try again.', 400, { code: 'INVALID_ID' });
  }

  if (err.code === 11000) {
    const key = Object.keys(err.keyPattern || err.keyValue || {})[0] || 'record';
    return new AppError(`${key} already exists. Please use a different value.`, 409, { code: 'DUPLICATE_KEY' });
  }

  if (/csrf|token/i.test(String(err.message || '')) && Number(err.statusCode || err.status) === 403) {
    return new AppError('Your session security check failed. Refresh the page and try again.', 403, { code: 'CSRF_FAILED' });
  }

  if (/ECONNREFUSED|MongoServerSelectionError|failed to connect/i.test(String(err.message || ''))) {
    return new AppError('The system could not connect to the database. Please contact the administrator.', 503, {
      expose: true,
      code: 'DATABASE_UNAVAILABLE',
    });
  }

  return new AppError('Something went wrong while processing your request. Please try again.', 500, {
    expose: false,
    code: err.code || null,
  });
}

module.exports = function errorMiddleware(err, req, res, next) {
  const normalized = mapKnownError(err);
  const status = Number(normalized.statusCode || 500);
  const isProd = process.env.NODE_ENV === 'production';
  const message = normalized.expose ? normalized.userMessage || normalized.message : 'Something went wrong while processing your request.';
  const stack = isProd ? null : (err && err.stack ? err.stack : normalized.stack || null);

  const logEntry = JSON.stringify({
    at: new Date().toISOString(),
    requestId: req.requestId || null,
    method: req.method,
    url: req.originalUrl,
    school: req.school?._id || req.session?.account?.school || null,
    accountId: req.session?.account?.id || null,
    role: req.session?.account?.role || null,
    status,
    publicMessage: message,
    rawMessage: err?.message || normalized.message,
    code: normalized.code || null,
    stack: err?.stack || normalized.stack || null,
  });

  console.error(err);
  writeErrorLog(logEntry);

  if (isJsonRequest(req)) {
    return res.status(status).json({
      success: false,
      message,
      requestId: req.requestId || null,
      code: normalized.code || null,
    });
  }

  const view = status === 403 ? 'errors/403' : status === 404 ? 'errors/404' : 'errors/500';
  return res.status(status).render(view, {
    title: status === 404 ? 'Page Not Found' : status === 403 ? 'Access Denied' : 'Something Went Wrong',
    message,
    status,
    requestId: req.requestId || null,
    stack,
  });
};
