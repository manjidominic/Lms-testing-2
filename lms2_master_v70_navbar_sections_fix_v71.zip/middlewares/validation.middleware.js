const mongoose = require('mongoose');

function isEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || '').trim());
}

function normalizeString(value) {
  return String(value == null ? '' : value).trim();
}

function addError(errors, field, message) {
  errors.push({ field, message });
}

function renderValidationError(req, res, errors, statusCode = 422) {
  if (typeof res.locals.validationRenderer === 'function') {
    return res.locals.validationRenderer(errors, statusCode);
  }

  if (req.accepts('html')) {
    return res.status(statusCode).render('error', {
      title: 'Validation Error',
      status: statusCode,
      message: errors[0]?.message || 'Please check your input and try again.',
    });
  }

  return res.status(statusCode).json({
    message: 'Validation failed',
    errors,
  });
}

function validate(rules = []) {
  return (req, res, next) => {
    const errors = [];

    for (const rule of rules) {
      rule(req, errors);
    }

    if (errors.length) {
      return renderValidationError(req, res, errors);
    }

    return next();
  };
}

function bodyString(field, label, opts = {}) {
  return (req, errors) => {
    const value = normalizeString(req.body?.[field]);
    req.body[field] = value;

    if (opts.required && !value) {
      addError(errors, field, `${label} is required.`);
      return;
    }
    if (!value) return;
    if (opts.min && value.length < opts.min) addError(errors, field, `${label} must be at least ${opts.min} characters.`);
    if (opts.max && value.length > opts.max) addError(errors, field, `${label} must be at most ${opts.max} characters.`);
    if (opts.pattern && !opts.pattern.test(value)) addError(errors, field, opts.patternMessage || `${label} is invalid.`);
  };
}


function bodyUrl(field, label, opts = {}) {
  return (req, errors) => {
    const value = normalizeString(req.body?.[field]);
    req.body[field] = value;
    if (opts.required && !value) {
      addError(errors, field, `${label} is required.`);
      return;
    }
    if (!value) return;
    try {
      const parsed = new URL(value);
      if (!['http:', 'https:'].includes(parsed.protocol)) {
        addError(errors, field, `${label} must start with http:// or https://`);
        return;
      }
      if (opts.imageOnly) {
        const pathname = parsed.pathname.toLowerCase();
        const ok = ['.png', '.jpg', '.jpeg', '.svg', '.webp', '.ico'].some((ext) => pathname.endsWith(ext));
        if (!ok) {
          addError(errors, field, `${label} must point to a PNG, JPG, SVG, WEBP, or ICO image.`);
        }
      }
    } catch (err) {
      addError(errors, field, `${label} must be a valid URL.`);
    }
    if (opts.max && value.length > opts.max) addError(errors, field, `${label} must be at most ${opts.max} characters.`);
  };
}

function bodyEmail(field, label, opts = {}) {
  return (req, errors) => {
    const value = normalizeString(req.body?.[field]).toLowerCase();
    req.body[field] = value;
    if (opts.required && !value) {
      addError(errors, field, `${label} is required.`);
      return;
    }
    if (!value) return;
    if (!isEmail(value)) addError(errors, field, `${label} must be a valid email address.`);
    if (opts.max && value.length > opts.max) addError(errors, field, `${label} must be at most ${opts.max} characters.`);
  };
}

function bodyEnum(field, label, allowed, opts = {}) {
  return (req, errors) => {
    const value = normalizeString(req.body?.[field]);
    req.body[field] = value;
    if (opts.required && !value) {
      addError(errors, field, `${label} is required.`);
      return;
    }
    if (!value) return;
    if (!allowed.includes(value)) addError(errors, field, `${label} is invalid.`);
  };
}

function bodyObjectId(field, label, opts = {}) {
  return (req, errors) => {
    const value = normalizeString(req.body?.[field]);
    req.body[field] = value;
    if (opts.required && !value) {
      addError(errors, field, `${label} is required.`);
      return;
    }
    if (!value) return;
    if (!mongoose.Types.ObjectId.isValid(value)) addError(errors, field, `${label} is invalid.`);
  };
}

function paramObjectId(field, label, opts = {}) {
  return (req, errors) => {
    const value = normalizeString(req.params?.[field]);
    req.params[field] = value;
    if (opts.required !== false && !value) {
      addError(errors, field, `${label} is required.`);
      return;
    }
    if (!value) return;
    if (!mongoose.Types.ObjectId.isValid(value)) addError(errors, field, `${label} is invalid.`);
  };
}

function queryString(field, label, opts = {}) {
  return (req, errors) => {
    const value = normalizeString(req.query?.[field]);
    req.query[field] = value;
    if (opts.required && !value) {
      addError(errors, field, `${label} is required.`);
      return;
    }
    if (!value) return;
    if (opts.max && value.length > opts.max) addError(errors, field, `${label} must be at most ${opts.max} characters.`);
  };
}

function checkboxBoolean(field) {
  return (req) => {
    req.body[field] = req.body?.[field] === 'on' || req.body?.[field] === true || req.body?.[field] === 'true';
  };
}

function matchFields(fieldA, fieldB, message) {
  return (req, errors) => {
    if (String(req.body?.[fieldA] || '') !== String(req.body?.[fieldB] || '')) {
      addError(errors, fieldB, message);
    }
  };
}

function decisionsMap(field) {
  const allowed = ['PROMOTE', 'REPEAT', 'WITHDRAW', 'GRADUATE', 'COMPLETE_PRIMARY'];
  return (req, errors) => {
    const raw = req.body?.[field];
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return;
    for (const [studentId, decision] of Object.entries(raw)) {
      if (!mongoose.Types.ObjectId.isValid(studentId)) {
        addError(errors, field, 'A selected student id is invalid.');
        continue;
      }
      if (!allowed.includes(String(decision || '').trim().toUpperCase())) {
        addError(errors, field, 'A promotion decision is invalid.');
      }
    }
  };
}

function announcementLink(field) {
  return (req, errors) => {
    const value = normalizeString(req.body?.[field]);
    req.body[field] = value;
    if (!value) return;
    if (!(value.startsWith('/') || /^https?:\/\//i.test(value))) {
      addError(errors, field, 'Announcement link must start with / or http(s)://');
    }
  };
}

function dateBody(field, label, opts = {}) {
  return (req, errors) => {
    const value = normalizeString(req.body?.[field]);
    req.body[field] = value;
    if (opts.required && !value) {
      addError(errors, field, `${label} is required.`);
      return;
    }
    if (!value) return;
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) addError(errors, field, `${label} is invalid.`);
  };
}

module.exports = {
  validate,
  bodyString,
  bodyUrl,
  bodyEmail,
  bodyEnum,
  bodyObjectId,
  paramObjectId,
  queryString,
  checkboxBoolean,
  matchFields,
  decisionsMap,
  announcementLink,
  dateBody,
};
