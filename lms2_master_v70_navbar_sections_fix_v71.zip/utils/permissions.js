const PERMISSIONS = {
  MANAGE_STUDENTS: 'CAN_MANAGE_STUDENTS',
  MANAGE_PARENTS: 'CAN_MANAGE_PARENTS',
  MANAGE_SUBJECTS: 'CAN_MANAGE_SUBJECTS',
  MANAGE_TEACHERS: 'CAN_MANAGE_TEACHERS',
  MANAGE_ASSIGNMENTS: 'CAN_MANAGE_ASSIGNMENTS',
  MANAGE_ASSESSMENT_POLICY: 'CAN_MANAGE_ASSESSMENT_POLICY',
  MANAGE_ACADEMIC_SETTINGS: 'CAN_MANAGE_ACADEMIC_SETTINGS',
  APPROVE_RESULTS: 'CAN_APPROVE_RESULTS',
  PUBLISH_RESULTS: 'CAN_PUBLISH_RESULTS',
  VIEW_ANALYTICS: 'CAN_VIEW_ANALYTICS',
  MANAGE_PROMOTION: 'CAN_MANAGE_PROMOTION',
  SEND_ANNOUNCEMENTS: 'CAN_SEND_ANNOUNCEMENTS',
  MANAGE_CALENDAR: 'CAN_MANAGE_CALENDAR',
  RESET_PASSWORDS: 'CAN_RESET_PASSWORDS',
  VIEW_SECURITY_AUDIT: 'CAN_VIEW_SECURITY_AUDIT',
  MANAGE_REPORT_CARD_SETTINGS: 'CAN_MANAGE_REPORT_CARD_SETTINGS',
  MANAGE_RESULT_TEMPLATES: 'CAN_MANAGE_RESULT_TEMPLATES',
  MANAGE_BACKUPS: 'CAN_MANAGE_BACKUPS',
  MANAGE_PERMISSIONS: 'CAN_MANAGE_PERMISSIONS',
};

const PERMISSION_LABELS = {
  [PERMISSIONS.MANAGE_STUDENTS]: 'Manage students',
  [PERMISSIONS.MANAGE_PARENTS]: 'Manage parents',
  [PERMISSIONS.MANAGE_SUBJECTS]: 'Manage subjects',
  [PERMISSIONS.MANAGE_TEACHERS]: 'Manage teachers & form teachers',
  [PERMISSIONS.MANAGE_ASSIGNMENTS]: 'Manage class/subject assignments',
  [PERMISSIONS.MANAGE_ASSESSMENT_POLICY]: 'Manage assessment policy',
  [PERMISSIONS.MANAGE_ACADEMIC_SETTINGS]: 'Manage terms, academic years & setup',
  [PERMISSIONS.APPROVE_RESULTS]: 'Approve results',
  [PERMISSIONS.PUBLISH_RESULTS]: 'Publish results',
  [PERMISSIONS.VIEW_ANALYTICS]: 'View analytics',
  [PERMISSIONS.MANAGE_PROMOTION]: 'Manage promotion',
  [PERMISSIONS.SEND_ANNOUNCEMENTS]: 'Send announcements',
  [PERMISSIONS.MANAGE_CALENDAR]: 'Manage calendar events',
  [PERMISSIONS.RESET_PASSWORDS]: 'Reset passwords',
  [PERMISSIONS.VIEW_SECURITY_AUDIT]: 'View security audit',
  [PERMISSIONS.MANAGE_REPORT_CARD_SETTINGS]: 'Manage report card settings',
  [PERMISSIONS.MANAGE_RESULT_TEMPLATES]: 'Manage result templates',
  [PERMISSIONS.MANAGE_BACKUPS]: 'Manage backup/export/restore',
  [PERMISSIONS.MANAGE_PERMISSIONS]: 'Manage account permissions',
};

const PERMISSION_GROUPS = [
  {
    title: 'Students & Parents',
    keys: [PERMISSIONS.MANAGE_STUDENTS, PERMISSIONS.MANAGE_PARENTS],
  },
  {
    title: 'Academics Setup',
    keys: [
      PERMISSIONS.MANAGE_SUBJECTS,
      PERMISSIONS.MANAGE_TEACHERS,
      PERMISSIONS.MANAGE_ASSIGNMENTS,
      PERMISSIONS.MANAGE_ASSESSMENT_POLICY,
      PERMISSIONS.MANAGE_ACADEMIC_SETTINGS,
      PERMISSIONS.MANAGE_REPORT_CARD_SETTINGS,
      PERMISSIONS.MANAGE_RESULT_TEMPLATES,
    ],
  },
  {
    title: 'Results & Promotion',
    keys: [
      PERMISSIONS.APPROVE_RESULTS,
      PERMISSIONS.PUBLISH_RESULTS,
      PERMISSIONS.VIEW_ANALYTICS,
      PERMISSIONS.MANAGE_PROMOTION,
    ],
  },
  {
    title: 'Security & Communication',
    keys: [
      PERMISSIONS.SEND_ANNOUNCEMENTS,
      PERMISSIONS.MANAGE_CALENDAR,
      PERMISSIONS.RESET_PASSWORDS,
      PERMISSIONS.VIEW_SECURITY_AUDIT,
      PERMISSIONS.MANAGE_BACKUPS,
      PERMISSIONS.MANAGE_PERMISSIONS,
    ],
  },
];

const DEFAULT_ROLE_PERMISSIONS = {
  owner: Object.values(PERMISSIONS),
  admin: Object.values(PERMISSIONS),
  staff: [
    PERMISSIONS.MANAGE_STUDENTS,
    PERMISSIONS.MANAGE_PARENTS,
    PERMISSIONS.MANAGE_SUBJECTS,
    PERMISSIONS.SEND_ANNOUNCEMENTS,
    PERMISSIONS.MANAGE_CALENDAR,
  ],
  teacher: [],
  form_teacher: [],
  student: [],
  parent: [],
};

function normalizePermissions(list) {
  const allowed = new Set(Object.values(PERMISSIONS));
  const source = Array.isArray(list) ? list : (list ? [list] : []);
  return Array.from(new Set(source
    .map((item) => String(item || '').trim())
    .filter((item) => allowed.has(item))));
}

function getDefaultPermissionsForRole(role) {
  return [...(DEFAULT_ROLE_PERMISSIONS[String(role || '').toLowerCase()] || [])];
}

function getEffectivePermissions(accountLike = {}) {
  const role = String(accountLike.role || '').toLowerCase();
  if (role === 'owner') return getDefaultPermissionsForRole('owner');
  if (accountLike.useCustomPermissions) {
    return normalizePermissions(accountLike.permissions);
  }
  return getDefaultPermissionsForRole(role);
}

function hasPermission(accountLike = {}, permission) {
  if (String(accountLike.role || '').toLowerCase() === 'owner') return true;
  return getEffectivePermissions(accountLike).includes(permission);
}

module.exports = {
  PERMISSIONS,
  PERMISSION_LABELS,
  PERMISSION_GROUPS,
  DEFAULT_ROLE_PERMISSIONS,
  normalizePermissions,
  getDefaultPermissionsForRole,
  getEffectivePermissions,
  hasPermission,
};
