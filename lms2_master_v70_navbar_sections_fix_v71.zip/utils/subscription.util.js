function addMonths(date, months) {
  const d = new Date(date);
  const m = d.getMonth();
  d.setMonth(m + Number(months || 0));
  return d;
}

function isWithin(date, end) {
  if (!end) return false;
  return new Date(date).getTime() <= new Date(end).getTime();
}

module.exports = {
  addMonths,
  isWithin,
};
