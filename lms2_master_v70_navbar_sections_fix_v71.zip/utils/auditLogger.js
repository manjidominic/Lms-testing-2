const fs = require('fs');
const path = require('path');

function appendLine(fileName, entry) {
  try {
    const dir = path.join(__dirname, '..', 'storage', 'logs');
    fs.mkdirSync(dir, { recursive: true });
    fs.appendFileSync(path.join(dir, fileName), `${JSON.stringify(entry)}
`, 'utf8');
  } catch (err) {
    console.error('Failed to write audit log:', err.message);
  }
}

function buildBaseEntry(req) {
  return {
    at: new Date().toISOString(),
    requestId: req.requestId || null,
    method: req.method,
    path: req.originalUrl || req.url,
    accountId: req.session?.account?.id || null,
    username: req.session?.account?.username || null,
    role: req.session?.account?.role || null,
    schoolId: req.session?.account?.school || req.schoolId || null,
    ip: req.ip || null,
  };
}

function logAudit(req, action, details = {}) {
  appendLine('audit.log', {
    ...buildBaseEntry(req),
    action,
    details,
  });
}

function logSecurityEvent(req, action, details = {}) {
  appendLine('security-events.log', {
    ...buildBaseEntry(req),
    action,
    details,
  });
}

module.exports = { logAudit, logSecurityEvent };
