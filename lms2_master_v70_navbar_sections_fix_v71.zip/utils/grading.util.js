// utils/grading.util.js

// Total = CA1 + CA2 + Test1 + Test2 + Exam (missing fields count as 0)
function mongoTotalExpr() {
  return {
    $add: [
      { $ifNull: ['$ca1', 0] },
      { $ifNull: ['$ca2', 0] },
      { $ifNull: ['$test1', 0] },
      { $ifNull: ['$test2', 0] },
      { $ifNull: ['$exam', 0] },
    ],
  };
}

// Grade rule (Nigeria-style common bands, editable later)
function mongoGradeExpr(totalExpr) {
  return {
    $switch: {
      branches: [
        { case: { $gte: [totalExpr, 70] }, then: 'A' },
        { case: { $gte: [totalExpr, 60] }, then: 'B' },
        { case: { $gte: [totalExpr, 50] }, then: 'C' },
        { case: { $gte: [totalExpr, 45] }, then: 'D' },
        { case: { $gte: [totalExpr, 40] }, then: 'E' },
      ],
      default: 'F',
    },
  };
}

module.exports = {
  mongoTotalExpr,
  mongoGradeExpr,
};