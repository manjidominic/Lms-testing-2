class AppError extends Error {
  constructor(message, statusCode = 400, options = {}) {
    super(message);
    this.name = 'AppError';
    this.statusCode = Number(statusCode) || 500;
    this.status = String(this.statusCode).startsWith('4') ? 'fail' : 'error';
    this.isOperational = true;
    this.expose = options.expose !== undefined ? Boolean(options.expose) : this.statusCode < 500;
    this.code = options.code || null;
    this.userMessage = options.userMessage || message;
    Error.captureStackTrace(this, this.constructor);
  }
}

module.exports = AppError;
