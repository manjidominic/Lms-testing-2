const { cleanString } = require('./validation.util');

function formatPersonName({ surname, middleName, firstName, fallbackName = '' }) {
  const cleanSurname = cleanString(surname);
  const cleanMiddleName = cleanString(middleName);
  const cleanFirstName = cleanString(firstName);
  const cleanFallbackName = cleanString(fallbackName);

  if (cleanSurname || cleanMiddleName || cleanFirstName) {
    return [cleanSurname, cleanMiddleName, cleanFirstName].filter(Boolean).join(' ');
  }

  return cleanFallbackName;
}

function requireSplitNames({ surname, firstName, middleName, fallbackName = '', label = 'Name' }) {
  const fullName = formatPersonName({ surname, middleName, firstName, fallbackName });
  if (!fullName) {
    const err = new Error(`${label} is required.`);
    err.statusCode = 400;
    throw err;
  }

  const cleanSurname = cleanString(surname);
  const cleanFirstName = cleanString(firstName);
  const cleanMiddleName = cleanString(middleName);

  if (!cleanSurname) {
    const err = new Error('Surname is required.');
    err.statusCode = 400;
    throw err;
  }

  if (!cleanFirstName) {
    const err = new Error('First name is required.');
    err.statusCode = 400;
    throw err;
  }

  return {
    surname: cleanSurname,
    middleName: cleanMiddleName,
    firstName: cleanFirstName,
    fullName,
  };
}

module.exports = {
  formatPersonName,
  requireSplitNames,
};
