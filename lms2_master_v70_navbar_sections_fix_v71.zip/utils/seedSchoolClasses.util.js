const ClassModel = require('../models/class');
const SectionModel = require('../models/section');

const DEFAULT_SSS_SECTIONS = ['SCIENCE', 'ART', 'COMMERCIAL'];
const PRIMARY_CLASS_LIBRARY = [
  { name: 'Creche', order: -2, isFinal: false },
  { name: 'Nursery 1', order: -1, isFinal: false },
  { name: 'Nursery 2', order: 0, isFinal: false },
  { name: 'Primary 1', order: 1, isFinal: false },
  { name: 'Primary 2', order: 2, isFinal: false },
  { name: 'Primary 3', order: 3, isFinal: false },
  { name: 'Primary 4', order: 4, isFinal: false },
  { name: 'Primary 5', order: 5, isFinal: false },
  { name: 'Primary 6', order: 6, isFinal: true },
];

module.exports = async function seedSchoolClasses({ schoolId, phases, primaryClassNames = null }) {
  const phasesArr = Array.isArray(phases) ? phases : [];
  const docs = [];

  if (phasesArr.includes('Primary')) {
    const chosenPrimary = Array.isArray(primaryClassNames) && primaryClassNames.length
      ? PRIMARY_CLASS_LIBRARY.filter((item) => primaryClassNames.includes(item.name))
      : PRIMARY_CLASS_LIBRARY.filter((item) => item.name.startsWith('Primary'));

    for (const item of chosenPrimary) {
      docs.push({
        school: schoolId,
        phase: 'Primary',
        name: item.name,
        level: 'Primary',
        order: item.order,
        isFinal: item.isFinal,
        allowTracks: false,
      });
    }
  }

  if (phasesArr.includes('Secondary')) {
    for (let i = 1; i <= 3; i++) {
      docs.push({ school: schoolId, phase: 'Secondary', name: `JSS ${i}`, level: 'JSS', order: i, isFinal: i === 3, allowTracks: false });
    }
    for (let i = 1; i <= 3; i++) {
      docs.push({ school: schoolId, phase: 'Secondary', name: `SSS ${i}`, level: 'SSS', order: i, isFinal: i === 3, allowTracks: true });
    }
  }

  if (!docs.length) return { inserted: 0 };

  let insertedClasses = [];
  try {
    insertedClasses = await ClassModel.insertMany(docs, { ordered: false });
  } catch (e) {
    if (e && e.insertedDocs) insertedClasses = e.insertedDocs;
    else if (e && e.code !== 11000) throw e;
  }

  const sssClasses = insertedClasses.filter((item) => item.level === 'SSS');
  if (sssClasses.length) {
    const sectionDocs = [];
    for (const klass of sssClasses) {
      for (const name of DEFAULT_SSS_SECTIONS) {
        sectionDocs.push({ school: schoolId, phase: klass.phase, class: klass._id, name });
      }
    }
    try { await SectionModel.insertMany(sectionDocs, { ordered: false }); } catch (e) { if (!e || e.code !== 11000) throw e; }
  }

  return { inserted: docs.length };
};
