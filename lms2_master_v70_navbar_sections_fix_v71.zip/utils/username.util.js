const School = require('../models/School');
const Account = require('../models/Account');

function normalizeNamePart(value = '') {
  return String(value || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '');
}

function deriveSchoolInitials(school = {}) {
  const code = normalizeNamePart(school.code || '');
  if (code) return code;

  const words = String(school.name || '')
    .trim()
    .split(/\s+/)
    .filter(Boolean)
    .map((w) => w.replace(/[^A-Za-z0-9]/g, ''))
    .filter(Boolean);

  if (!words.length) return 'sch';
  return words.map((w) => w[0].toLowerCase()).join('');
}

async function getSchoolIdentifier(schoolId) {
  const school = await School.findById(schoolId).select('name code');
  if (!school) {
    const err = new Error('School not found');
    err.statusCode = 404;
    throw err;
  }

  return deriveSchoolInitials(school);
}

async function usernameExists(username, schoolId) {
  const exists = await Account.findOne({
    school: schoolId,
    $or: [
      { username },
      { email: username },
    ],
  }).select('_id');

  return Boolean(exists);
}

async function generateScopedUsername({ schoolId, surname, firstName, year }) {
  const surnameInitial = normalizeNamePart(String(surname || '').trim()).charAt(0);
  const normalizedFirstName = normalizeNamePart(firstName);
  const normalizedYear = String(year || '').trim();
  const schoolInitials = await getSchoolIdentifier(schoolId);

  if (!surnameInitial || !normalizedFirstName || !/^\d{4}$/.test(normalizedYear)) {
    const err = new Error('Unable to generate username from the provided data');
    err.statusCode = 400;
    throw err;
  }

  const baseTail = `${normalizedFirstName}${normalizedYear}${schoolInitials}`;
  let candidate = `${surnameInitial}${baseTail}`;

  if (!(await usernameExists(candidate, schoolId))) {
    return candidate;
  }

  for (let i = 1; i <= 9999; i += 1) {
    candidate = `${surnameInitial}${i}${baseTail}`;
    if (!(await usernameExists(candidate, schoolId))) {
      return candidate;
    }
  }

  const err = new Error('Unable to generate a unique username');
  err.statusCode = 500;
  throw err;
}

module.exports = {
  normalizeNamePart,
  deriveSchoolInitials,
  getSchoolIdentifier,
  generateScopedUsername,
};
