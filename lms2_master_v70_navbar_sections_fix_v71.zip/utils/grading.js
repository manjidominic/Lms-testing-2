const { mongoTotalExpr, mongoGradeExpr } = require('./grading.util');

function getGradeAndRemark(total = 0) {
  const n = Number(total) || 0;
  if (n >= 70) return { grade: 'A', remark: 'Excellent' };
  if (n >= 60) return { grade: 'B', remark: 'Very Good' };
  if (n >= 50) return { grade: 'C', remark: 'Good' };
  if (n >= 45) return { grade: 'D', remark: 'Fair' };
  if (n >= 40) return { grade: 'E', remark: 'Pass' };
  return { grade: 'F', remark: 'Fail' };
}

module.exports = {
  getGradeAndRemark,
  mongoTotalExpr,
  mongoGradeExpr,
};
