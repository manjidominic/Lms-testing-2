function cleanString(value) {
  return String(value ?? '').trim();
}

function validateYear(value, fieldName = 'Year', options = {}) {
  const raw = cleanString(value);
  const now = new Date();
  const minYear = Number.isInteger(options.minYear) ? options.minYear : 1900;
  const maxYear = Number.isInteger(options.maxYear) ? options.maxYear : now.getFullYear() + 10;

  if (!/^\d{4}$/.test(raw)) {
    const err = new Error(`${fieldName} must be a valid 4-digit year.`);
    err.statusCode = 400;
    throw err;
  }

  const year = Number(raw);
  if (year < minYear || year > maxYear) {
    const err = new Error(`${fieldName} must be between ${minYear} and ${maxYear}.`);
    err.statusCode = 400;
    throw err;
  }

  return String(year);
}

function normalizeNigerianPhone(value, fieldName = 'Phone number') {
  const raw = cleanString(value).replace(/\s+/g, '');

  if (!/^0\d{10}$/.test(raw)) {
    const err = new Error(`${fieldName} must be an 11-digit Nigerian phone number starting with 0.`);
    err.statusCode = 400;
    throw err;
  }

  return raw;
}

function validateDateString(value, fieldName = 'Date') {
  const raw = cleanString(value);
  if (!raw) return '';

  if (!/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
    const err = new Error(`${fieldName} must be in YYYY-MM-DD format.`);
    err.statusCode = 400;
    throw err;
  }

  const parsed = new Date(`${raw}T00:00:00.000Z`);
  if (Number.isNaN(parsed.getTime())) {
    const err = new Error(`${fieldName} is not a valid calendar date.`);
    err.statusCode = 400;
    throw err;
  }

  const [y, m, d] = raw.split('-').map(Number);
  if (
    parsed.getUTCFullYear() !== y ||
    parsed.getUTCMonth() + 1 !== m ||
    parsed.getUTCDate() !== d
  ) {
    const err = new Error(`${fieldName} is not a valid calendar date.`);
    err.statusCode = 400;
    throw err;
  }

  return raw;
}

module.exports = {
  cleanString,
  validateYear,
  normalizeNigerianPhone,
  validateDateString,
};
