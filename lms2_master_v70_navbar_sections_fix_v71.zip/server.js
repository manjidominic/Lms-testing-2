require('dotenv').config();

const helmet = require('helmet');
const mongoSanitize = require('express-mongo-sanitize');

const express = require('./middlewares/expressAsyncPatch');
const mongoose = require('mongoose');
const path = require('path');
const session = require('express-session');
const MongoStore = require('connect-mongo').default;
const expressLayouts = require('express-ejs-layouts');
const { logSecurityEvent } = require('./utils/auditLogger');
const { rejectSuspiciousMongoPayload } = require('./middlewares/requestSecurity.middleware');
const crypto = require('crypto');

const errorMiddleware = require('./middlewares/error.middleware');
const requestContext = require('./middlewares/requestContext.middleware');
const forcePasswordChange = require('./middlewares/forcePasswordChange');
const { requireAuth, requireRole } = require('./middlewares/auth.middleware');
const { attachSchool, attachScopePhase } = require('./middlewares/tenant.middleware');
const { attachCsrfToken, verifyCsrf } = require('./middlewares/csrf.middleware');
const attachAcademicContext = require('./middlewares/academicContext.middleware');
const requireActiveSubscription = require('./middlewares/subscription.middleware');
const requireAcademicSession = require('./middlewares/requireAcademicSession.middleware');
const notificationService = require('./services/notifications/notification.service');
const { startBackupScheduler } = require('./services/admin/backupAutomation.service');
const Account = require('./models/Account');
const School = require('./models/School');

const schoolRoutes = require('./routes/schools');
const promotionRoutes = require('./routes/promotion');
const teacherRoutes = require('./routes/teacher');

const app = express();

if (!process.env.MONGO_URI) {
  throw new Error('MONGO_URI is not defined. Set it in your .env file before starting the server.');
}

if (!process.env.SESSION_SECRET) {
  throw new Error('SESSION_SECRET is not defined. Set it in your .env file before starting the server.');
}

const sessionSecret = process.env.SESSION_SECRET;

app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(requestContext);
app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));
app.use(express.json({ limit: '15mb' }));
app.use(rejectSuspiciousMongoPayload);
app.use(mongoSanitize({
  onSanitize: ({ req, key }) => {
    logSecurityEvent(req, 'NOSQL_SANITIZE_TRIGGERED', { key });
  },
}));
app.use(expressLayouts);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.set('layout', 'layouts/main');
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  name: process.env.SESSION_COOKIE_NAME || 'lms.sid',
  secret: sessionSecret,
  resave: false,
  saveUninitialized: false,
  rolling: true,
  unset: 'destroy',
  proxy: process.env.NODE_ENV === 'production',
  store: MongoStore.create({
    mongoUrl: process.env.MONGO_URI,
    ttl: 60 * 60 * 2,
    autoRemove: 'native',
  }),
  cookie: {
    httpOnly: true,
    sameSite: process.env.NODE_ENV === 'production' ? 'lax' : 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 1000 * 60 * 60 * 2,
  },
}));
app.use(attachCsrfToken);
app.use(verifyCsrf);

app.use(async (req, res, next) => {
  res.locals.title = 'LMS Portal';
  res.locals.user = req.session?.account || null;
  res.locals.notificationUnreadCount = 0;
  res.locals.csrfToken = req.session?.csrfToken || null;
  res.locals.branding = { schoolName: 'LMS', initials: 'SL', logoUrl: '', faviconUrl: '', showLogo: true };
  try {
    if (req.session?.account?.id && req.session?.account?.role && req.session.account.role !== 'owner' && req.session.account.school) {
      res.locals.notificationUnreadCount = await notificationService.getUnreadCount({
        schoolId: req.session.account.school,
        accountId: req.session.account.id,
      });
      const school = await School.findById(req.session.account.school).select('name code reportCardSettings').lean();
      if (school) {
        const schoolName = String(school.name || 'LMS').trim();
        const initials = schoolName
          .split(/\s+/)
          .filter(Boolean)
          .slice(0, 2)
          .map((part) => part[0])
          .join('')
          .toUpperCase() || String(school.code || 'SL').slice(0, 2).toUpperCase();
        res.locals.branding = {
          schoolName,
          initials,
          logoUrl: school.reportCardSettings?.logoUrl || '',
          faviconUrl: school.reportCardSettings?.faviconUrl || '',
          showLogo: school.reportCardSettings?.showLogo !== false,
        };
      }
    }
  } catch (err) {
    res.locals.notificationUnreadCount = 0;
  }
  next();
});

app.use(forcePasswordChange);

app.get('/', async (req, res, next) => {
  try {
    if (req.session?.account) {
      const role = req.session.account.role;
      if (role === 'owner') return res.redirect('/owner/schools');
      if (role === 'student') return res.redirect('/student/dashboard');
      if (role === 'parent') return res.redirect('/parent/dashboard');
      if (role === 'teacher' || role === 'form_teacher') return res.redirect('/teacher/dashboard');
      return res.redirect('/dashboard');
    }
    const owner = await Account.findOne({ role: 'owner' }).lean();
    if (!owner) return res.redirect('/auth/setup-owner');
    return res.redirect('/auth/login');
  } catch (err) {
    return next(err);
  }
});

app.get('/favicon.ico', (req, res) => res.redirect('/favicon.svg'));
app.use('/auth', require('./routes/auth'));
app.use('/owner', requireAuth, requireRole('owner'), require('./routes/owner'));
app.use('/schools', requireAuth, requireRole('owner'), schoolRoutes);

app.use('/student/dashboard', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, requireRole('student'), require('./routes/student/dashboard'));
app.use('/student/results', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, requireAcademicSession, require('./routes/student/results'));

app.use('/parent', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, requireRole('parent'), require('./routes/parent'));

app.use('/teacher/dashboard', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, requireRole('teacher', 'form_teacher'), require('./routes/teacher/dashboard'));
app.use('/teacher/scoresheets', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, requireAcademicSession, requireRole('teacher', 'form_teacher'), require('./routes/teacher/scoresheets'));
app.use('/teacher/assignments', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, requireAcademicSession, requireRole('teacher', 'form_teacher'), teacherRoutes);

app.use('/notifications', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, require('./routes/notifications'));
app.use('/calendar', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, require('./routes/calendar'));

app.use('/admin/setup', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, require('./routes/admin/setup'));
app.get('/admin/permissions', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, (req, res) => res.redirect('/admin/setup/permissions'));
app.get('/admin/bulk-import', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, (req, res) => res.redirect('/admin/imports'));
app.use('/dashboard', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, requireRole('owner', 'admin'), require('./routes/dashboard'));
app.use('/students', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, requireRole('owner', 'admin', 'staff'), require('./routes/students'));
app.use('/sections', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, requireRole('owner', 'admin', 'staff'), require('./routes/sections'));
app.use('/admin/subjects', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, requireRole('owner', 'admin', 'staff'), require('./routes/subjects'));
app.use('/admin/teachers', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, requireRole('owner', 'admin'), require('./routes/teachers'));
app.use('/admin/assignments', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, requireAcademicSession, requireRole('owner', 'admin'), require('./routes/assignments'));
app.use('/admin/assessment-policy', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, requireAcademicSession, requireRole('owner', 'admin'), require('./routes/admin/assessment-policy'));
app.use('/admin/form-teachers', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, requireAcademicSession, requireRole('owner', 'admin'), require('./routes/admin/form-teachers'));
app.use('/admin/terms', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, requireRole('owner', 'admin'), require('./routes/terms'));
app.use('/admin/academic-years', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, requireRole('owner', 'admin'), require('./routes/academic-years'));
app.use('/admin/results', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, requireAcademicSession, requireRole('owner', 'admin'), require('./routes/admin/results'));
app.use('/form-teacher/results', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, requireAcademicSession, require('./routes/form-teacher/results'));
app.use('/promotion', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, requireAcademicSession, requireRole('owner', 'admin', 'form_teacher', 'teacher'), promotionRoutes);
app.use('/form-teacher/performance', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, requireAcademicSession, require('./routes/form-teacher/performance'));
app.use('/admin/parents', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, requireRole('owner','admin','staff'), require('./routes/admin/parents'));
app.use('/admin/imports', requireAuth, attachSchool, attachScopePhase, requireActiveSubscription, attachAcademicContext, requireRole('owner','admin','staff'), require('./routes/admin/imports'));

app.use((req, res, next) => {
  const err = new Error('The requested page could not be found.');
  err.statusCode = 404;
  err.expose = true;
  next(err);
});

app.use((err, req, res, next) => {
  if (err && err.statusCode === 403 && /token/i.test(String(err.message || ''))) {
    if (req.accepts('html')) {
      return res.status(403).render('errors/403', {
        title: 'Security Check Failed',
        message: err.message,
      });
    }
    return res.status(403).json({ message: err.message });
  }
  return next(err);
});

app.use(errorMiddleware);


function logFatalError(label, err) {
  const message = err && err.stack ? err.stack : String(err);
  console.error(`${label}:`, message);
}

process.on('unhandledRejection', (err) => {
  logFatalError('Unhandled Rejection', err);
  process.exit(1);
});

process.on('uncaughtException', (err) => {
  logFatalError('Uncaught Exception', err);
  process.exit(1);
});

async function start() {
  if (process.env.NODE_ENV === 'production' && /127\.0\.0\.1:27017|localhost:27017/i.test(String(process.env.MONGO_URI || ''))) {
    throw new Error('Production startup blocked: MONGO_URI cannot point to localhost.');
  }
  await mongoose.connect(process.env.MONGO_URI);
  console.log('MongoDB connected ✅');
  startBackupScheduler();
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
}

start().catch((err) => {
  console.error('Failed to start server:', err);
});
