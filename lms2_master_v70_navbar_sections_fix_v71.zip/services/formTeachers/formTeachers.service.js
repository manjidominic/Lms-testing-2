const FormTeacherAssignment = require('../../models/FormTeacherAssignment');
const Teacher = require('../../models/Teacher');
const ClassModel = require('../../models/class');
const Section = require('../../models/section');

const DEFAULT_SSS_SECTIONS = ['SCIENCE', 'ART', 'COMMERCIAL'];

async function ensureAutoSectionsForClass({ schoolId, classObj }) {
  if (!classObj || classObj.level !== 'SSS') return;
  const existing = await Section.find({ school: schoolId, class: classObj._id }).select('name').lean();
  const existingNames = new Set(existing.map((item) => String(item.name || '').trim().toUpperCase()));
  const docs = DEFAULT_SSS_SECTIONS.filter((name) => !existingNames.has(name)).map((name) => ({
    school: schoolId,
    phase: classObj.phase,
    class: classObj._id,
    name,
  }));
  if (docs.length) await Section.insertMany(docs, { ordered: false });
}

function ensureAcademicYearName(academicYear) {
  const name = String(academicYear || '').trim();
  if (!name) {
    const err = new Error('No active academic year set for this school. Set it under Academic Years.');
    err.statusCode = 400;
    throw err;
  }
  return name;
}


async function dropLegacyClassYearUniqueIndex() {
  try {
    const collection = FormTeacherAssignment.collection;
    const indexes = await collection.indexes();
    const legacy = indexes.find((idx) => idx && idx.name === 'school_1_class_1_academicYear_1');
    if (legacy) {
      await collection.dropIndex('school_1_class_1_academicYear_1');
    }
  } catch (err) {
    // ignore if index does not exist yet or collection has not been created
    if (!err || !String(err.message || '').includes('index not found')) {
      // swallow startup/index-state errors; assignment query will still use new compound key
    }
  }
}

exports.getPageData = async ({ schoolId, reqScopePhase, academicYear }) => {
  const yearName = ensureAcademicYearName(academicYear);
  const classFilter = { school: schoolId };
  const teacherFilter = { school: schoolId, status: 'Active' };

  if (reqScopePhase) {
    classFilter.phase = reqScopePhase;
    teacherFilter.phase = reqScopePhase;
  }

  const classes = await ClassModel.find(classFilter).sort({ phase: 1, level: 1, order: 1, name: 1 });
  for (const cls of classes) {
    await ensureAutoSectionsForClass({ schoolId, classObj: cls });
  }

  const [teachers, assignments, sections] = await Promise.all([
    Teacher.find(teacherFilter).sort({ fullName: 1 }).lean(),
    FormTeacherAssignment.find({ school: schoolId, academicYear: yearName })
      .populate('teacher', 'fullName phase')
      .populate('class', 'name level phase')
      .populate('section', 'name')
      .lean(),
    Section.find({ school: schoolId, class: { $in: classes.map((c) => c._id) } }).sort({ name: 1 }).lean(),
  ]);

  const scopedAssignments = reqScopePhase
    ? assignments.filter((a) => a.class?.phase === reqScopePhase)
    : assignments;

  const sectionsByClass = {};
  for (const section of sections) {
    const key = String(section.class);
    sectionsByClass[key] = sectionsByClass[key] || [];
    sectionsByClass[key].push(section);
  }

  const assignmentMap = new Map();
  for (const assignment of scopedAssignments) {
    const classId = String(assignment.class?._id || assignment.class || '');
    const sectionId = String(assignment.section?._id || assignment.section || 'whole');
    assignmentMap.set(`${classId}::${sectionId}`, assignment);
  }

  const slots = [];
  for (const klass of classes) {
    const classId = String(klass._id);
    const classSections = sectionsByClass[classId] || [];

    if (classSections.length) {
      for (const sec of classSections) {
        const key = `${classId}::${String(sec._id)}`;
        const currentAssignment = assignmentMap.get(key) || null;
        const availableTeachers = teachers;

        slots.push({
          key,
          classId: klass._id,
          className: klass.name,
          level: klass.level,
          phase: klass.phase,
          sectionId: sec._id,
          sectionName: sec.name,
          currentAssignment,
          availableTeachers,
        });
      }
    } else {
      const key = `${classId}::whole`;
      const currentAssignment = assignmentMap.get(key) || null;
      const availableTeachers = teachers;

      slots.push({
        key,
        classId: klass._id,
        className: klass.name,
        level: klass.level,
        phase: klass.phase,
        sectionId: null,
        sectionName: 'Whole Class',
        currentAssignment,
        availableTeachers,
      });
    }
  }

  return { classes, teachers, assignments: scopedAssignments, sectionsByClass, academicYear: yearName, slots };
};

exports.assignFormTeacher = async ({ schoolId, reqScopePhase, academicYear, teacherId, classId, sectionId = null }) => {
  const yearName = ensureAcademicYearName(academicYear);
  const [teacher, cls] = await Promise.all([
    Teacher.findOne({ _id: teacherId, school: schoolId }),
    ClassModel.findOne({ _id: classId, school: schoolId }),
  ]);

  if (!teacher) throw Object.assign(new Error('Teacher not found'), { statusCode: 404 });
  if (!cls) throw Object.assign(new Error('Class not found'), { statusCode: 404 });

  if (reqScopePhase) {
    if (teacher.phase !== reqScopePhase) throw Object.assign(new Error('Teacher is not in your scopePhase'), { statusCode: 403 });
    if (cls.phase !== reqScopePhase) throw Object.assign(new Error('Class is not in your scopePhase'), { statusCode: 403 });
  }

  if (teacher.phase !== cls.phase) {
    throw Object.assign(new Error('Teacher phase and Class phase must match.'), { statusCode: 400 });
  }

  await ensureAutoSectionsForClass({ schoolId, classObj: cls });
  await dropLegacyClassYearUniqueIndex();

  const classSections = await Section.find({ school: schoolId, class: cls._id }).select('_id name').lean();
  const classHasSections = classSections.length > 0;

  let resolvedSectionId = null;
  if (classHasSections) {
    if (!sectionId || sectionId === 'none') {
      throw Object.assign(new Error('This class has sections, so form teacher assignment must target a section.'), { statusCode: 400 });
    }
    const sec = await Section.findOne({ _id: sectionId, school: schoolId, class: cls._id });
    if (!sec) throw Object.assign(new Error('Section not found for this class.'), { statusCode: 404 });
    resolvedSectionId = sec._id;
  }

  await FormTeacherAssignment.findOneAndUpdate(
    { school: schoolId, class: cls._id, section: resolvedSectionId, academicYear: yearName },
    { $set: { teacher: teacher._id } },
    { upsert: true, new: true, setDefaultsOnInsert: true }
  );

  return { ok: true };
};

exports.removeAssignment = async ({ schoolId, assignmentId }) => {
  const deleted = await FormTeacherAssignment.findOneAndDelete({ _id: assignmentId, school: schoolId });
  if (!deleted) throw Object.assign(new Error('Form teacher assignment not found'), { statusCode: 404 });
  return { ok: true };
};

exports.isFormTeacherForClass = async ({ schoolId, teacherId, classId, academicYear, sectionId = null }) => {
  const year = ensureAcademicYearName(academicYear);
  const filter = {
    school: schoolId,
    teacher: teacherId,
    class: classId,
    academicYear: year,
  };
  if (sectionId !== undefined) filter.section = sectionId;
  const exists = await FormTeacherAssignment.findOne(filter).select('_id');
  return !!exists;
};
