const Notification = require('../../models/Notification');
const Account = require('../../models/Account');
const ClassModel = require('../../models/class');
const Subject = require('../../models/Subject');
const PublishedStudentResult = require('../../models/PublishedStudentResult');
const NotificationPreference = require('../../models/NotificationPreference');

function uniqueIds(values = []) {
  return [...new Set(values.filter(Boolean).map((value) => String(value)))];
}

function normalizePreferencePayload(payload = {}) {
  return {
    workflow: payload.workflow !== false,
    publication: payload.publication !== false,
    announcement: payload.announcement !== false,
    promotion: payload.promotion !== false,
    general: payload.general !== false,
  };
}

async function filterRecipientIdsByPreference({ schoolId, recipientAccountIds = [], category = 'general' }) {
  const ids = uniqueIds(recipientAccountIds);
  if (!schoolId || !ids.length) return [];
  const categoryKey = ['workflow', 'publication', 'announcement', 'promotion', 'general'].includes(String(category))
    ? String(category)
    : 'general';

  const preferenceDocs = await NotificationPreference.find({ school: schoolId, account: { $in: ids } })
    .select('account workflow publication announcement promotion general')
    .lean();
  const preferenceMap = new Map(preferenceDocs.map((doc) => [String(doc.account), doc]));

  return ids.filter((accountId) => {
    const pref = preferenceMap.get(String(accountId));
    if (!pref) return true;
    return pref[categoryKey] !== false;
  });
}

async function getPreferencesForAccount({ schoolId, accountId }) {
  if (!schoolId || !accountId) return normalizePreferencePayload();
  const doc = await NotificationPreference.findOne({ school: schoolId, account: accountId }).lean();
  return normalizePreferencePayload(doc || {});
}

async function updatePreferencesForAccount({ schoolId, accountId, preferences = {} }) {
  if (!schoolId || !accountId) return normalizePreferencePayload();
  const payload = normalizePreferencePayload(preferences);
  const updated = await NotificationPreference.findOneAndUpdate(
    { school: schoolId, account: accountId },
    { $set: payload, $setOnInsert: { school: schoolId, account: accountId } },
    { upsert: true, new: true, setDefaultsOnInsert: true }
  ).lean();
  return normalizePreferencePayload(updated || payload);
}

async function createForRecipients({ schoolId, recipientAccountIds = [], senderType = 'system', actorAccountId = null, category = 'general', title, message, link = '/notifications', meta = {} }) {
  const ids = await filterRecipientIdsByPreference({ schoolId, recipientAccountIds, category });
  if (!schoolId || !ids.length || !title || !message) return 0;
  const now = new Date();
  const broadcastKey = meta && meta.broadcastKey ? String(meta.broadcastKey) : null;
  const docs = ids.map((accountId) => ({
    school: schoolId,
    recipient: accountId,
    senderType,
    actorAccount: actorAccountId || null,
    category,
    title,
    message,
    link,
    meta: { ...meta, ...(broadcastKey ? { broadcastKey } : {}) },
    createdAt: now,
    updatedAt: now,
  }));
  await Notification.insertMany(docs, { ordered: false });
  return docs.length;
}

async function getUnreadCount({ schoolId, accountId }) {
  if (!schoolId || !accountId) return 0;
  return Notification.countDocuments({ school: schoolId, recipient: accountId, isRead: false });
}

async function listForAccount({ schoolId, accountId, limit = 30 }) {
  if (!schoolId || !accountId) return [];
  return Notification.find({ school: schoolId, recipient: accountId })
    .sort({ createdAt: -1 })
    .limit(Math.max(1, Math.min(Number(limit) || 30, 100)))
    .lean();
}

async function markOneRead({ schoolId, accountId, notificationId }) {
  if (!schoolId || !accountId || !notificationId) return null;
  return Notification.findOneAndUpdate(
    { _id: notificationId, school: schoolId, recipient: accountId },
    { $set: { isRead: true, readAt: new Date() } },
    { new: true }
  ).lean();
}

async function markAllRead({ schoolId, accountId }) {
  if (!schoolId || !accountId) return 0;
  const result = await Notification.updateMany(
    { school: schoolId, recipient: accountId, isRead: false },
    { $set: { isRead: true, readAt: new Date() } }
  );
  return result.modifiedCount || 0;
}

async function getAdminRecipients({ schoolId, scopePhase }) {
  const docs = await Account.find({ school: schoolId, role: { $in: ['admin', 'staff'] }, isActive: true, ...(scopePhase ? { scopePhase } : {}) })
    .select('_id')
    .lean();
  return docs.map((doc) => doc._id);
}

async function getFormTeacherRecipientsForClass({ schoolId, classId }) {
  const docs = await Account.find({ school: schoolId, role: 'form_teacher', isActive: true, teacher: { $exists: true, $ne: null } })
    .select('_id teacher')
    .lean();
  if (!docs.length) return [];
  const FormTeacherAssignment = require('../../models/FormTeacherAssignment');
  const assignments = await FormTeacherAssignment.find({ school: schoolId, class: classId, teacher: { $in: docs.map((d) => d.teacher).filter(Boolean) } })
    .select('teacher')
    .lean();
  const teacherIds = new Set(assignments.map((item) => String(item.teacher)));
  return docs.filter((doc) => teacherIds.has(String(doc.teacher))).map((doc) => doc._id);
}

async function notifySubjectSubmitted({ schoolId, scopePhase, actorAccountId, classId, subjectId }) {
  const [classDoc, subjectDoc, formTeacherRecipients, adminRecipients] = await Promise.all([
    ClassModel.findById(classId).select('name').lean(),
    Subject.findById(subjectId).select('name code').lean(),
    getFormTeacherRecipientsForClass({ schoolId, classId }),
    getAdminRecipients({ schoolId, scopePhase }),
  ]);
  const subjectName = subjectDoc?.code || subjectDoc?.name || 'Subject';
  const className = classDoc?.name || 'Class';
  await createForRecipients({
    schoolId,
    recipientAccountIds: [...formTeacherRecipients, ...adminRecipients],
    actorAccountId,
    category: 'workflow',
    title: 'Subject result submitted',
    message: `${subjectName} for ${className} has been submitted and is awaiting class review.`,
    link: '/form-teacher/results',
    meta: { classId, subjectId },
  });
}

async function notifyClassSubmitted({ schoolId, scopePhase, actorAccountId, classId }) {
  const [classDoc, adminRecipients] = await Promise.all([
    ClassModel.findById(classId).select('name').lean(),
    getAdminRecipients({ schoolId, scopePhase }),
  ]);
  await createForRecipients({
    schoolId,
    recipientAccountIds: adminRecipients,
    actorAccountId,
    category: 'workflow',
    title: 'Class result submitted for approval',
    message: `${classDoc?.name || 'A class'} result is ready for admin approval.`,
    link: `/admin/results/class/${classId}`,
    meta: { classId },
  });
}

async function notifyClassApproved({ schoolId, actorAccountId, classId }) {
  const [classDoc, formTeacherRecipients] = await Promise.all([
    ClassModel.findById(classId).select('name').lean(),
    getFormTeacherRecipientsForClass({ schoolId, classId }),
  ]);
  await createForRecipients({
    schoolId,
    recipientAccountIds: formTeacherRecipients,
    actorAccountId,
    category: 'workflow',
    title: 'Class result approved',
    message: `${classDoc?.name || 'This class'} result has been approved by admin.`,
    link: `/form-teacher/results/class/${classId}`,
    meta: { classId },
  });
}



async function getRecipientAccountIdsForAudience({ schoolId, audience = 'all_school', scopePhase = null }) {
  if (!schoolId) return [];
  const criteria = { school: schoolId, isActive: true };
  const normalizedAudience = String(audience || 'all_school').trim().toLowerCase();

  if (normalizedAudience === 'students') criteria.role = 'student';
  else if (normalizedAudience === 'teachers') criteria.role = 'teacher';
  else if (normalizedAudience === 'form_teachers') criteria.role = 'form_teacher';
  else if (normalizedAudience === 'teachers_and_form_teachers') criteria.role = { $in: ['teacher', 'form_teacher'] };
  else if (normalizedAudience === 'admins') criteria.role = { $in: ['admin', 'staff'] };
  else if (normalizedAudience === 'staff') criteria.role = 'staff';
  else criteria.role = { $in: ['student', 'teacher', 'form_teacher', 'admin', 'staff'] };

  if (scopePhase) {
    criteria.$or = [
      { scopePhase },
      { scopePhase: null },
      { scopePhase: { $exists: false } },
    ];
  }

  const docs = await Account.find(criteria).select('_id').lean();
  return docs.map((doc) => doc._id);
}

async function createManualAnnouncement({ schoolId, actorAccountId, audience = 'all_school', scopePhase = null, title, message, link = '/notifications' }) {
  const recipientAccountIds = await getRecipientAccountIdsForAudience({ schoolId, audience, scopePhase });
  return createForRecipients({
    schoolId,
    recipientAccountIds,
    senderType: 'admin',
    actorAccountId,
    category: 'announcement',
    title,
    message,
    link: String(link || '/notifications').trim() || '/notifications',
    meta: { audience, scopePhase: scopePhase || null },
  });
}



async function listSentAnnouncements({ schoolId, actorAccountId = null, audience = '', q = '', startDate = '', endDate = '', limit = 50 }) {
  if (!schoolId) return [];
  const match = { school: require('mongoose').Types.ObjectId.createFromHexString(String(schoolId)), senderType: 'admin', category: 'announcement' };
  if (actorAccountId) match.actorAccount = require('mongoose').Types.ObjectId.createFromHexString(String(actorAccountId));
  if (audience) match['meta.audience'] = String(audience).trim();
  if (startDate || endDate) {
    match.createdAt = {};
    if (startDate) match.createdAt.$gte = new Date(`${startDate}T00:00:00.000Z`);
    if (endDate) match.createdAt.$lte = new Date(`${endDate}T23:59:59.999Z`);
  }
  if (q) {
    match.$or = [
      { title: { $regex: String(q).trim(), $options: 'i' } },
      { message: { $regex: String(q).trim(), $options: 'i' } },
    ];
  }

  const rows = await Notification.aggregate([
    { $match: match },
    {
      $group: {
        _id: {
          broadcastKey: { $ifNull: ['$meta.broadcastKey', null] },
          actorAccount: '$actorAccount',
          audience: { $ifNull: ['$meta.audience', 'all_school'] },
          title: '$title',
          message: '$message',
          link: '$link',
          createdAt: '$createdAt',
        },
        recipientCount: { $sum: 1 },
        readCount: { $sum: { $cond: ['$isRead', 1, 0] } },
      },
    },
    {
      $project: {
        _id: 0,
        broadcastKey: '$_id.broadcastKey',
        actorAccount: '$_id.actorAccount',
        audience: '$_id.audience',
        title: '$_id.title',
        message: '$_id.message',
        link: '$_id.link',
        createdAt: '$_id.createdAt',
        recipientCount: 1,
        readCount: 1,
        unreadCount: { $subtract: ['$recipientCount', '$readCount'] },
      },
    },
    { $sort: { createdAt: -1 } },
    { $limit: Math.max(1, Math.min(Number(limit) || 50, 200)) },
  ]);

  const actorIds = uniqueIds(rows.map((item) => item.actorAccount));
  const actors = actorIds.length
    ? await Account.find({ _id: { $in: actorIds } }).select('_id fullName name username').lean()
    : [];
  const actorMap = new Map(actors.map((actor) => [String(actor._id), actor]));

  return rows.map((item) => ({
    ...item,
    actorName: actorMap.get(String(item.actorAccount))?.fullName || actorMap.get(String(item.actorAccount))?.name || actorMap.get(String(item.actorAccount))?.username || 'School Administration',
  }));
}

async function notifyResultsPublished({ schoolId, actorAccountId, academicYear, term }) {
  const results = await PublishedStudentResult.find({ school: schoolId, academicYear: String(academicYear).trim(), term: String(term).trim() })
    .select('student')
    .lean();
  const studentIds = uniqueIds(results.map((item) => item.student));
  if (!studentIds.length) return 0;
  const accounts = await Account.find({ school: schoolId, role: 'student', student: { $in: studentIds }, isActive: true }).select('_id').lean();
  return createForRecipients({
    schoolId,
    recipientAccountIds: accounts.map((doc) => doc._id),
    actorAccountId,
    category: 'publication',
    title: 'Result published',
    message: `${term} result for ${academicYear} is now available on your portal.`,
    link: '/student/results',
    meta: { academicYear, term },
  });
}

module.exports = {
  getDashboardPanelData,
  createForRecipients,
  getUnreadCount,
  listForAccount,
  markOneRead,
  markAllRead,
  notifySubjectSubmitted,
  notifyClassSubmitted,
  notifyClassApproved,
  notifyResultsPublished,
  getRecipientAccountIdsForAudience,
  createManualAnnouncement,
  listSentAnnouncements,
  getPreferencesForAccount,
  updatePreferencesForAccount,
};


async function getDashboardPanelData({ schoolId, accountId, limit = 5 }) {
  const [unreadCount, recent] = await Promise.all([
    getUnreadCount({ schoolId, accountId }),
    listForAccount({ schoolId, accountId, limit }),
  ]);
  const unreadByCategory = recent.filter((n) => !n.isRead).reduce((acc, item) => {
    const key = item.category || 'general';
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {});
  return { unreadCount, unreadByCategory, recent };
}
