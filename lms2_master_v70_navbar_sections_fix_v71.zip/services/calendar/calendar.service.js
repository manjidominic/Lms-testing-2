const CalendarEvent = require('../../models/CalendarEvent');
const notificationService = require('../notifications/notification.service');

function audienceFilter(role) {
  if (role === 'student' || role === 'parent') return { audience: { $in: ['all','students'] } };
  if (role === 'teacher' || role === 'form_teacher') return { audience: { $in: ['all','teachers'] } };
  return { audience: { $in: ['all','admin'] } };
}

async function listEvents({ schoolId, role }) {
  const now = new Date();
  const upcoming = await CalendarEvent.find({ school: schoolId, endDate: { $gte: new Date(now.getFullYear(), now.getMonth(), now.getDate()) }, ...audienceFilter(role) }).sort({ startDate: 1 }).limit(100).lean();
  return upcoming;
}

async function createEvent({ schoolId, actorAccountId, role, payload }) {
  const event = await CalendarEvent.create({ school: schoolId, createdBy: actorAccountId, ...payload });
  if (['Exam','Deadline'].includes(event.type)) {
    await notificationService.createManualAnnouncement({ schoolId, actorAccountId, audience: event.audience === 'all' ? 'all_school' : event.audience === 'students' ? 'students' : event.audience === 'teachers' ? 'teachers_and_form_teachers' : 'admins', title: `${event.type}: ${event.title}`, message: event.description || `${event.title} scheduled for ${new Date(event.startDate).toLocaleDateString()}`, link: '/calendar' });
  }
  return event;
}

module.exports = {
  listUpcomingForRole, listEvents, createEvent };


async function listUpcomingForRole({ schoolId, role, limit = 5 }) {
  const now = new Date();
  const audience = role === 'student' ? ['all','students'] : role === 'teacher' || role === 'form_teacher' ? ['all','teachers'] : role === 'parent' ? ['all','students'] : ['all','admin'];
  return CalendarEvent.find({ school: schoolId, audience: { $in: audience }, endDate: { $gte: now } })
    .sort({ startDate: 1 })
    .limit(limit)
    .lean();
}
