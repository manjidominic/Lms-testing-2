const School = require('../../models/School');
const Account = require('../../models/Account');
const seedSchoolClasses = require('../../utils/seedSchoolClasses.util');
const Subscription = require('../../models/Subscription');
const bcrypt = require('bcrypt');
const { addMonths } = require('../../utils/subscription.util');

function normalizePhases(type) {
  const t = String(type || '').trim().toLowerCase();

  if (t === 'primary') return ['Primary'];
  if (t === 'secondary') return ['Secondary'];
  if (t === 'both') return ['Primary', 'Secondary'];

  const err = new Error('Invalid school type. Choose Primary, Secondary, or Both.');
  err.statusCode = 400;
  throw err;
}

module.exports = async function registerSchoolService(payload = {}) {
  const {
    name,
    type,
    code,

    // Admin creation inputs
    adminEmail,
    adminPassword,
    primaryAdminEmail,
    primaryAdminPassword,
    secondaryAdminEmail,
    secondaryAdminPassword,
    primaryClasses,
  } = payload;

  if (!name || !type || !code) {
    const err = new Error('Name, type and code are required');
    err.statusCode = 400;
    throw err;
  }

  const normalizedCode = code.toLowerCase().trim();

  const exists = await School.findOne({ code: normalizedCode }).select('_id');
  if (exists) {
    const err = new Error('School code already exists');
    err.statusCode = 409;
    throw err;
  }

  // ✅ convert type -> phases array
  const phases = normalizePhases(type);

  const school = await School.create({
    name: name.trim(),
    phases,            // ✅ store phases array
    code: normalizedCode,
  });


  if (phases.length === 2) {
    const primaryEmail = String(primaryAdminEmail || '').toLowerCase().trim();
    const secondaryEmail = String(secondaryAdminEmail || '').toLowerCase().trim();
    if (primaryEmail && secondaryEmail && primaryEmail === secondaryEmail) {
      const err = new Error('Primary admin email and secondary admin email must be different for a school with both phases');
      err.statusCode = 400;
      throw err;
    }
  }


  // ✅ Create admin accounts based on school phases.
  // We never take phase from req.body; it is controlled by the school configuration.
  // - Primary-only => 1 admin scoped to Primary
  // - Secondary-only => 1 admin scoped to Secondary
  // - Both => 2 admins (Primary + Secondary)
  const createAdminAccount = async ({ scopePhase, email, password }) => {
    const normalizedEmail = String(email || '').toLowerCase().trim();
    if (!normalizedEmail || !password) {
      const err = new Error(`Missing admin credentials for ${scopePhase}`);
      err.statusCode = 400;
      throw err;
    }

    const emailExists = await Account.findOne({
      school: school._id,
      email: normalizedEmail,
    }).select('_id');
    if (emailExists) {
      const err = new Error(`An account with ${normalizedEmail} already exists for this school`);
      err.statusCode = 409;
      throw err;
    }

    const passwordHash = await bcrypt.hash(String(password), 10);

    return Account.create({
      school: school._id,
      role: 'admin',
      scopePhase,
      email: normalizedEmail,
      username: undefined,
      passwordHash,
      mustChangePassword: false,
      isActive: true,
    });
  };

  try {
    if (phases.length === 1) {
      const only = phases[0];
      await createAdminAccount({
        scopePhase: only,
        email: adminEmail,
        password: adminPassword,
      });
    } else {
      // Both
      await createAdminAccount({
        scopePhase: 'Primary',
        email: primaryAdminEmail,
        password: primaryAdminPassword,
      });
      await createAdminAccount({
        scopePhase: 'Secondary',
        email: secondaryAdminEmail,
        password: secondaryAdminPassword,
      });
    }
  } catch (e) {
    // Rollback if admin creation fails (simple compensation)
    await Account.deleteMany({ school: school._id });
    await School.deleteOne({ _id: school._id });
    throw e;
  }

  // ✅ Seed default classes immediately so dropdowns work out-of-the-box.
  // This is safe because Class model has unique indexes to prevent duplicates.
  try {
    const primaryClassNames = Array.isArray(primaryClasses) ? primaryClasses : (primaryClasses ? [primaryClasses] : null);
    await seedSchoolClasses({ schoolId: school._id, phases, primaryClassNames });
  } catch (e) {
    // If duplicate key errors happen (re-run), ignore; anything else bubble up.
    if (e && e.code !== 11000) throw e;
  }


  // ✅ Seed a 4-month TRIAL subscription (all features open during trial).
  // This is the commercial gate for admins/teachers/students. Owner is never blocked.
  try {
    const trialStart = new Date();
    const trialEnd = addMonths(trialStart, 4);

    const sub = await Subscription.create({
      school: school._id,
      status: 'TRIAL',
      trialStart,
      trialEnd,
    });

    school.subscription = sub._id;
    await school.save();
  } catch (e) {
    // Ignore duplicate subscription record if re-run
    if (e && e.code !== 11000) throw e;
  }

  return school;
};