const ClassModel = require('../../models/class');
const ClassResultStatus = require('../../models/ClassResultStatus');
const TeachingAssignment = require('../../models/TeachingAssignment');
const SubjectResultSubmission = require('../../models/SubjectResultSubmission');
const {
  computeClassTermBroadsheet,
  computeClassAnnualBroadsheet,
  computeStudentTermResult,
  buildBroadsheetCsv,
  buildAnnualBroadsheetCsv,
  computeAndFreezeClassTermResults,
  publishResults,
  getPublishStatus,
  getClassResultStatus,
  getClassAuditTrail,
  submitClassResults,
  approveClassResults,
} = require('../results');
const promotionService = require('../promotion/promotion.service');

function getAcademicContext(req) {
  return {
    schoolId: req.schoolId,
    reqScopePhase: req.scopePhase,
    academicYear: req.session.currentAcademicYear,
    term: req.session.currentTerm,
    actorAccountId: req.session.account?.id || req.session.account?._id || null,
  };
}

async function listClassesWithResultStatus(req) {
  const { schoolId, reqScopePhase, academicYear, term } = getAcademicContext(req);

  const filter = { school: schoolId };
  if (reqScopePhase) filter.phase = reqScopePhase;

  const classesRaw = await ClassModel.find(filter)
    .select('name phase level')
    .sort({ level: 1, name: 1 })
    .lean();

  const [publishStatus, statuses, teachingAssignments, subjectSubmissions] = await Promise.all([
    getPublishStatus({ schoolId, academicYear, term }),
    ClassResultStatus.find({
      school: schoolId,
      academicYear: String(academicYear).trim(),
      term: String(term).trim(),
      class: { $in: classesRaw.map((klass) => klass._id) },
    }).select('class status').lean(),
    TeachingAssignment.find({
      school: schoolId,
      academicYear: String(academicYear).trim(),
      class: { $in: classesRaw.map((klass) => klass._id) },
    }).select('class').lean(),
    SubjectResultSubmission.find({
      school: schoolId,
      academicYear: String(academicYear).trim(),
      term: String(term).trim(),
      class: { $in: classesRaw.map((klass) => klass._id) },
      status: 'Submitted',
    }).select('class').lean(),
  ]);

  const statusMap = new Map(statuses.map((status) => [String(status.class), status.status]));
  const assignmentCountMap = new Map();
  for (const item of teachingAssignments) assignmentCountMap.set(String(item.class), (assignmentCountMap.get(String(item.class)) || 0) + 1);
  const submittedSubjectCountMap = new Map();
  for (const item of subjectSubmissions) submittedSubjectCountMap.set(String(item.class), (submittedSubjectCountMap.get(String(item.class)) || 0) + 1);

  const classes = classesRaw.map((klass) => {
    const explicitStatus = statusMap.get(String(klass._id));
    const assignmentCount = assignmentCountMap.get(String(klass._id)) || 0;
    const submittedSubjectCount = submittedSubjectCountMap.get(String(klass._id)) || 0;
    let resultStatus = explicitStatus || 'Not Computed';
    if (!explicitStatus && submittedSubjectCount > 0) resultStatus = 'Draft';
    return {
      ...klass,
      resultStatus,
      assignmentCount,
      submittedSubjectCount,
    };
  });

  const totalClasses = classes.length;
  const submittedClasses = classes.filter((item) => item.resultStatus === 'Submitted').length;
  const approvedClasses = classes.filter((item) => item.resultStatus === 'Approved').length;
  const computedClasses = classes.filter((item) => item.submittedSubjectCount > 0).length;

  return {
    title: 'Results',
    classes,
    academicYear,
    term,
    publishStatus,
    workflowSummary: {
      totalClasses,
      computedClasses,
      submittedClasses,
      approvedClasses,
      canPublish: totalClasses > 0 && approvedClasses === totalClasses,
    },
  };
}

async function computeFreezeForClass(req) {
  const { schoolId, reqScopePhase, academicYear, term } = getAcademicContext(req);
  const { classId } = req.params;

  await computeAndFreezeClassTermResults({
    schoolId,
    classId,
    academicYear,
    term,
    reqScopePhase,
  });

  return { redirectTo: `/admin/results/class/${classId}` };
}

async function publishComputedResults(req) {
  const { schoolId, academicYear, term, actorAccountId, reqScopePhase } = getAcademicContext(req);
  const requireAllApproved = req.body?.requireAllApproved !== 'false';

  await publishResults({
    schoolId,
    academicYear,
    term,
    publisherAccountId: actorAccountId,
    requireAllApproved,
    reqScopePhase,
  });

  return { redirectTo: '/admin/results' };
}

async function getClassBroadsheetPageData(req) {
  const { schoolId, reqScopePhase, academicYear, term } = getAcademicContext(req);
  const { classId } = req.params;
  const { sectionId } = req.query;

  const data = await computeClassTermBroadsheet({
    schoolId,
    classId,
    academicYear,
    term,
    reqScopePhase,
    sectionId: sectionId || null,
    submittedOnly: true,
  });

  const status = await getClassResultStatus({ schoolId, academicYear, term, classId });
  const { class: cls, ...rest } = data;
  const [publishStatus, allStatuses, totalClasses, auditTrail] = await Promise.all([
    getPublishStatus({ schoolId, academicYear, term }),
    ClassResultStatus.find({ school: schoolId, academicYear: String(academicYear).trim(), term: String(term).trim() }).select('status').lean(),
    ClassModel.countDocuments({ school: schoolId }),
    getClassAuditTrail({ schoolId, academicYear, term, classId }),
  ]);
  const approvedClasses = allStatuses.filter((item) => item.status === 'Approved').length;

  return {
    view: 'admin/results/class',
    payload: {
      title: `Broadsheet - ${cls.name}`,
      ...rest,
      klass: cls,
      resultStatus: status?.status || 'Not Computed',
      publishStatus,
      workflowSummary: {
        totalClasses,
        approvedClasses,
        canPublish: totalClasses > 0 && approvedClasses === totalClasses,
      },
      auditTrail,
    },
  };
}

async function getClassPrintData(req) {
  const { schoolId, reqScopePhase, academicYear, term } = getAcademicContext(req);
  const { classId } = req.params;
  const { sectionId } = req.query;

  const data = await computeClassTermBroadsheet({
    schoolId,
    classId,
    academicYear,
    term,
    reqScopePhase,
    sectionId: sectionId || null,
    submittedOnly: true,
  });

  const { class: cls, ...rest } = data;
  return {
    view: 'admin/results/print',
    payload: {
      layout: false,
      title: `Printable Broadsheet - ${cls.name}`,
      ...rest,
      klass: cls,
      generatedAt: new Date(),
    },
  };
}

async function getClassCsvDownload(req) {
  const { schoolId, reqScopePhase, academicYear, term } = getAcademicContext(req);
  const { classId } = req.params;
  const { sectionId } = req.query;

  const data = await computeClassTermBroadsheet({
    schoolId,
    classId,
    academicYear,
    term,
    reqScopePhase,
    sectionId: sectionId || null,
    submittedOnly: true,
  });

  const csv = buildBroadsheetCsv(data);
  const safeClassName = String(data.class?.name || 'class').replace(/[^a-z0-9-_]+/gi, '_');

  return {
    csv,
    filename: `broadsheet_${safeClassName}_${academicYear}_${term}.csv`,
  };
}

async function getAnnualBroadsheetPageData(req) {
  const { schoolId, reqScopePhase, academicYear, term } = getAcademicContext(req);
  const { classId } = req.params;
  const { sectionId } = req.query;

  const data = await computeClassAnnualBroadsheet({
    schoolId,
    classId,
    academicYear,
    reqScopePhase,
    sectionId: sectionId || null,
  });
  const promotionData = await promotionService.getPromotionPageData({
    schoolId,
    classId,
    status: 'Active',
  });
  const targetAcademicYears = await promotionService.listPromotionTargetAcademicYears({
    schoolId,
    currentAcademicYearName: academicYear,
  });
  const derivedNextName = (() => {
    const m = String(academicYear || '').match(/^(\d{4})\s*\/\s*(\d{4})$/);
    if (!m) return '';
    return `${Number(m[1]) + 1}/${Number(m[2]) + 1}`;
  })();
  const defaultTargetAcademicYear = targetAcademicYears.find((year) => year.name === derivedNextName) || targetAcademicYears[0] || null;

  const { class: cls, ...rest } = data;
  return {
    view: 'admin/results/annual',
    payload: {
      title: `Annual Broadsheet - ${cls.name}`,
      ...rest,
      klass: cls,
      promotionOutcome: promotionData.outcome,
      activeTerm: term,
      query: req.query || {},
      targetAcademicYears,
      selectedTargetAcademicYearId: String((req.query && req.query.targetAcademicYearId) || (defaultTargetAcademicYear && defaultTargetAcademicYear._id) || ''),
      defaultTargetAcademicYear,
    },
  };
}

async function getAnnualPrintData(req) {
  const { schoolId, reqScopePhase, academicYear } = getAcademicContext(req);
  const { classId } = req.params;
  const { sectionId } = req.query;

  const data = await computeClassAnnualBroadsheet({
    schoolId,
    classId,
    academicYear,
    reqScopePhase,
    sectionId: sectionId || null,
  });

  const { class: cls, ...rest } = data;
  return {
    view: 'admin/results/annual-print',
    payload: {
      layout: false,
      title: `Annual Broadsheet - ${cls.name}`,
      ...rest,
      klass: cls,
      generatedAt: new Date(),
    },
  };
}

async function getAnnualCsvDownload(req) {
  const { schoolId, reqScopePhase, academicYear } = getAcademicContext(req);
  const { classId } = req.params;
  const { sectionId } = req.query;

  const data = await computeClassAnnualBroadsheet({
    schoolId,
    classId,
    academicYear,
    reqScopePhase,
    sectionId: sectionId || null,
  });

  const csv = buildAnnualBroadsheetCsv(data);
  const safeClassName = String(data.class?.name || 'class').replace(/[^a-z0-9-_]+/gi, '_');

  return {
    csv,
    filename: `annual_broadsheet_${safeClassName}_${academicYear}.csv`,
  };
}

async function moveStudentsFromAnnualBroadsheet(req) {
  const { schoolId, academicYear, term, actorAccountId } = getAcademicContext(req);
  const { classId } = req.params;

  let { promoteIds, repeatIds } = req.body;
  if (!promoteIds) promoteIds = [];
  if (!repeatIds) repeatIds = [];
  if (!Array.isArray(promoteIds)) promoteIds = [promoteIds];
  if (!Array.isArray(repeatIds)) repeatIds = [repeatIds];

  const trackByStudentId = {};
  Object.keys(req.body || {}).forEach((key) => {
    if (key.startsWith('track_')) {
      const studentId = key.slice('track_'.length).trim();
      trackByStudentId[studentId] = req.body[key];
    }
  });

  const targetAcademicYearId = req.body.targetAcademicYearId || null;
  const activateTargetSession = String(req.body.activateTargetSession || '').toLowerCase() === 'on';

  const moveResult = await promotionService.moveStudentsWithSelection({
    schoolId,
    classId,
    promoteIds,
    repeatIds,
    academicYear,
    term,
    actorAccountId,
    trackByStudentId,
    targetAcademicYearId,
    activateTargetSession,
  });

  const params = new URLSearchParams();
  params.set('moved', '1');
  if (targetAcademicYearId) params.set('targetAcademicYearId', String(targetAcademicYearId));
  if (moveResult?.activatedTargetSession) params.set('activated', '1');
  return { redirectTo: `/admin/results/class/${classId}/annual?${params.toString()}` };
}

async function getStudentResultPageData(req) {
  const { schoolId, reqScopePhase, academicYear, term } = getAcademicContext(req);
  const { studentId } = req.params;

  const data = await computeStudentTermResult({
    schoolId,
    studentId,
    academicYear,
    term,
    reqScopePhase,
  });

  const { class: cls, ...rest } = data;
  return {
    view: 'admin/results/student',
    payload: {
      title: `Result - ${data.student.name}`,
      ...rest,
      klass: cls,
    },
  };
}

module.exports = {
  getAcademicContext,
  listClassesWithResultStatus,
  computeFreezeForClass,
  publishComputedResults,
  approveClassForAdmin,
  getClassBroadsheetPageData,
  getClassPrintData,
  getClassCsvDownload,
  getAnnualBroadsheetPageData,
  getAnnualPrintData,
  getAnnualCsvDownload,
  moveStudentsFromAnnualBroadsheet,
  getStudentResultPageData,
};


async function submitClassForAdmin(req) {
  const { schoolId, academicYear, term, actorAccountId } = getAcademicContext(req);
  const { classId } = req.params;
  await submitClassResults({ schoolId, academicYear, term, classId, teacherId: actorAccountId });
  return { redirectTo: `/admin/results/class/${classId}` };
}

async function approveClassForAdmin(req) {
  const { schoolId, academicYear, term, actorAccountId } = getAcademicContext(req);
  const { classId } = req.params;
  const status = await getClassResultStatus({ schoolId, academicYear, term, classId });
  if (!status) {
    const err = new Error('Compute & freeze this class before approving results.');
    err.statusCode = 400;
    throw err;
  }
  if (status.status !== 'Submitted') {
    const err = new Error('Form teacher must submit this class result before admin can approve it.');
    err.statusCode = 400;
    throw err;
  }
  await approveClassResults({ schoolId, academicYear, term, classId, approverAccountId: actorAccountId });
  return { redirectTo: `/admin/results/class/${classId}` };
}
