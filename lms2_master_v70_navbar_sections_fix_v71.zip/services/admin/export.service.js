const bcrypt = require('bcrypt');
const School = require('../../models/School');
const Student = require('../../models/Students');
const Parent = require('../../models/Parent');
const Account = require('../../models/Account');
const PublishedStudentResult = require('../../models/PublishedStudentResult');
const PromotionHistory = require('../../models/PromotionHistory');
const AuditLog = require('../../models/AuditLog');
const Notification = require('../../models/Notification');
const NotificationPreference = require('../../models/NotificationPreference');
const CalendarEvent = require('../../models/CalendarEvent');
const ClassModel = require('../../models/class');
const Section = require('../../models/section');
const Teacher = require('../../models/Teacher');
const AcademicYear = require('../../models/AcademicYear');
const Term = require('../../models/Term');
const Subject = require('../../models/Subject');
const AssessmentPolicy = require('../../models/assessmentPolicy');
const ClassSubject = require('../../models/ClassSubject');
const StudentSubject = require('../../models/StudentSubject');
const TeacherSubject = require('../../models/TeacherSubject');
const TeachingAssignment = require('../../models/TeachingAssignment');
const FormTeacherAssignment = require('../../models/FormTeacherAssignment');
const Result = require('../../models/Result');
const ResultSnapshot = require('../../models/ResultSnapshot');
const SubjectResultSubmission = require('../../models/SubjectResultSubmission');
const FormTeacherAttendance = require('../../models/FormTeacherAttendance');
const ClassResultStatus = require('../../models/ClassResultStatus');
const PublishStatus = require('../../models/PublishStatus');
const Score = require('../../models/score');
const BackupSchedule = require('../../models/BackupSchedule');

function csvEscape(value) {
  const str = String(value == null ? '' : value);
  if (/[,"\n]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

function rowsToCsv(headers, rows) {
  const headerLine = headers.map((h) => csvEscape(h.label)).join(',');
  const lines = rows.map((row) => headers.map((h) => csvEscape(row[h.key])).join(','));
  return [headerLine, ...lines].join('\n');
}

async function getLookupMaps(schoolId) {
  const [classes, sections, parents, teachers] = await Promise.all([
    ClassModel.find({ school: schoolId }).lean(),
    Section.find({ school: schoolId }).lean(),
    Parent.find({ school: schoolId }).lean(),
    Teacher.find({ school: schoolId }).lean(),
  ]);
  return {
    classMap: new Map(classes.map((item) => [String(item._id), item.name])),
    sectionMap: new Map(sections.map((item) => [String(item._id), item.name])),
    parentMap: new Map(parents.map((item) => [String(item._id), item.fullName])),
    teacherMap: new Map(teachers.map((item) => [String(item._id), item.name || item.fullName || `${item.firstName || ''} ${item.lastName || ''}`.trim()])),
  };
}

async function getExportSummary({ schoolId }) {
  const [students, parents, accounts, results, promotions, audits, notifications, calendarEvents, classes, sections, teachers, subjects, years, terms] = await Promise.all([
    Student.countDocuments({ school: schoolId }),
    Parent.countDocuments({ school: schoolId }),
    Account.countDocuments({ school: schoolId }),
    PublishedStudentResult.countDocuments({ school: schoolId }),
    PromotionHistory.countDocuments({ school: schoolId }),
    AuditLog.countDocuments({ school: schoolId }),
    Notification.countDocuments({ school: schoolId }),
    CalendarEvent.countDocuments({ school: schoolId }),
    ClassModel.countDocuments({ school: schoolId }),
    Section.countDocuments({ school: schoolId }),
    Teacher.countDocuments({ school: schoolId }),
    Subject.countDocuments({ school: schoolId }),
    AcademicYear.countDocuments({ school: schoolId }),
    Term.countDocuments({ school: schoolId }),
  ]);

  return { students, parents, accounts, results, promotions, audits, notifications, calendarEvents, classes, sections, teachers, subjects, years, terms };
}

async function exportStudentsCsv({ schoolId }) {
  const { classMap, sectionMap, parentMap } = await getLookupMaps(schoolId);
  const students = await Student.find({ school: schoolId }).sort({ createdAt: -1 }).lean();
  const rows = students.map((item) => ({
    id: String(item._id),
    surname: item.surname || '',
    firstName: item.firstName || '',
    middleName: item.middleName || '',
    fullName: item.name || '',
    phase: item.phase || '',
    level: item.level || '',
    className: classMap.get(String(item.class || '')) || '',
    sectionName: sectionMap.get(String(item.section || '')) || '',
    track: item.track || '',
    admissionYear: item.admissionYear || '',
    currentSession: item.currentSession || '',
    status: item.status || '',
    portalAccess: item.portalAccess || '',
    email: item.email || '',
    username: item.username || '',
    parentName: item.parentName || parentMap.get(String(item.parent || '')) || '',
    parentEmail: item.parentEmail || '',
    parentPhone: item.parentPhone || '',
    createdAt: item.createdAt ? new Date(item.createdAt).toISOString() : '',
  }));

  const headers = [
    { key: 'id', label: 'Student ID' },
    { key: 'surname', label: 'Surname' },
    { key: 'firstName', label: 'First Name' },
    { key: 'middleName', label: 'Middle Name' },
    { key: 'fullName', label: 'Full Name' },
    { key: 'phase', label: 'Phase' },
    { key: 'level', label: 'Level' },
    { key: 'className', label: 'Class' },
    { key: 'sectionName', label: 'Section' },
    { key: 'track', label: 'Track' },
    { key: 'admissionYear', label: 'Admission Year' },
    { key: 'currentSession', label: 'Current Session' },
    { key: 'status', label: 'Status' },
    { key: 'portalAccess', label: 'Portal Access' },
    { key: 'email', label: 'Email' },
    { key: 'username', label: 'Username' },
    { key: 'parentName', label: 'Parent Name' },
    { key: 'parentEmail', label: 'Parent Email' },
    { key: 'parentPhone', label: 'Parent Phone' },
    { key: 'createdAt', label: 'Created At' },
  ];
  return rowsToCsv(headers, rows);
}

async function exportParentsCsv({ schoolId }) {
  const parents = await Parent.find({ school: schoolId }).sort({ createdAt: -1 }).lean();
  const links = await Student.aggregate([
    { $match: { school: require('mongoose').Types.ObjectId.createFromHexString(String(schoolId)), parent: { $ne: null } } },
    { $group: { _id: '$parent', count: { $sum: 1 } } },
  ]).catch(() => []);
  const countMap = new Map();
  for (const item of links) countMap.set(String(item._id), item.count);
  const rows = parents.map((item) => ({
    id: String(item._id),
    fullName: item.fullName || '',
    email: item.email || '',
    phone: item.phone || '',
    username: item.username || '',
    isActive: item.isActive ? 'Yes' : 'No',
    childrenCount: countMap.get(String(item._id)) || 0,
    createdAt: item.createdAt ? new Date(item.createdAt).toISOString() : '',
  }));
  const headers = [
    { key: 'id', label: 'Parent ID' },
    { key: 'fullName', label: 'Full Name' },
    { key: 'email', label: 'Email' },
    { key: 'phone', label: 'Phone' },
    { key: 'username', label: 'Username' },
    { key: 'isActive', label: 'Active' },
    { key: 'childrenCount', label: 'Linked Children' },
    { key: 'createdAt', label: 'Created At' },
  ];
  return rowsToCsv(headers, rows);
}

async function exportPublishedResultsCsv({ schoolId }) {
  const { classMap, sectionMap } = await getLookupMaps(schoolId);
  const results = await PublishedStudentResult.find({ school: schoolId }).sort({ publishedAt: -1 }).lean();
  const rows = results.map((item) => ({
    id: String(item._id),
    academicYear: item.academicYear || '',
    term: item.term || '',
    studentName: item.studentName || '',
    studentEmail: item.studentEmail || '',
    className: classMap.get(String(item.class || '')) || '',
    sectionName: sectionMap.get(String(item.section || '')) || '',
    phase: item.phase || '',
    level: item.level || '',
    track: item.track || '',
    total: item.summary?.total ?? '',
    average: item.summary?.average ?? '',
    position: item.summary?.position ?? '',
    subjectCount: item.summary?.subjectCount ?? '',
    overallRemark: item.overallRemark || '',
    promotionDecision: item.promotionDecision || '',
    publishedAt: item.publishedAt ? new Date(item.publishedAt).toISOString() : '',
  }));
  const headers = [
    { key: 'id', label: 'Published Result ID' },
    { key: 'academicYear', label: 'Academic Year' },
    { key: 'term', label: 'Term' },
    { key: 'studentName', label: 'Student Name' },
    { key: 'studentEmail', label: 'Student Email' },
    { key: 'className', label: 'Class' },
    { key: 'sectionName', label: 'Section' },
    { key: 'phase', label: 'Phase' },
    { key: 'level', label: 'Level' },
    { key: 'track', label: 'Track' },
    { key: 'total', label: 'Total' },
    { key: 'average', label: 'Average' },
    { key: 'position', label: 'Position' },
    { key: 'subjectCount', label: 'Subject Count' },
    { key: 'overallRemark', label: 'Overall Remark' },
    { key: 'promotionDecision', label: 'Promotion Decision' },
    { key: 'publishedAt', label: 'Published At' },
  ];
  return rowsToCsv(headers, rows);
}

async function exportPromotionHistoryCsv({ schoolId }) {
  const { classMap } = await getLookupMaps(schoolId);
  const students = await Student.find({ school: schoolId }).lean();
  const studentMap = new Map(students.map((item) => [String(item._id), item.name]));
  const history = await PromotionHistory.find({ school: schoolId }).sort({ createdAt: -1 }).lean();
  const rows = history.map((item) => ({
    id: String(item._id),
    studentName: studentMap.get(String(item.student || '')) || '',
    fromClass: classMap.get(String(item.fromClass || '')) || '',
    toClass: classMap.get(String(item.toClass || '')) || '',
    action: item.action || '',
    academicYearFrom: item.academicYearFrom || '',
    academicYearTo: item.academicYearTo || '',
    term: item.term || '',
    note: item.note || '',
    createdAt: item.createdAt ? new Date(item.createdAt).toISOString() : '',
  }));
  const headers = [
    { key: 'id', label: 'Promotion Record ID' },
    { key: 'studentName', label: 'Student Name' },
    { key: 'fromClass', label: 'From Class' },
    { key: 'toClass', label: 'To Class' },
    { key: 'action', label: 'Action' },
    { key: 'academicYearFrom', label: 'Academic Year From' },
    { key: 'academicYearTo', label: 'Academic Year To' },
    { key: 'term', label: 'Term' },
    { key: 'note', label: 'Note' },
    { key: 'createdAt', label: 'Created At' },
  ];
  return rowsToCsv(headers, rows);
}

async function exportSecurityAuditCsv({ schoolId }) {
  const logs = await AuditLog.find({ school: schoolId }).sort({ createdAt: -1 }).lean();
  const rows = logs.map((item) => ({
    id: String(item._id),
    action: item.action || '',
    category: item.category || '',
    actorRole: item.actorRole || '',
    targetType: item.targetType || '',
    targetId: item.targetId || '',
    message: item.message || '',
    ipAddress: item.ipAddress || '',
    createdAt: item.createdAt ? new Date(item.createdAt).toISOString() : '',
  }));
  const headers = [
    { key: 'id', label: 'Audit ID' },
    { key: 'action', label: 'Action' },
    { key: 'category', label: 'Category' },
    { key: 'actorRole', label: 'Actor Role' },
    { key: 'targetType', label: 'Target Type' },
    { key: 'targetId', label: 'Target ID' },
    { key: 'message', label: 'Message' },
    { key: 'ipAddress', label: 'IP Address' },
    { key: 'createdAt', label: 'Created At' },
  ];
  return rowsToCsv(headers, rows);
}

async function exportCalendarCsv({ schoolId }) {
  const events = await CalendarEvent.find({ school: schoolId }).sort({ startDate: 1, createdAt: -1 }).lean();
  const rows = events.map((item) => ({
    id: String(item._id),
    title: item.title || '',
    description: item.description || '',
    type: item.type || '',
    audience: item.audience || '',
    startDate: item.startDate ? new Date(item.startDate).toISOString() : '',
    endDate: item.endDate ? new Date(item.endDate).toISOString() : '',
    createdAt: item.createdAt ? new Date(item.createdAt).toISOString() : '',
  }));
  const headers = [
    { key: 'id', label: 'Event ID' },
    { key: 'title', label: 'Title' },
    { key: 'description', label: 'Description' },
    { key: 'type', label: 'Type' },
    { key: 'audience', label: 'Audience' },
    { key: 'startDate', label: 'Start Date' },
    { key: 'endDate', label: 'End Date' },
    { key: 'createdAt', label: 'Created At' },
  ];
  return rowsToCsv(headers, rows);
}

function sanitizeDocs(docs = [], schoolId, mapper = null) {
  return (docs || []).map((item) => {
    const copy = JSON.parse(JSON.stringify(item));
    delete copy.__v;
    if (Object.prototype.hasOwnProperty.call(copy, 'school')) copy.school = schoolId;
    return mapper ? mapper(copy) : copy;
  });
}

async function buildFullBackup({ schoolId }) {
  const school = await School.findById(schoolId).lean();
  const [
    academicYears,
    terms,
    classes,
    sections,
    subjects,
    assessmentPolicies,
    classSubjects,
    studentSubjects,
    teachers,
    teacherSubjects,
    teachingAssignments,
    formTeacherAssignments,
    students,
    parents,
    accounts,
    scores,
    results,
    resultSnapshots,
    subjectResultSubmissions,
    formTeacherAttendance,
    classResultStatuses,
    publishStatuses,
    publishedResults,
    promotionHistory,
    notifications,
    notificationPreferences,
    calendarEvents,
    securityAudit,
    backupSchedule,
  ] = await Promise.all([
    AcademicYear.find({ school: schoolId }).lean(),
    Term.find({ school: schoolId }).lean(),
    ClassModel.find({ school: schoolId }).lean(),
    Section.find({ school: schoolId }).lean(),
    Subject.find({ school: schoolId }).lean(),
    AssessmentPolicy.find({ school: schoolId }).lean(),
    ClassSubject.find({ school: schoolId }).lean(),
    StudentSubject.find({ school: schoolId }).lean(),
    Teacher.find({ school: schoolId }).lean(),
    TeacherSubject.find({ school: schoolId }).lean(),
    TeachingAssignment.find({ school: schoolId }).lean(),
    FormTeacherAssignment.find({ school: schoolId }).lean(),
    Student.find({ school: schoolId }).lean(),
    Parent.find({ school: schoolId }).lean(),
    Account.find({ school: schoolId }).lean(),
    Score.find({ school: schoolId }).lean(),
    Result.find({ school: schoolId }).lean(),
    ResultSnapshot.find({ school: schoolId }).lean(),
    SubjectResultSubmission.find({ school: schoolId }).lean(),
    FormTeacherAttendance.find({ school: schoolId }).lean(),
    ClassResultStatus.find({ school: schoolId }).lean(),
    PublishStatus.find({ school: schoolId }).lean(),
    PublishedStudentResult.find({ school: schoolId }).lean(),
    PromotionHistory.find({ school: schoolId }).lean(),
    Notification.find({ school: schoolId }).lean(),
    NotificationPreference.find({ school: schoolId }).lean(),
    CalendarEvent.find({ school: schoolId }).lean(),
    AuditLog.find({ school: schoolId }).sort({ createdAt: -1 }).limit(5000).lean(),
    BackupSchedule.findOne({ school: schoolId }).lean(),
  ]);

  return {
    backupVersion: 2,
    generatedAt: new Date().toISOString(),
    school,
    counts: {
      academicYears: academicYears.length,
      terms: terms.length,
      classes: classes.length,
      sections: sections.length,
      subjects: subjects.length,
      assessmentPolicies: assessmentPolicies.length,
      classSubjects: classSubjects.length,
      studentSubjects: studentSubjects.length,
      teachers: teachers.length,
      teacherSubjects: teacherSubjects.length,
      teachingAssignments: teachingAssignments.length,
      formTeacherAssignments: formTeacherAssignments.length,
      students: students.length,
      parents: parents.length,
      accounts: accounts.length,
      scores: scores.length,
      results: results.length,
      resultSnapshots: resultSnapshots.length,
      subjectResultSubmissions: subjectResultSubmissions.length,
      formTeacherAttendance: formTeacherAttendance.length,
      classResultStatuses: classResultStatuses.length,
      publishStatuses: publishStatuses.length,
      publishedResults: publishedResults.length,
      promotionHistory: promotionHistory.length,
      notifications: notifications.length,
      notificationPreferences: notificationPreferences.length,
      calendarEvents: calendarEvents.length,
      securityAudit: securityAudit.length,
      backupSchedules: backupSchedule ? 1 : 0,
    },
    academicYears,
    terms,
    classes,
    sections,
    subjects,
    assessmentPolicies,
    classSubjects,
    studentSubjects,
    teachers,
    teacherSubjects,
    teachingAssignments,
    formTeacherAssignments,
    students,
    parents,
    accounts: accounts
      .filter((item) => String(item.role || '').toLowerCase() !== 'owner')
      .map((item) => ({
        _id: item._id,
        school: item.school,
        role: item.role,
        scopePhase: item.scopePhase,
        email: item.email,
        username: item.username,
        student: item.student,
        teacher: item.teacher,
        parent: item.parent,
        mustChangePassword: item.mustChangePassword,
        isActive: item.isActive,
        lastLoginAt: item.lastLoginAt,
        createdAt: item.createdAt,
        updatedAt: item.updatedAt,
      })),
    scores,
    results,
    resultSnapshots,
    subjectResultSubmissions,
    formTeacherAttendance,
    classResultStatuses,
    publishStatuses,
    publishedResults,
    promotionHistory,
    notifications,
    notificationPreferences,
    calendarEvents,
    securityAudit,
    backupSchedule: backupSchedule || null,
  };
}

async function restoreFullBackup({ schoolId, backupText, expectedSchoolCode, actorAccountId = null }) {
  if (!backupText || typeof backupText !== 'string') {
    throw new Error('Backup JSON content is required.');
  }

  let backup;
  try {
    backup = JSON.parse(backupText);
  } catch (err) {
    throw new Error('Backup JSON is invalid.');
  }

  if (!backup || typeof backup !== 'object' || !backup.school) {
    throw new Error('Backup file is missing the school payload.');
  }

  const currentSchool = await School.findById(schoolId).lean();
  if (!currentSchool) throw new Error('Current school could not be found.');

  const backupSchoolCode = String(backup.school.code || '').trim().toLowerCase();
  const currentSchoolCode = String(currentSchool.code || '').trim().toLowerCase();
  const typedCode = String(expectedSchoolCode || '').trim().toLowerCase();

  if (!typedCode || typedCode !== currentSchoolCode) {
    throw new Error('Confirmation school code does not match the current school code.');
  }
  if (backupSchoolCode && backupSchoolCode !== currentSchoolCode) {
    throw new Error('This backup belongs to a different school code and cannot be restored here.');
  }

  const temporaryPassword = `Restore${Math.random().toString(36).slice(2, 8)}!`;
  const passwordHash = await bcrypt.hash(temporaryPassword, 10);

  const schoolUpdate = {
    name: backup.school.name || currentSchool.name,
    phases: Array.isArray(backup.school.phases) && backup.school.phases.length ? backup.school.phases : currentSchool.phases,
    isActive: backup.school.isActive !== undefined ? !!backup.school.isActive : currentSchool.isActive,
    reportCardSettings: backup.school.reportCardSettings || currentSchool.reportCardSettings || {},
  };

  const insertPlan = [
    { label: 'academicYears', model: AcademicYear, docs: sanitizeDocs(backup.academicYears, schoolId) },
    { label: 'terms', model: Term, docs: sanitizeDocs(backup.terms, schoolId) },
    { label: 'classes', model: ClassModel, docs: sanitizeDocs(backup.classes, schoolId) },
    { label: 'sections', model: Section, docs: sanitizeDocs(backup.sections, schoolId) },
    { label: 'subjects', model: Subject, docs: sanitizeDocs(backup.subjects, schoolId) },
    { label: 'assessmentPolicies', model: AssessmentPolicy, docs: sanitizeDocs(backup.assessmentPolicies, schoolId) },
    { label: 'classSubjects', model: ClassSubject, docs: sanitizeDocs(backup.classSubjects, schoolId) },
    { label: 'studentSubjects', model: StudentSubject, docs: sanitizeDocs(backup.studentSubjects, schoolId) },
    { label: 'parents', model: Parent, docs: sanitizeDocs(backup.parents, schoolId) },
    { label: 'accounts', model: Account, docs: sanitizeDocs(backup.accounts, schoolId, (copy) => {
        delete copy.passwordHash;
        copy.passwordHash = passwordHash;
        copy.mustChangePassword = true;
        copy.lastLoginAt = null;
        if (String(copy.role || '').toLowerCase() === 'owner') return null;
        return copy;
      }).filter(Boolean) },
    { label: 'teachers', model: Teacher, docs: sanitizeDocs(backup.teachers, schoolId) },
    { label: 'teacherSubjects', model: TeacherSubject, docs: sanitizeDocs(backup.teacherSubjects, schoolId) },
    { label: 'teachingAssignments', model: TeachingAssignment, docs: sanitizeDocs(backup.teachingAssignments, schoolId) },
    { label: 'formTeacherAssignments', model: FormTeacherAssignment, docs: sanitizeDocs(backup.formTeacherAssignments, schoolId) },
    { label: 'students', model: Student, docs: sanitizeDocs(backup.students, schoolId) },
    { label: 'scores', model: Score, docs: sanitizeDocs(backup.scores, schoolId) },
    { label: 'results', model: Result, docs: sanitizeDocs(backup.results, schoolId) },
    { label: 'resultSnapshots', model: ResultSnapshot, docs: sanitizeDocs(backup.resultSnapshots, schoolId) },
    { label: 'subjectResultSubmissions', model: SubjectResultSubmission, docs: sanitizeDocs(backup.subjectResultSubmissions, schoolId) },
    { label: 'formTeacherAttendance', model: FormTeacherAttendance, docs: sanitizeDocs(backup.formTeacherAttendance, schoolId) },
    { label: 'classResultStatuses', model: ClassResultStatus, docs: sanitizeDocs(backup.classResultStatuses, schoolId) },
    { label: 'publishStatuses', model: PublishStatus, docs: sanitizeDocs(backup.publishStatuses, schoolId) },
    { label: 'publishedResults', model: PublishedStudentResult, docs: sanitizeDocs(backup.publishedResults || backup.resultsReleased || backup.publishedResults, schoolId) },
    { label: 'promotionHistory', model: PromotionHistory, docs: sanitizeDocs(backup.promotionHistory, schoolId) },
    { label: 'notifications', model: Notification, docs: sanitizeDocs(backup.notifications, schoolId) },
    { label: 'notificationPreferences', model: NotificationPreference, docs: sanitizeDocs(backup.notificationPreferences, schoolId) },
    { label: 'calendarEvents', model: CalendarEvent, docs: sanitizeDocs(backup.calendarEvents, schoolId) },
    { label: 'securityAudit', model: AuditLog, docs: sanitizeDocs(backup.securityAudit, schoolId, (copy) => {
        copy.actorAccount = copy.actorAccount || actorAccountId || null;
        return copy;
      }) },
    { label: 'backupSchedules', model: BackupSchedule, docs: sanitizeDocs(backup.backupSchedule ? [backup.backupSchedule] : [], schoolId, (copy) => {
        copy.updatedBy = actorAccountId || copy.updatedBy || null;
        return copy;
      }) },
  ];

  for (const item of insertPlan.slice().reverse()) {
    await item.model.deleteMany({ school: schoolId });
  }
  await School.findByIdAndUpdate(schoolId, schoolUpdate);

  const restoredCounts = {};
  for (const item of insertPlan) {
    if (!item.docs.length) {
      restoredCounts[item.label] = 0;
      continue;
    }
    await item.model.insertMany(item.docs, { ordered: true });
    restoredCounts[item.label] = item.docs.length;
  }

  return {
    backupVersion: backup.backupVersion || 1,
    generatedAt: backup.generatedAt || '',
    restoredCounts,
    temporaryPassword,
  };
}

module.exports = {
  getExportSummary,
  exportStudentsCsv,
  exportParentsCsv,
  exportPublishedResultsCsv,
  exportPromotionHistoryCsv,
  exportSecurityAuditCsv,
  exportCalendarCsv,
  buildFullBackup,
  restoreFullBackup,
};
