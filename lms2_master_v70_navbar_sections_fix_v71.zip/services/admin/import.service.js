const Class = require('../../models/class');
const Section = require('../../models/section');
const studentsService = require('../students/students.service');
const teacherService = require('../teachers/teacher.service');

function parseCsvLine(line) {
  const out = [];
  let current = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i += 1) {
    const ch = line[i];
    const next = line[i + 1];
    if (ch === '"') {
      if (inQuotes && next === '"') {
        current += '"';
        i += 1;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch === ',' && !inQuotes) {
      out.push(current.trim());
      current = '';
    } else {
      current += ch;
    }
  }
  out.push(current.trim());
  return out;
}

function parseCsv(text) {
  const normalized = String(text || '').replace(/^\uFEFF/, '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  const lines = normalized.split('\n').map((line) => line.trim()).filter(Boolean);
  if (lines.length < 2) {
    const err = new Error('Provide a CSV header row and at least one data row.');
    err.statusCode = 400;
    throw err;
  }
  const headers = parseCsvLine(lines[0]).map((h) => String(h || '').trim());
  const rows = lines.slice(1).map((line, index) => {
    const values = parseCsvLine(line);
    const row = { __rowNumber: index + 2 };
    headers.forEach((header, idx) => {
      row[header] = values[idx] === undefined ? '' : values[idx];
    });
    return row;
  });
  return { headers, rows };
}

async function resolveClassAndSection({ schoolId, reqScopePhase, className, sectionName }) {
  const classObj = await Class.findOne({
    school: schoolId,
    ...(reqScopePhase ? { phase: reqScopePhase } : {}),
    name: new RegExp(`^${String(className || '').trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i'),
  });
  if (!classObj) {
    return { error: `Class not found: ${className}` };
  }
  let sectionObj = null;
  const sectionLabel = String(sectionName || '').trim();
  const existingSections = await Section.find({ school: schoolId, class: classObj._id }).select('_id name').lean();
  if (existingSections.length) {
    if (!sectionLabel) {
      return { error: `Section is required for ${classObj.name}` };
    }
    sectionObj = existingSections.find((item) => String(item.name || '').trim().toLowerCase() === sectionLabel.toLowerCase()) || null;
    if (!sectionObj) {
      return { error: `Section not found for ${classObj.name}: ${sectionLabel}` };
    }
  }
  return { classObj, sectionObj };
}

function normalizeEmpty(value) {
  const cleaned = String(value || '').trim();
  return cleaned || '';
}

async function previewStudents({ schoolId, reqScopePhase, csvText, academicYear }) {
  const { rows } = parseCsv(csvText);
  const previewRows = [];
  for (const row of rows) {
    const surname = normalizeEmpty(row.surname);
    const firstName = normalizeEmpty(row.firstName);
    const className = normalizeEmpty(row.className || row.class);
    const sectionName = normalizeEmpty(row.sectionName || row.section);
    const parentName = normalizeEmpty(row.parentName);
    const parentEmail = normalizeEmpty(row.parentEmail);
    const parentPhone = normalizeEmpty(row.parentPhone);
    const admissionYear = normalizeEmpty(row.admissionYear) || String(academicYear || '').trim();
    const errors = [];
    if (!surname) errors.push('surname is required');
    if (!firstName) errors.push('firstName is required');
    if (!className) errors.push('className is required');
    if (!parentName) errors.push('parentName is required');
    if (!parentEmail && !parentPhone) errors.push('parentEmail or parentPhone is required');
    let classId = '';
    let sectionId = '';
    let resolvedClass = null;
    let resolvedSection = null;
    if (!errors.length) {
      const resolved = await resolveClassAndSection({ schoolId, reqScopePhase, className, sectionName });
      if (resolved.error) errors.push(resolved.error);
      else {
        resolvedClass = resolved.classObj;
        resolvedSection = resolved.sectionObj || null;
        classId = String(resolvedClass._id);
        sectionId = resolvedSection ? String(resolvedSection._id) : '';
      }
    }
    previewRows.push({
      rowNumber: row.__rowNumber,
      surname,
      middleName: normalizeEmpty(row.middleName),
      firstName,
      className,
      sectionName,
      parentName,
      parentEmail,
      parentPhone,
      admissionYear,
      classId,
      sectionId,
      resolvedClassName: resolvedClass?.name || '',
      resolvedSectionName: resolvedSection?.name || '',
      errors,
    });
  }
  return previewRows;
}

async function importStudents({ schoolId, reqScopePhase, academicYear, rows }) {
  const results = [];
  for (const row of rows) {
    try {
      const created = await studentsService.registerStudent({
        schoolId,
        reqScopePhase,
        surname: row.surname,
        middleName: row.middleName,
        firstName: row.firstName,
        admissionYear: row.admissionYear || academicYear,
        classId: row.classId,
        sectionId: row.sectionId || undefined,
        academicYear,
        parentName: row.parentName,
        parentEmail: row.parentEmail,
        parentPhone: row.parentPhone,
      });
      results.push({ rowNumber: row.rowNumber, success: true, name: created.student?.name || `${row.surname} ${row.firstName}` });
    } catch (err) {
      results.push({ rowNumber: row.rowNumber, success: false, error: err.message || 'Import failed' });
    }
  }
  return results;
}

async function previewTeachers({ schoolId, reqScopePhase, csvText }) {
  const { rows } = parseCsv(csvText);
  return rows.map((row) => {
    const surname = normalizeEmpty(row.surname);
    const firstName = normalizeEmpty(row.firstName);
    const startYear = normalizeEmpty(row.startYear);
    const phone = normalizeEmpty(row.phone);
    const errors = [];
    if (!surname) errors.push('surname is required');
    if (!firstName) errors.push('firstName is required');
    if (!startYear) errors.push('startYear is required');
    return {
      rowNumber: row.__rowNumber,
      surname,
      middleName: normalizeEmpty(row.middleName),
      firstName,
      phone,
      startYear,
      errors,
    };
  });
}

async function importTeachers({ schoolId, reqScopePhase, rows }) {
  const results = [];
  for (const row of rows) {
    try {
      const created = await teacherService.createTeacher({
        surname: row.surname,
        middleName: row.middleName,
        firstName: row.firstName,
        schoolId,
        startYear: row.startYear,
        phone: row.phone,
        reqScopePhase,
      });
      results.push({ rowNumber: row.rowNumber, success: true, name: created.fullName || `${row.surname} ${row.firstName}` });
    } catch (err) {
      results.push({ rowNumber: row.rowNumber, success: false, error: err.message || 'Import failed' });
    }
  }
  return results;
}

module.exports = {
  parseCsv,
  previewStudents,
  importStudents,
  previewTeachers,
  importTeachers,
};
