const PublishedStudentResult = require('../../models/PublishedStudentResult');
const ResultSnapshot = require('../../models/ResultSnapshot');
const ClassModel = require('../../models/class');

function round1(value) {
  return Math.round((Number(value) || 0) * 10) / 10;
}

function toPercent(part, total) {
  if (!total) return 0;
  return round1((part / total) * 100);
}

function getRangeLabel(avg) {
  const score = Number(avg) || 0;
  if (score >= 70) return 'Strong';
  if (score >= 50) return 'Fair';
  return 'Needs Attention';
}

async function getAnalyticsPageData({ schoolId, academicYear, term, reqScopePhase }) {
  const baseFilter = {
    school: schoolId,
    academicYear: String(academicYear || '').trim(),
    term: String(term || '').trim(),
  };
  if (reqScopePhase) baseFilter.phase = reqScopePhase;

  let source = 'published';
  let documents = await PublishedStudentResult.find(baseFilter)
    .populate('class', 'name level phase order')
    .populate('student', 'name track status')
    .lean();

  if (!documents.length) {
    source = 'snapshot';
    documents = await ResultSnapshot.find(baseFilter)
      .populate('class', 'name level phase order')
      .populate('student', 'name track status')
      .lean();
  }

  const classes = await ClassModel.find(reqScopePhase ? { school: schoolId, phase: reqScopePhase } : { school: schoolId })
    .select('name level phase order')
    .sort({ phase: 1, level: 1, order: 1, name: 1 })
    .lean();

  const schoolSummary = {
    studentsWithResults: documents.length,
    schoolAverage: 0,
    passRate: 0,
    distinctionRate: 0,
    subjectsAnalysed: 0,
    classesCovered: 0,
    source,
  };

  if (!documents.length) {
    return {
      title: 'Academic Analytics',
      academicYear,
      term,
      source,
      schoolSummary,
      classRows: classes.map((klass) => ({
        classId: String(klass._id),
        className: klass.name,
        level: klass.level,
        phase: klass.phase,
        students: 0,
        average: 0,
        passRate: 0,
        distinctionRate: 0,
        band: 'No Results',
        topStudent: '',
      })),
      subjectRows: [],
      topStudents: [],
      attentionStudents: [],
      insights: ['No computed or published results were found yet for the selected academic session and term.'],
    };
  }

  let totalAverage = 0;
  let passCount = 0;
  let distinctionCount = 0;
  const classMap = new Map();
  const subjectMap = new Map();
  const studentRows = [];

  for (const doc of documents) {
    const average = Number(doc.summary?.average || 0);
    totalAverage += average;
    if (average >= 50) passCount += 1;
    if (average >= 70) distinctionCount += 1;

    const classId = String(doc.class?._id || doc.class || '');
    const className = doc.class?.name || 'Unknown Class';
    if (!classMap.has(classId)) {
      classMap.set(classId, {
        classId,
        className,
        level: doc.class?.level || doc.level || '',
        phase: doc.class?.phase || doc.phase || '',
        students: 0,
        totalAverage: 0,
        passCount: 0,
        distinctionCount: 0,
        topStudent: '',
        topAverage: -1,
      });
    }
    const classEntry = classMap.get(classId);
    classEntry.students += 1;
    classEntry.totalAverage += average;
    if (average >= 50) classEntry.passCount += 1;
    if (average >= 70) classEntry.distinctionCount += 1;
    const studentName = doc.studentName || doc.student?.name || 'Student';
    if (average > classEntry.topAverage) {
      classEntry.topAverage = average;
      classEntry.topStudent = studentName;
    }

    studentRows.push({
      studentName,
      className,
      track: doc.track || doc.student?.track || '',
      average: round1(average),
      position: doc.summary?.position || null,
      subjectCount: Number(doc.summary?.subjectCount || (doc.subjects || []).length || 0),
    });

    for (const subject of doc.subjects || []) {
      const key = String(subject.subject || subject.name || 'subject');
      if (!subjectMap.has(key)) {
        subjectMap.set(key, {
          subjectName: subject.name || 'Unnamed Subject',
          code: subject.code || '',
          entries: 0,
          total: 0,
          passCount: 0,
          distinctionCount: 0,
          highest: 0,
          lowest: null,
        });
      }
      const entry = subjectMap.get(key);
      const total = Number(subject.total || 0);
      entry.entries += 1;
      entry.total += total;
      if (total >= 50) entry.passCount += 1;
      if (total >= 70) entry.distinctionCount += 1;
      if (total > entry.highest) entry.highest = total;
      if (entry.lowest === null || total < entry.lowest) entry.lowest = total;
    }
  }

  const classRows = Array.from(classMap.values())
    .map((entry) => ({
      ...entry,
      average: round1(entry.totalAverage / Math.max(entry.students, 1)),
      passRate: toPercent(entry.passCount, entry.students),
      distinctionRate: toPercent(entry.distinctionCount, entry.students),
      band: getRangeLabel(entry.totalAverage / Math.max(entry.students, 1)),
    }))
    .sort((a, b) => b.average - a.average || a.className.localeCompare(b.className));

  const subjectRows = Array.from(subjectMap.values())
    .map((entry) => ({
      ...entry,
      average: round1(entry.total / Math.max(entry.entries, 1)),
      passRate: toPercent(entry.passCount, entry.entries),
      distinctionRate: toPercent(entry.distinctionCount, entry.entries),
      lowest: entry.lowest === null ? 0 : entry.lowest,
      band: getRangeLabel(entry.total / Math.max(entry.entries, 1)),
    }))
    .sort((a, b) => b.average - a.average || a.subjectName.localeCompare(b.subjectName));

  const topStudents = [...studentRows]
    .sort((a, b) => b.average - a.average || (a.position || 9999) - (b.position || 9999) || a.studentName.localeCompare(b.studentName))
    .slice(0, 8);

  const attentionStudents = [...studentRows]
    .filter((item) => item.average < 50)
    .sort((a, b) => a.average - b.average || a.studentName.localeCompare(b.studentName))
    .slice(0, 8);

  schoolSummary.schoolAverage = round1(totalAverage / Math.max(documents.length, 1));
  schoolSummary.passRate = toPercent(passCount, documents.length);
  schoolSummary.distinctionRate = toPercent(distinctionCount, documents.length);
  schoolSummary.subjectsAnalysed = subjectRows.length;
  schoolSummary.classesCovered = classRows.filter((row) => row.students > 0).length;

  const insights = [];
  if (classRows.length) {
    const bestClass = classRows[0];
    const weakestClass = [...classRows].sort((a, b) => a.average - b.average)[0];
    insights.push(`${bestClass.className} is currently the strongest class with an average of ${bestClass.average}%.`);
    if (weakestClass && weakestClass.classId !== bestClass.classId) {
      insights.push(`${weakestClass.className} needs the most support with an average of ${weakestClass.average}%.`);
    }
  }
  if (subjectRows.length) {
    const bestSubject = subjectRows[0];
    const weakestSubject = [...subjectRows].sort((a, b) => a.average - b.average)[0];
    insights.push(`${bestSubject.subjectName} is the best-performing subject overall at ${bestSubject.average}%.`);
    if (weakestSubject && weakestSubject.subjectName !== bestSubject.subjectName) {
      insights.push(`${weakestSubject.subjectName} is the weakest-performing subject and may need intervention.`);
    }
  }
  if (attentionStudents.length) {
    insights.push(`${attentionStudents.length} students on this screen are below the 50% average threshold and need attention.`);
  }

  return {
    title: 'Academic Analytics',
    academicYear,
    term,
    source,
    schoolSummary,
    classRows,
    subjectRows,
    topStudents,
    attentionStudents,
    insights,
  };
}

module.exports = {
  getAnalyticsPageData,
};
