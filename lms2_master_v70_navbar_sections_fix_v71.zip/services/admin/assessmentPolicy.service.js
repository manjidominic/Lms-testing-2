// services/assessmentPolicy.service.js
const AssessmentPolicy = require('../../models/assessmentPolicy');

async function getPolicyForLevel({ schoolId, level, academicYear = null, term = null }) {
  const queries = [
    { school: schoolId, level, academicYear, term },
    { school: schoolId, level, academicYear, term: null },
    { school: schoolId, level, academicYear: null, term: null },
  ];

  for (const q of queries) {
    const policy = await AssessmentPolicy.findOne(q).lean();
    if (policy) return policy;
  }

  const err = new Error(`Assessment policy not set for ${level}. Ask admin to configure it.`);
  err.statusCode = 400;
  throw err;
}

module.exports = { getPolicyForLevel };