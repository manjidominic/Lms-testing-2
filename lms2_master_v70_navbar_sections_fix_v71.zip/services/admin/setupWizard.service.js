const AcademicYear = require('../../models/AcademicYear');
const Term = require('../../models/Term');
const AssessmentPolicy = require('../../models/assessmentPolicy');
const ClassModel = require('../../models/class');
const Subject = require('../../models/Subject');
const Teacher = require('../../models/Teacher');
const Student = require('../../models/Students');
const School = require('../../models/School');

function task(label, href, done, detail, required = true) {
  return { label, href, done: !!done, detail: detail || '', required };
}

function getRequiredLevels({ school, scopePhase }) {
  if (scopePhase === 'Primary') return ['Primary'];
  if (scopePhase === 'Secondary') return ['JSS', 'SSS'];

  const phases = Array.isArray(school?.phases) ? school.phases : [];
  if (phases.length === 1 && phases[0] === 'Primary') return ['Primary'];
  if (phases.length === 1 && phases[0] === 'Secondary') return ['JSS', 'SSS'];
  return ['Primary', 'JSS', 'SSS'];
}

async function getSetupWizardData({ schoolId, scopePhase }) {
  const school = await School.findById(schoolId).lean();
  if (!school) {
    const err = new Error('School not found.');
    err.statusCode = 404;
    throw err;
  }

  const activeYear = await AcademicYear.findOne({ school: schoolId, isActive: true }).lean();
  const activeTerm = activeYear
    ? await Term.findOne({ school: schoolId, academicYear: activeYear._id, isActive: true }).lean()
    : null;

  const requiredLevels = getRequiredLevels({ school, scopePhase });
  const classFilter = { school: schoolId };
  const teacherFilter = { school: schoolId, status: 'Active' };
  const studentFilter = { school: schoolId, status: 'Active' };
  const subjectFilter = { school: schoolId };

  if (scopePhase) {
    classFilter.phase = scopePhase;
    teacherFilter.phase = scopePhase;
    studentFilter.phase = scopePhase;
    if (scopePhase === 'Primary') {
      subjectFilter.level = 'Primary';
    } else {
      subjectFilter.level = { $in: ['JSS', 'SSS'] };
    }
  }

  let policyCount = 0;
  if (activeYear) {
    policyCount = await AssessmentPolicy.countDocuments({
      school: schoolId,
      academicYear: activeYear.name,
      level: { $in: requiredLevels },
    });
  }

  const [classesCount, subjectsCount, teachersCount, studentsCount] = await Promise.all([
    ClassModel.countDocuments(classFilter),
    Subject.countDocuments(subjectFilter),
    Teacher.countDocuments(teacherFilter),
    Student.countDocuments(studentFilter),
  ]);

  const tasks = [
    task('Create and activate academic session', '/admin/academic-years', !!activeYear, activeYear ? `Active session: ${activeYear.name}` : 'No active academic session yet.'),
    task('Activate term', '/admin/terms', !!activeTerm, activeTerm ? `Active term: ${activeTerm.name}` : 'No active term yet.'),
    task('Configure assessment policy', '/admin/assessment-policy', !!activeYear && policyCount >= requiredLevels.length, activeYear ? `${policyCount}/${requiredLevels.length} required policy level(s) configured for ${activeYear.name}.` : 'Create academic session first.'),
    task('Set up classes and sections', '/sections', classesCount > 0, `${classesCount} class(es) available.`),
    task('Set up subjects and assign them to classes', '/admin/subjects', subjectsCount > 0, `${subjectsCount} subject(s) available.`),
    task('Assign form teachers', '/admin/form-teachers', teachersCount > 0, `${teachersCount} active teacher(s) available for assignment.`),
    task('Admit students', '/students', studentsCount > 0, `${studentsCount} active student(s) available.`, false),
  ];

  const requiredTasks = tasks.filter((t) => t.required);
  const completedRequiredTasks = requiredTasks.filter((t) => t.done).length;
  const totalRequiredTasks = requiredTasks.length;
  const progressPercent = totalRequiredTasks ? Math.round((completedRequiredTasks / totalRequiredTasks) * 100) : 0;
  const setupComplete = completedRequiredTasks === totalRequiredTasks;
  const nextPendingTask = tasks.find((t) => t.required && !t.done) || tasks.find((t) => !t.done) || null;
  const setupKey = activeYear?.name || '__no_active_year__';

  return {
    school,
    activeYear,
    activeTerm,
    tasks,
    completedRequiredTasks,
    totalRequiredTasks,
    progressPercent,
    setupComplete,
    nextPendingTask,
    setupKey,
  };
}

function shouldForceWizard(req, setupKey) {
  const seen = req.session?.adminSetupWizard?.seenFor;
  return seen !== setupKey;
}

function markWizardSeen(req, setupKey, skipped = false) {
  req.session.adminSetupWizard = {
    seenFor: setupKey,
    skipped: !!skipped,
    updatedAt: new Date().toISOString(),
  };
}

module.exports = {
  getSetupWizardData,
  shouldForceWizard,
  markWizardSeen,
};
