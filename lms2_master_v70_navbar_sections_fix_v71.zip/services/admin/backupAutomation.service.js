const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');

const School = require('../../models/School');
const BackupSchedule = require('../../models/BackupSchedule');
const { buildFullBackup } = require('./export.service');
const { recordAudit } = require('../security/audit.service');

const BACKUP_ROOT = path.join(process.cwd(), 'storage', 'backups');
let intervalHandle = null;
let sweepRunning = false;

function ensureBackupRoot() {
  fs.mkdirSync(BACKUP_ROOT, { recursive: true });
}

function sanitizeSegment(value) {
  return String(value || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]+/g, '-')
    .replace(/^-+|-+$/g, '') || 'school';
}

function parseTimeOfDay(timeOfDay) {
  const text = String(timeOfDay || '02:00').trim();
  const match = /^(\d{1,2}):(\d{2})$/.exec(text);
  if (!match) return { hours: 2, minutes: 0, normalized: '02:00' };
  const hours = Math.max(0, Math.min(23, Number(match[1])));
  const minutes = Math.max(0, Math.min(59, Number(match[2])));
  return {
    hours,
    minutes,
    normalized: `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`,
  };
}

function addFrequency(date, frequency) {
  const next = new Date(date);
  if (frequency === 'hourly') next.setHours(next.getHours() + 1);
  else if (frequency === 'every_6_hours') next.setHours(next.getHours() + 6);
  else if (frequency === 'every_12_hours') next.setHours(next.getHours() + 12);
  else if (frequency === 'daily') next.setDate(next.getDate() + 1);
  else if (frequency === 'weekly') next.setDate(next.getDate() + 7);
  else if (frequency === 'monthly') next.setMonth(next.getMonth() + 1);
  return next;
}

function computeNextRun(schedule, fromDate = new Date()) {
  const now = new Date(fromDate);
  const frequency = String(schedule.frequency || 'daily');

  if (['hourly', 'every_6_hours', 'every_12_hours'].includes(frequency)) {
    const base = schedule.lastRunAt ? new Date(schedule.lastRunAt) : now;
    const next = addFrequency(base, frequency);
    if (next <= now) return addFrequency(now, frequency);
    return next;
  }

  const { hours, minutes } = parseTimeOfDay(schedule.timeOfDay);
  let candidate = new Date(now);
  candidate.setSeconds(0, 0);
  candidate.setHours(hours, minutes, 0, 0);

  if (frequency === 'daily') {
    if (candidate <= now) candidate.setDate(candidate.getDate() + 1);
    return candidate;
  }

  if (frequency === 'weekly') {
    const desired = Number.isFinite(schedule.dayOfWeek) ? Number(schedule.dayOfWeek) : 0;
    const delta = (desired - candidate.getDay() + 7) % 7;
    candidate.setDate(candidate.getDate() + delta);
    if (candidate <= now) candidate.setDate(candidate.getDate() + 7);
    return candidate;
  }

  const day = Math.max(1, Math.min(28, Number(schedule.dayOfMonth) || 1));
  candidate.setDate(day);
  if (candidate <= now) candidate.setMonth(candidate.getMonth() + 1);
  candidate.setDate(Math.min(day, 28));
  return candidate;
}

async function getOrCreateSchedule(schoolId) {
  let schedule = await BackupSchedule.findOne({ school: schoolId });
  if (!schedule) {
    schedule = await BackupSchedule.create({ school: schoolId, nextRunAt: null });
  }
  return schedule;
}

async function getScheduleForSchool(schoolId) {
  const schedule = await getOrCreateSchedule(schoolId);
  return schedule.toObject();
}

async function saveSchedule({ schoolId, actorAccountId = null, enabled, frequency, timeOfDay, dayOfWeek, dayOfMonth, retentionCount }) {
  const schedule = await getOrCreateSchedule(schoolId);
  schedule.enabled = !!enabled;
  schedule.frequency = frequency;
  schedule.timeOfDay = parseTimeOfDay(timeOfDay).normalized;
  schedule.dayOfWeek = Math.max(0, Math.min(6, Number(dayOfWeek) || 0));
  schedule.dayOfMonth = Math.max(1, Math.min(28, Number(dayOfMonth) || 1));
  schedule.retentionCount = Math.max(1, Math.min(50, Number(retentionCount) || 10));
  schedule.updatedBy = actorAccountId || null;
  schedule.nextRunAt = schedule.enabled ? computeNextRun(schedule, new Date()) : null;
  if (!schedule.enabled) {
    schedule.lastError = '';
    if (schedule.lastStatus === 'running') schedule.lastStatus = 'never';
  }
  await schedule.save();
  return schedule.toObject();
}

async function getSchoolBackupDirBySchool(school) {
  ensureBackupRoot();
  const code = sanitizeSegment(school.code || school._id);
  const dir = path.join(BACKUP_ROOT, code);
  await fsp.mkdir(dir, { recursive: true });
  return dir;
}

function fileTimestamp(date = new Date()) {
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const dd = String(date.getDate()).padStart(2, '0');
  const hh = String(date.getHours()).padStart(2, '0');
  const mi = String(date.getMinutes()).padStart(2, '0');
  const ss = String(date.getSeconds()).padStart(2, '0');
  return `${yyyy}${mm}${dd}-${hh}${mi}${ss}`;
}

async function pruneBackups(dir, retentionCount) {
  const files = (await fsp.readdir(dir)).filter((name) => name.endsWith('.json')).sort().reverse();
  const extras = files.slice(retentionCount);
  for (const file of extras) {
    await fsp.unlink(path.join(dir, file)).catch(() => {});
  }
}

async function runBackupNow({ schoolId, actorAccountId = null, actorRole = '', trigger = 'manual' }) {
  const school = await School.findById(schoolId).lean();
  if (!school) throw new Error('School not found for backup.');
  const schedule = await getOrCreateSchedule(schoolId);
  const dir = await getSchoolBackupDirBySchool(school);
  const payload = await buildFullBackup({ schoolId });
  const fileName = `${sanitizeSegment(school.code)}-${trigger}-${fileTimestamp()}.json`;
  const filePath = path.join(dir, fileName);

  schedule.lastStatus = 'running';
  schedule.lastError = '';
  await schedule.save();

  try {
    await fsp.writeFile(filePath, JSON.stringify(payload, null, 2), 'utf8');
    schedule.lastRunAt = new Date();
    schedule.lastSuccessAt = new Date();
    schedule.lastStatus = 'success';
    schedule.lastFileName = fileName;
    schedule.lastError = '';
    schedule.nextRunAt = schedule.enabled ? computeNextRun(schedule, new Date()) : null;
    await schedule.save();
    await pruneBackups(dir, schedule.retentionCount || 10);

    await recordAudit({
      school: schoolId,
      actorAccount: actorAccountId,
      actorRole: actorRole || '',
      action: trigger === 'scheduled' ? 'BACKUP_AUTOMATED_RUN' : 'BACKUP_MANUAL_RUN',
      category: 'backup',
      targetType: 'School',
      targetId: schoolId,
      message: trigger === 'scheduled' ? 'Automated backup completed.' : 'Manual backup completed.',
      metadata: { fileName, trigger },
    });

    return { fileName, filePath, generatedAt: payload.generatedAt, sizeBytes: Buffer.byteLength(JSON.stringify(payload)) };
  } catch (err) {
    schedule.lastRunAt = new Date();
    schedule.lastStatus = 'failed';
    schedule.lastError = String(err.message || err);
    schedule.nextRunAt = schedule.enabled ? computeNextRun(schedule, new Date()) : null;
    await schedule.save();
    await recordAudit({
      school: schoolId,
      actorAccount: actorAccountId,
      actorRole: actorRole || '',
      action: 'BACKUP_RUN_FAILED',
      category: 'backup',
      targetType: 'School',
      targetId: schoolId,
      message: 'Backup execution failed.',
      metadata: { trigger, error: String(err.message || err) },
    }).catch(() => {});
    throw err;
  }
}

async function listBackupArchives({ schoolId, limit = 20 }) {
  const school = await School.findById(schoolId).lean();
  if (!school) return [];
  const dir = await getSchoolBackupDirBySchool(school);
  const names = (await fsp.readdir(dir).catch(() => [])).filter((name) => name.endsWith('.json')).sort().reverse().slice(0, limit);
  const entries = [];
  for (const name of names) {
    const filePath = path.join(dir, name);
    const stat = await fsp.stat(filePath).catch(() => null);
    if (!stat) continue;
    entries.push({
      fileName: name,
      sizeBytes: stat.size,
      createdAt: stat.birthtime || stat.mtime,
      downloadUrl: `/admin/setup/exports/archives/${encodeURIComponent(name)}`,
      deleteUrl: `/admin/setup/exports/archives/${encodeURIComponent(name)}/delete`,
    });
  }
  return entries;
}

async function getArchivePath({ schoolId, fileName }) {
  if (!/^[a-z0-9._-]+$/i.test(String(fileName || ''))) throw new Error('Invalid backup file name.');
  const school = await School.findById(schoolId).lean();
  if (!school) throw new Error('School not found.');
  const dir = await getSchoolBackupDirBySchool(school);
  const filePath = path.join(dir, fileName);
  if (!filePath.startsWith(dir)) throw new Error('Invalid backup file path.');
  await fsp.access(filePath);
  return filePath;
}

async function deleteArchive({ schoolId, fileName }) {
  const filePath = await getArchivePath({ schoolId, fileName });
  await fsp.unlink(filePath);
  const schedule = await BackupSchedule.findOne({ school: schoolId });
  if (schedule?.lastFileName === fileName) {
    schedule.lastFileName = '';
    await schedule.save();
  }
}

async function sweepDueSchedules() {
  if (sweepRunning) return;
  sweepRunning = true;
  try {
    const now = new Date();
    const due = await BackupSchedule.find({ enabled: true, nextRunAt: { $ne: null, $lte: now } }).select('_id school');
    for (const item of due) {
      try {
        await runBackupNow({ schoolId: item.school, trigger: 'scheduled' });
      } catch (err) {
        // already captured on schedule
      }
    }
  } finally {
    sweepRunning = false;
  }
}

function startBackupScheduler() {
  if (intervalHandle) return intervalHandle;
  ensureBackupRoot();
  intervalHandle = setInterval(() => {
    sweepDueSchedules().catch(() => {});
  }, 60 * 1000);
  if (typeof intervalHandle.unref === 'function') intervalHandle.unref();
  setTimeout(() => {
    sweepDueSchedules().catch(() => {});
  }, 10 * 1000).unref?.();
  return intervalHandle;
}

module.exports = {
  getScheduleForSchool,
  saveSchedule,
  runBackupNow,
  listBackupArchives,
  getArchivePath,
  deleteArchive,
  startBackupScheduler,
};
