const ClassModel = require('../../models/class');
const Student = require('../../models/Students');
const Section = require('../../models/section');
const ResultSnapshot = require('../../models/ResultSnapshot');
const PublishStatus = require('../../models/PublishStatus');
const ClassResultStatus = require('../../models/ClassResultStatus');
const PromotionHistory = require('../../models/PromotionHistory');
const AcademicYear = require('../../models/AcademicYear');
const Term = require('../../models/Term');
const ClassSubject = require('../../models/ClassSubject');
const StudentSubject = require('../../models/StudentSubject');
const academicYearService = require('../academicYears/academicYear.service');

function httpError(message, statusCode = 400) {
  const err = new Error(message);
  err.statusCode = statusCode;
  return err;
}

function parseAcademicYearName(name) {
  const m = String(name || '').match(/^(\d{4})\s*\/\s*(\d{4})$/);
  if (!m) return null;
  return { start: Number(m[1]), end: Number(m[2]) };
}

function buildNextAcademicYearName(currentName) {
  const p = parseAcademicYearName(currentName);
  if (!p) return null;
  return `${p.start + 1}/${p.end + 1}`;
}

async function listPromotionTargetAcademicYearsImpl(schoolId, currentAcademicYearName) {
  const current = parseAcademicYearName(currentAcademicYearName);
  const years = await AcademicYear.find({ school: schoolId })
    .select('_id name isActive')
    .sort({ name: 1 })
    .lean();

  return years
    .filter((year) => {
      if (!year || !year.name || year.name === currentAcademicYearName) return false;
      const parsed = parseAcademicYearName(year.name);
      if (!parsed || !current) return true;
      return parsed.start >= current.start + 1;
    })
    .map((year) => ({
      _id: year._id,
      name: year.name,
      isActive: !!year.isActive,
    }));
}

async function resolvePromotionTargetAcademicYear({ schoolId, currentAcademicYearName, targetAcademicYearId }) {
  let year = null;

  if (targetAcademicYearId) {
    year = await AcademicYear.findOne({
      _id: targetAcademicYearId,
      school: schoolId,
    }).select('_id name isActive');
  } else {
    const nextName = buildNextAcademicYearName(currentAcademicYearName);
    if (nextName) {
      year = await AcademicYear.findOne({ school: schoolId, name: nextName }).select('_id name isActive');
    }
  }

  if (!year) {
    throw httpError('Create the next academic session first, then return here and select it as the promotion target.', 400);
  }

  if (year.name === currentAcademicYearName) {
    throw httpError('Promotion target session cannot be the same as the current academic session.', 400);
  }

  const termsCount = await Term.countDocuments({ school: schoolId, academicYear: year._id });
  if (termsCount < 3) {
    throw httpError('The selected target academic session is incomplete. Create the standard First, Second, and Third Term records before promotion.', 400);
  }

  return year;
}

async function computePromotionOutcome({ schoolId, currentClass }) {
  // ✅ Policy used in your LMS:
  // - Primary final (Primary 6) => Completed (they finish primary; admission into secondary is separate)
  // - JSS final (JSS 3) => Promote to SSS 1 (track required)
  // - SSS final (SSS 3) => Graduated
  // - Others => promote within same level by order

  if (currentClass.level === 'Primary' && currentClass.isFinal) {
    return { action: 'COMPLETE_PRIMARY' };
  }

  if (currentClass.level === 'SSS' && currentClass.isFinal) {
    return { action: 'GRADUATE' };
  }

  if (currentClass.level === 'JSS' && currentClass.isFinal) {
    const next = await ClassModel.findOne({
      school: schoolId,
      level: 'SSS',
      order: 1,
      phase: 'Secondary',
    });
    if (!next) throw httpError('Next class SSS 1 not found. Ensure classes are seeded for SSS.', 404);
    return { action: 'PROMOTE', nextClass: next, requiresTrack: true };
  }

  const next = await ClassModel.findOne({
    school: schoolId,
    level: currentClass.level,
    order: currentClass.order + 1,
    phase: currentClass.phase,
  });

  if (!next) {
    throw httpError(`Next class not found for ${currentClass.name}. Ensure classes are seeded correctly.`, 404);
  }

  const requiresTrack = next.level === 'SSS' && next.order === 1;
  return { action: 'PROMOTE', nextClass: next, requiresTrack };
}

async function requirePublishedAndSubmitted({ schoolId, classId, academicYear, term }) {
  const pub = await PublishStatus.findOne({ school: schoolId, academicYear, term });
  if (!pub || pub.published !== true) {
    throw httpError('Results have not been published yet. Publish results before promoting students.', 403);
  }

  const st = await ClassResultStatus.findOne({ school: schoolId, academicYear, term, class: classId });
  if (!st || (st.status !== 'Submitted' && st.status !== 'Approved')) {
    throw httpError('Class results are not submitted/approved. Submit class results before promotion.', 403);
  }

  const anySnapshot = await ResultSnapshot.findOne({ school: schoolId, academicYear, term, class: classId }).select('_id');
  if (!anySnapshot) {
    throw httpError('No frozen results found for this class. Compute & Freeze results first.', 403);
  }
}

async function autoEnrollBaseSubjectsForSession({ schoolId, studentId, classId, sessionName, studentTrack }) {
  // Remove existing base enrollments for this session (fresh start for the new academic year)
  await StudentSubject.deleteMany({ school: schoolId, student: studentId, session: sessionName, type: 'base' });

  const offerings = await ClassSubject.find({ school: schoolId, class: classId })
    .populate('subject')
    .lean();

  const baseSubjectIds = [];
  for (const off of offerings) {
    const subj = off.subject;
    if (!subj) continue;

    const offeringType = off.offeringType || subj.type || 'CORE';
    if (offeringType === 'ELECTIVE') continue; // electives are not auto-enrolled

    if (offeringType === 'TRACK_CORE') {
      const tracks = Array.isArray(subj.tracks) ? subj.tracks : [];
      if (!studentTrack) continue;
      if (tracks.length > 0 && !tracks.includes(studentTrack)) continue;
    }

    baseSubjectIds.push(String(subj._id));
  }

  if (baseSubjectIds.length === 0) return;

  const docs = baseSubjectIds.map((sid) => ({
    school: schoolId,
    student: studentId,
    subject: sid,
    type: 'base',
    session: sessionName,
  }));

  // Ignore duplicates safely
  try {
    await StudentSubject.insertMany(docs, { ordered: false });
  } catch (e) {
    // Duplicate key errors can happen; ignore
  }
}

async function computeAnnualPerformance({ schoolId, classId, academicYear }) {
  const students = await Student.find({ school: schoolId, class: classId, status: 'Active' })
    .select('_id name track')
    .sort({ name: 1 })
    .lean();

  const terms = ['First Term', 'Second Term', 'Third Term'];
  const snapshots = await ResultSnapshot.find({
    school: schoolId,
    academicYear,
    class: classId,
    term: { $in: terms },
  })
    .select('student term summary.average')
    .lean();

  const byStudent = new Map();
  for (const st of students) {
    byStudent.set(String(st._id), {
      student: st,
      termAvg: { 'First Term': null, 'Second Term': null, 'Third Term': null },
      missingTerms: [],
      overallAvg: null,
      position: null,
    });
  }

  for (const snap of snapshots) {
    const k = String(snap.student);
    if (!byStudent.has(k)) continue;
    byStudent.get(k).termAvg[snap.term] = typeof snap?.summary?.average === 'number' ? snap.summary.average : 0;
  }

  const rows = Array.from(byStudent.values()).map((row) => {
    const avgs = [];
    for (const t of terms) {
      const v = row.termAvg[t];
      if (typeof v === 'number') avgs.push(v);
      else row.missingTerms.push(t);
    }
    if (avgs.length) {
      const sum = avgs.reduce((a, b) => a + b, 0);
      row.overallAvg = Math.round((sum / avgs.length) * 100) / 100;
    } else {
      row.overallAvg = null;
    }
    return row;
  });

  // Sort by overallAvg desc (null last)
  rows.sort((a, b) => {
    const av = a.overallAvg;
    const bv = b.overallAvg;
    if (av === null && bv === null) return a.student.name.localeCompare(b.student.name);
    if (av === null) return 1;
    if (bv === null) return -1;
    if (bv !== av) return bv - av;
    return a.student.name.localeCompare(b.student.name);
  });

  // Assign position (competition ranking)
  let pos = 0;
  let lastAvg = null;
  let rank = 0;
  for (const r of rows) {
    pos += 1;
    if (r.overallAvg === null) {
      r.position = null;
      continue;
    }
    if (lastAvg === null || r.overallAvg !== lastAvg) {
      rank = pos;
      lastAvg = r.overallAvg;
    }
    r.position = rank;
  }


  return { rows, terms };
}

async function validateSelectedStudentsHaveTransferAwareAnnualResults({ schoolId, classId, academicYear, studentIds = [] }) {
  const ids = Array.from(new Set((studentIds || []).map(String).filter(Boolean)));
  if (!ids.length) return;

  const terms = ['First Term', 'Second Term', 'Third Term'];
  const snapshots = await ResultSnapshot.find({
    school: schoolId,
    class: classId,
    academicYear,
    student: { $in: ids },
    term: { $in: terms },
  })
    .select('student term summary.average')
    .lean();

  const byStudent = new Map(ids.map((id) => [String(id), 0]));
  for (const snap of snapshots) {
    const sid = String(snap.student);
    if (!byStudent.has(sid)) continue;
    const hasAverage = typeof snap?.summary?.average === 'number';
    if (hasAverage) byStudent.set(sid, (byStudent.get(sid) || 0) + 1);
  }

  const missingAll = ids.filter((id) => (byStudent.get(String(id)) || 0) === 0);
  if (missingAll.length) {
    throw httpError('One or more selected students do not have any published frozen term result yet. Transfer students can be moved with partial terms, but at least one term result must exist.', 400);
  }
}

module.exports = {
  computeAnnualPerformance,

  async moveStudentsWithSelection({
    schoolId,
    classId,
    promoteIds,
    repeatIds,
    withdrawIds,
    graduateIds,
    completeIds,
    academicYear,
    term,
    actorAccountId,
    trackByStudentId = {},
    noteByStudentId = {},
    targetAcademicYearId = null,
    activateTargetSession = false,
  }) {
    const promoteSet = new Set((Array.isArray(promoteIds) ? promoteIds : promoteIds ? [promoteIds] : []).map(String));
    const repeatSet = new Set((Array.isArray(repeatIds) ? repeatIds : repeatIds ? [repeatIds] : []).map(String));
    const withdrawSet = new Set((Array.isArray(withdrawIds) ? withdrawIds : withdrawIds ? [withdrawIds] : []).map(String));
    const graduateSet = new Set((Array.isArray(graduateIds) ? graduateIds : graduateIds ? [graduateIds] : []).map(String));
    const completeSet = new Set((Array.isArray(completeIds) ? completeIds : completeIds ? [completeIds] : []).map(String));

    if (promoteSet.size === 0 && repeatSet.size === 0 && withdrawSet.size === 0 && graduateSet.size === 0 && completeSet.size === 0) {
      throw httpError('Select at least one student movement decision.', 400);
    }

    const allDecisionSets = [promoteSet, repeatSet, withdrawSet, graduateSet, completeSet];
    const seenDecisionIds = new Set();
    for (const decisionSet of allDecisionSets) {
      for (const id of decisionSet) {
        if (seenDecisionIds.has(id)) {
          throw httpError('A student cannot have more than one movement decision.', 400);
        }
        seenDecisionIds.add(id);
      }
    }

    const currentClass = await ClassModel.findOne({ _id: classId, school: schoolId });
    if (!currentClass) throw httpError('Class not found', 404);

    if (!academicYear || !term) {
      throw httpError('Academic context not set.', 400);
    }

    if (term !== 'Third Term') {
      throw httpError('Promotion is only allowed in Third Term.', 403);
    }

    await requirePublishedAndSubmitted({ schoolId, classId, academicYear, term });

    const allIds = Array.from(new Set([...promoteSet, ...repeatSet, ...withdrawSet, ...graduateSet, ...completeSet]));
    await validateSelectedStudentsHaveTransferAwareAnnualResults({
      schoolId,
      classId,
      academicYear,
      studentIds: allIds,
    });

    const outcome = await computePromotionOutcome({ schoolId, currentClass });

    const requiresTargetAcademicYear = promoteSet.size > 0 || repeatSet.size > 0;
    const targetAcademicYear = requiresTargetAcademicYear
      ? await resolvePromotionTargetAcademicYear({
          schoolId,
          currentAcademicYearName: academicYear,
          targetAcademicYearId,
        })
      : null;
    const nextAcademicYearName = targetAcademicYear?.name || null;
    const students = await Student.find({
      _id: { $in: allIds },
      school: schoolId,
      class: classId,
      status: 'Active',
    }).select('_id name track level');

    if (students.length !== allIds.length) {
      throw httpError('Some selected students are not active or not in this class.', 400);
    }

    const already = await PromotionHistory.findOne({
      school: schoolId,
      academicYearFrom: academicYear,
      student: { $in: allIds },
    }).select('student');
    if (already) {
      throw httpError('One or more selected students have already been moved/promoted for this academic year.', 409);
    }

    const ops = [];
    const historyDocs = [];
    const noteFor = (studentId) => String(noteByStudentId?.[String(studentId)] || noteByStudentId?.[studentId] || '').trim();

    if (graduateSet.size && outcome.action !== 'GRADUATE') {
      throw httpError('Graduate can only be selected for final secondary classes.', 400);
    }
    if (completeSet.size && outcome.action !== 'COMPLETE_PRIMARY') {
      throw httpError('Complete Primary can only be selected for final primary classes.', 400);
    }

    // Repeat: same class, next academic year
    for (const st of students.filter((s) => repeatSet.has(String(s._id)))) {
      ops.push({
        updateOne: {
          filter: { _id: st._id },
          update: { $set: { currentSession: nextAcademicYearName || academicYear, section: null } },
        },
      });
      historyDocs.push({
        school: schoolId,
        student: st._id,
        fromClass: currentClass._id,
        toClass: currentClass._id,
        action: 'REPEAT',
        academicYearFrom: academicYear,
        academicYearTo: nextAcademicYearName || null,
        term,
        performedBy: actorAccountId || null,
        note: noteFor(st._id),
      });
    }

    for (const st of students.filter((s) => withdrawSet.has(String(s._id)))) {
      ops.push({
        updateOne: {
          filter: { _id: st._id },
          update: { $set: { status: 'Withdrawn', section: null, statusAcademicYear: academicYear } },
        },
      });
      historyDocs.push({
        school: schoolId,
        student: st._id,
        fromClass: currentClass._id,
        toClass: null,
        action: 'WITHDRAW',
        academicYearFrom: academicYear,
        academicYearTo: null,
        term,
        performedBy: actorAccountId || null,
        note: noteFor(st._id),
      });
    }

    for (const st of students.filter((s) => graduateSet.has(String(s._id)))) {
      ops.push({
        updateOne: {
          filter: { _id: st._id },
          update: { $set: { status: 'Graduated', section: null, statusAcademicYear: academicYear } },
        },
      });
      historyDocs.push({
        school: schoolId,
        student: st._id,
        fromClass: currentClass._id,
        toClass: null,
        action: 'GRADUATE',
        academicYearFrom: academicYear,
        academicYearTo: null,
        term,
        performedBy: actorAccountId || null,
        note: noteFor(st._id),
      });
    }

    for (const st of students.filter((s) => completeSet.has(String(s._id)))) {
      ops.push({
        updateOne: {
          filter: { _id: st._id },
          update: { $set: { status: 'Completed', section: null, statusAcademicYear: academicYear } },
        },
      });
      historyDocs.push({
        school: schoolId,
        student: st._id,
        fromClass: currentClass._id,
        toClass: null,
        action: 'COMPLETE_PRIMARY',
        academicYearFrom: academicYear,
        academicYearTo: null,
        term,
        performedBy: actorAccountId || null,
        note: noteFor(st._id),
      });
    }

    // Promote group
    const promoteStudents = students.filter((s) => promoteSet.has(String(s._id)));

    if (promoteStudents.length) {
      if (outcome.action === 'GRADUATE') {
        for (const st of promoteStudents) {
          ops.push({
            updateOne: {
              filter: { _id: st._id },
              update: { $set: { status: 'Graduated', section: null, statusAcademicYear: academicYear } },
            },
          });
          historyDocs.push({
            school: schoolId,
            student: st._id,
            fromClass: currentClass._id,
            toClass: null,
            action: 'GRADUATE',
            academicYearFrom: academicYear,
            academicYearTo: null,
            term,
            performedBy: actorAccountId || null,
            note: noteFor(st._id),
          });
        }
      } else if (outcome.action === 'COMPLETE_PRIMARY') {
        for (const st of promoteStudents) {
          ops.push({
            updateOne: {
              filter: { _id: st._id },
              update: { $set: { status: 'Completed', section: null, statusAcademicYear: academicYear } },
            },
          });
          historyDocs.push({
            school: schoolId,
            student: st._id,
            fromClass: currentClass._id,
            toClass: null,
            action: 'COMPLETE_PRIMARY',
            academicYearFrom: academicYear,
            academicYearTo: null,
            term,
            performedBy: actorAccountId || null,
            note: noteFor(st._id),
          });
        }
      } else {
        const nextClass = outcome.nextClass;
        for (const st of promoteStudents) {
          let nextTrack = st.track;
          if (outcome.requiresTrack) {
            const incoming = trackByStudentId[String(st._id)] || trackByStudentId[st._id];
            if (!incoming) {
              throw httpError(`Track is required for ${st.name} when moving to SSS.`, 400);
            }
            nextTrack = incoming;
          }
          ops.push({
            updateOne: {
              filter: { _id: st._id },
              update: {
                $set: {
                  class: nextClass._id,
                  level: nextClass.level,
                  phase: nextClass.phase,
                  section: null,
                  currentSession: nextAcademicYearName || academicYear,
                  track: nextTrack,
                },
              },
            },
          });
          historyDocs.push({
            school: schoolId,
            student: st._id,
            fromClass: currentClass._id,
            toClass: nextClass._id,
            action: 'PROMOTE',
            academicYearFrom: academicYear,
            academicYearTo: nextAcademicYearName || null,
            term,
            performedBy: actorAccountId || null,
            note: noteFor(st._id),
          });
        }
      }
    }

    await Student.bulkWrite(ops);
    await PromotionHistory.insertMany(historyDocs);

    // Auto-enroll base subjects for next academic year for all moved students (promote + repeat)
    const nextSession = nextAcademicYearName || academicYear;
    // re-fetch updated students minimal
    const moved = await Student.find({ _id: { $in: allIds }, school: schoolId }).select('_id class track status');
    for (const st of moved) {
      if (st.status !== 'Active') continue; // graduated/completed
      await autoEnrollBaseSubjectsForSession({
        schoolId,
        studentId: st._id,
        classId: st.class,
        sessionName: nextSession,
        studentTrack: st.track,
      });
    }

    if (activateTargetSession && targetAcademicYear?._id) {
      await academicYearService.activateAcademicYear({
        schoolId,
        academicYearId: targetAcademicYear._id,
      });

      await Term.updateMany(
        { school: schoolId, academicYear: targetAcademicYear._id },
        { $set: { isActive: false } }
      );
      await Term.findOneAndUpdate(
        { school: schoolId, academicYear: targetAcademicYear._id, name: 'First Term' },
        { $set: { isActive: true, isResultOpen: true } },
        { new: true }
      );
    }

    return {
      ok: true,
      targetAcademicYearId: targetAcademicYear?._id || null,
      targetAcademicYearName: nextAcademicYearName || null,
      activatedTargetSession: !!(activateTargetSession && targetAcademicYear?._id),
    };
  },
  async getPromotionPageData({ schoolId, classId, status = 'Active', academicYear = null }) {
    const currentClass = await ClassModel.findOne({ _id: classId, school: schoolId });
    if (!currentClass) throw httpError('Class not found', 404);

    const outcome = await computePromotionOutcome({ schoolId, currentClass });

    const studentQuery = { school: schoolId, class: classId };
    if (status) studentQuery.status = status;

    const students = await Student.find(studentQuery).populate('section').sort({ name: 1 }).lean();
    const sections = await Section.find({ school: schoolId, class: classId }).sort({ name: 1 }).lean();

    let annualRows = [];
    let terms = ['First Term', 'Second Term', 'Third Term'];
    if (academicYear) {
      const perf = await computeAnnualPerformance({ schoolId, classId, academicYear });
      annualRows = perf.rows || [];
      terms = perf.terms || terms;
    }

    const annualRowByStudentId = new Map((annualRows || []).map((row) => [String(row.student._id), row]));
    const studentsWithAnnual = students.map((student) => ({
      ...student,
      annual: annualRowByStudentId.get(String(student._id)) || null,
    }));

    return { currentClass, outcome, students: studentsWithAnnual, sections, annualRows, terms };
  },

  async promoteStudentInClass({
    schoolId,
    classId,
    studentIds,
    academicYear,
    term,
    actorAccountId,
    trackByStudentId = {},
    targetAcademicYearId = null,
  }) {
    if (!Array.isArray(studentIds) || studentIds.length === 0) {
      throw httpError('Select at least one student to promote.', 400);
    }

    const currentClass = await ClassModel.findOne({ _id: classId, school: schoolId });
    if (!currentClass) throw httpError('Class not found', 404);

    if (!academicYear || !term) {
      throw httpError('Academic context not set. Ensure an active academic year and term exist.', 400);
    }

    // ✅ Must follow workflow: freeze + submit + publish
    await requirePublishedAndSubmitted({ schoolId, classId, academicYear, term });

    const outcome = await computePromotionOutcome({ schoolId, currentClass });

    const requiresTargetAcademicYear = promoteSet.size > 0 || repeatSet.size > 0;
    const targetAcademicYear = requiresTargetAcademicYear
      ? await resolvePromotionTargetAcademicYear({
          schoolId,
          currentAcademicYearName: academicYear,
          targetAcademicYearId,
        })
      : null;
    const nextAcademicYearName = targetAcademicYear?.name || null;

    const students = await Student.find({
      _id: { $in: studentIds },
      school: schoolId,
      class: classId,
      status: 'Active',
    }).select('_id name track');

    if (students.length !== studentIds.length) {
      throw httpError('Some selected students are not active or not in this class.', 400);
    }

    // Prevent double promotion in same academic year
    const already = await PromotionHistory.findOne({
      school: schoolId,
      academicYearFrom: academicYear,
      student: { $in: studentIds },
    }).select('student');

    if (already) {
      throw httpError('One or more selected students have already been promoted/completed for this academic year.', 409);
    }

    const ops = [];
    const historyDocs = [];

    if (outcome.action === 'GRADUATE') {
      for (const st of students) {
        ops.push({
          updateOne: {
            filter: { _id: st._id },
            update: { $set: { status: 'Graduated', section: null, statusAcademicYear: academicYear } },
          },
        });

        historyDocs.push({
          school: schoolId,
          student: st._id,
          fromClass: currentClass._id,
          toClass: null,
          action: 'GRADUATE',
          academicYearFrom: academicYear,
          academicYearTo: null,
          term,
          performedBy: actorAccountId || null,
        });
      }
    } else if (outcome.action === 'COMPLETE_PRIMARY') {
      for (const st of students) {
        ops.push({
          updateOne: {
            filter: { _id: st._id },
            update: { $set: { status: 'Completed', section: null, statusAcademicYear: academicYear } },
          },
        });

        historyDocs.push({
          school: schoolId,
          student: st._id,
          fromClass: currentClass._id,
          toClass: null,
          action: 'COMPLETE_PRIMARY',
          academicYearFrom: academicYear,
          academicYearTo: null,
          term,
          performedBy: actorAccountId || null,
        });
      }
    } else {
      const nextClass = outcome.nextClass;

      for (const st of students) {
        let nextTrack = st.track;

        if (outcome.requiresTrack) {
          const incoming = trackByStudentId[String(st._id)] || trackByStudentId[st._id];
          if (!incoming) {
            throw httpError(
              `Track is required for ${st.name} when moving to SSS. Select Science/Art/Commercial/Other.`,
              400
            );
          }
          nextTrack = incoming;
        }

        ops.push({
          updateOne: {
            filter: { _id: st._id },
            update: {
              $set: {
                class: nextClass._id,
                level: nextClass.level,
                phase: nextClass.phase,
                section: null,
                currentSession: nextAcademicYearName || academicYear,
                track: nextTrack,
              },
            },
          },
        });

        historyDocs.push({
          school: schoolId,
          student: st._id,
          fromClass: currentClass._id,
          toClass: nextClass._id,
          action: 'PROMOTE',
          academicYearFrom: academicYear,
          academicYearTo: nextAcademicYearName || null,
          term,
          performedBy: actorAccountId || null,
        });
      }
    }

    await Student.bulkWrite(ops);
    await PromotionHistory.insertMany(historyDocs);

    return { ok: true, action: outcome.action };
  },

  async createSectionForClass({ schoolId, classId, name }) {
    const cls = await ClassModel.findOne({ _id: classId, school: schoolId }).select('_id phase');
    if (!cls) throw httpError('Class not found', 404);

    return Section.create({
      school: schoolId,
      class: classId,
      phase: cls.phase,
      name,
    });
  },

  async listPromotionTargetAcademicYears({ schoolId, currentAcademicYearName }) {
    return listPromotionTargetAcademicYearsImpl(schoolId, currentAcademicYearName);
  },

  async assignSectionToStudent({ schoolId, studentId, sectionId }) {
    const student = await Student.findOne({ _id: studentId, school: schoolId }).select('_id class');
    if (!student) throw httpError('Student not found', 404);

    if (!sectionId || sectionId === 'none') {
      await Student.updateOne({ _id: studentId }, { $set: { section: null } });
      return;
    }

    const sec = await Section.findOne({ _id: sectionId, school: schoolId }).select('_id class');
    if (!sec) throw httpError('Section not found', 404);

    if (String(sec.class) !== String(student.class)) {
      throw httpError('Section does not belong to the same class as the student.', 400);
    }

    await Student.updateOne({ _id: studentId }, { $set: { section: sec._id } });
  },
};
