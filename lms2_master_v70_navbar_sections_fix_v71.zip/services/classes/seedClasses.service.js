const Class = require('../../models/class');

async function seedDefaultClasses({ schoolId, schoolType }) {
  const docs = [];

  if (schoolType === 'primary') {
    for (let i = 1; i <= 6; i++) {
      docs.push({
        school: schoolId,
        phase: 'Primary',          // ✅ add
        name: `Primary ${i}`,
        level: 'Primary',
        order: i,
        isFinal: i === 6,
      });
    }
  } else {
    // secondary (JSS + SSS)
    for (let i = 1; i <= 3; i++) {
      docs.push({
        school: schoolId,
        phase: 'Secondary',        // ✅ add
        name: `JSS ${i}`,
        level: 'JSS',
        order: i,
        isFinal: i === 3,
      });
    }
    for (let i = 1; i <= 3; i++) {
      docs.push({
        school: schoolId,
        phase: 'Secondary',        // ✅ add
        name: `SSS ${i}`,
        level: 'SSS',
        order: i,
        isFinal: i === 3,
        allowTracks: true,
      });
    }
  }

  // ✅ IMPORTANT: use $set so existing docs get phase filled in too
  for (const c of docs) {
    await Class.updateOne(
      { school: c.school, name: c.name },
      { $set: c },
      { upsert: true }
    );
  }

  return docs.length;
}

module.exports = { seedDefaultClasses };