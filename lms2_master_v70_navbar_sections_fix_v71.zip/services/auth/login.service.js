const bcrypt = require('bcrypt');
const Account = require('../../models/Account');
const School = require('../../models/School');

module.exports = async function loginService(payload = {}) {
  const identifier = String(payload.identifier || payload.email || '').trim();
  const password = String(payload.password || '');
  const schoolCode = String(payload.schoolCode || '').trim().toLowerCase();

  if (!identifier || !password) {
    const err = new Error('Username/email and password are required');
    err.statusCode = 400;
    throw err;
  }

  const normalizedIdentifier = identifier.toLowerCase().trim();

  const ownerAttempt = await Account.findOne({
    role: 'owner',
    isActive: true,
    email: normalizedIdentifier,
  });

  if (ownerAttempt) {
    const ownerMatch = await bcrypt.compare(password, ownerAttempt.passwordHash);
    if (!ownerMatch) {
      const err = new Error('Invalid login credentials');
      err.statusCode = 401;
      throw err;
    }
    ownerAttempt.lastLoginAt = new Date();
    await ownerAttempt.save();
    return ownerAttempt;
  }

  if (!schoolCode) {
    const err = new Error('School code is required for school accounts');
    err.statusCode = 400;
    throw err;
  }

  const school = await School.findOne({ code: schoolCode, isActive: true }).select('_id code name');
  if (!school) {
    const err = new Error('Invalid school code');
    err.statusCode = 401;
    throw err;
  }

  const matches = await Account.find({
    school: school._id,
    isActive: true,
    $or: [
      { username: normalizedIdentifier },
      { email: normalizedIdentifier },
    ],
  }).sort({ createdAt: 1 });

  if (!matches.length) {
    const err = new Error('Invalid login credentials');
    err.statusCode = 401;
    throw err;
  }

  if (matches.length > 1) {
    const exactUsername = matches.find((item) => String(item.username || '').toLowerCase() === normalizedIdentifier);
    const exactEmail = matches.find((item) => String(item.email || '').toLowerCase() === normalizedIdentifier);
    const chosen = exactUsername || exactEmail || matches[0];
    const match = await bcrypt.compare(password, chosen.passwordHash);
    if (!match) {
      const err = new Error('Invalid login credentials');
      err.statusCode = 401;
      throw err;
    }
    chosen.lastLoginAt = new Date();
    await chosen.save();
    return chosen;
  }

  const account = matches[0];
  const match = await bcrypt.compare(password, account.passwordHash);
  if (!match) {
    const err = new Error('Invalid login credentials');
    err.statusCode = 401;
    throw err;
  }

  account.lastLoginAt = new Date();
  await account.save();

  return account;
};
