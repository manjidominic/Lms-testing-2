const bcrypt = require('bcrypt');
const School = require('../../models/School');
const Account = require('../../models/Account');

module.exports = async function registerOwnerService(payload = {}) {
  const { schoolCode, email, password } = payload;

  // 1) Validate input (business rule)
  if (!schoolCode || !email || !password) {
    const err = new Error('schoolCode, email and password are required');
    err.statusCode = 400;
    throw err;
  }

  const normalizedCode = schoolCode.toLowerCase().trim();
  const normalizedEmail = email.toLowerCase().trim();

  // 2) Find school (multi-school foundation)
  const school = await School.findOne({ code: normalizedCode }).select('_id');
  if (!school) {
    const err = new Error('School not found. Check school code.');
    err.statusCode = 404;
    throw err;
  }

  // 3) Prevent duplicate owner email inside this school
  const exists = await Account.findOne({
    school: school._id,
    email: normalizedEmail,
  }).select('_id');

  if (exists) {
    const err = new Error('Account already exists for this school');
    err.statusCode = 409;
    throw err;
  }

  // 4) Hash password securely
  // 10 is a good starting cost for bcrypt; you can tune later
  const passwordHash = await bcrypt.hash(password, 10);

  // 5) Create account
  const account = await Account.create({
    school: school._id,
    role: 'owner',
    email: normalizedEmail,
    passwordHash,
  });

  return account;
};