const mongoose = require('mongoose');
const Class = require('../../models/class');
const Section = require('../../models/section');

const School = require('../../models/School');

const PRIMARY_CLASS_LIBRARY = [
  { name: 'Creche', order: -2, isFinal: false },
  { name: 'Nursery 1', order: -1, isFinal: false },
  { name: 'Nursery 2', order: 0, isFinal: false },
  { name: 'Primary 1', order: 1, isFinal: false },
  { name: 'Primary 2', order: 2, isFinal: false },
  { name: 'Primary 3', order: 3, isFinal: false },
  { name: 'Primary 4', order: 4, isFinal: false },
  { name: 'Primary 5', order: 5, isFinal: false },
  { name: 'Primary 6', order: 6, isFinal: true },
];

const DEFAULT_SSS_SECTIONS = ['SCIENCE', 'ART', 'COMMERCIAL'];

async function ensureAutoSectionsForClass({ schoolId, classObj }) {
  if (!classObj || classObj.level !== 'SSS') return;

  const existing = await Section.find({ school: schoolId, class: classObj._id }).select('name').lean();
  const existingNames = new Set(existing.map((item) => String(item.name || '').trim().toUpperCase()));

  const docs = DEFAULT_SSS_SECTIONS
    .filter((name) => !existingNames.has(name))
    .map((name) => ({
      school: schoolId,
      phase: classObj.phase,
      class: classObj._id,
      name,
    }));

  if (docs.length) {
    await Section.insertMany(docs, { ordered: false });
  }
}

async function listClassesForSections({ schoolId, scopePhase = null }) {
  const school = await School.findById(schoolId).select('phases').lean();
  const filter = { school: schoolId };
  if (scopePhase) filter.phase = scopePhase;

  const classes = await Class.find(filter).sort({ level: 1, order: 1, name: 1 }).lean();

  for (const classObj of classes) {
    await ensureAutoSectionsForClass({ schoolId, classObj });
  }

  const sections = await Section.find({ school: schoolId }).lean();

  const countMap = new Map();
  for (const sec of sections) {
    const key = String(sec.class);
    countMap.set(key, (countMap.get(key) || 0) + 1);
  }

  const decorated = classes.map((c) => ({
    ...c,
    sectionsCount: countMap.get(String(c._id)) || 0,
    autoSections: c.level === 'SSS' ? DEFAULT_SSS_SECTIONS : [],
  }));

  const selectedPrimaryClasses = decorated.filter((c) => c.phase === 'Primary').map((c) => c.name);

  const visiblePhases = scopePhase ? [scopePhase] : (Array.isArray(school?.phases) ? school.phases : []);

  return {
    school,
    visiblePhases,
    classes: decorated,
    primaryClassLibrary: PRIMARY_CLASS_LIBRARY,
    selectedPrimaryClasses,
    secondaryClasses: ['JSS 1', 'JSS 2', 'JSS 3', 'SSS 1', 'SSS 2', 'SSS 3'],
  };
}

async function getManageSectionsData({ schoolId, classId }) {
  if (!mongoose.isValidObjectId(classId)) {
    const err = new Error('Invalid class id');
    err.statusCode = 400;
    throw err;
  }

  const classObj = await Class.findOne({ _id: classId, school: schoolId });
  if (!classObj) {
    const err = new Error('Class not found for this school');
    err.statusCode = 404;
    throw err;
  }

  await ensureAutoSectionsForClass({ schoolId, classObj });

  const sections = await Section.find({ school: schoolId, class: classId }).sort({ name: 1 });

  return { classObj, sections };
}

async function createSection({ schoolId, classId, name }) {
  const clean = String(name || '').trim().toUpperCase();
  if (!clean) {
    const err = new Error('Section name is required (e.g. A)');
    err.statusCode = 400;
    throw err;
  }

  const classObj = await Class.findOne({ _id: classId, school: schoolId }).select('phase level');
  if (!classObj) {
    const err = new Error('Class not found for this school');
    err.statusCode = 404;
    throw err;
  }

  await Section.create({
    school: schoolId,
    phase: classObj.phase,
    class: classId,
    name: clean,
  });
}

async function deleteSection({ schoolId, sectionId }) {
  if (!mongoose.isValidObjectId(sectionId)) {
    const err = new Error('Invalid section id');
    err.statusCode = 400;
    throw err;
  }

  const section = await Section.findOne({ _id: sectionId, school: schoolId });
  if (!section) {
    const err = new Error('Section not found');
    err.statusCode = 404;
    throw err;
  }

  const classId = section.class.toString();
  await Section.deleteOne({ _id: sectionId });

  return classId;
}

async function saveSchoolClassSetup({ schoolId, primaryClasses = [] }) {
  const chosen = Array.isArray(primaryClasses) ? primaryClasses : (primaryClasses ? [primaryClasses] : []);
  const chosenSet = new Set(chosen);

  const existingPrimary = await Class.find({ school: schoolId, phase: 'Primary' }).lean();
  const existingMap = new Map(existingPrimary.map((c) => [c.name, c]));

  for (const item of PRIMARY_CLASS_LIBRARY) {
    if (chosenSet.has(item.name) && !existingMap.has(item.name)) {
      await Class.create({
        school: schoolId,
        phase: 'Primary',
        name: item.name,
        level: 'Primary',
        order: item.order,
        isFinal: item.isFinal,
        allowTracks: false,
      });
    }
  }

  for (const existing of existingPrimary) {
    if (!chosenSet.has(existing.name)) {
      const hasStudents = await require('../../models/Students').exists({ school: schoolId, class: existing._id });
      const hasSections = await Section.exists({ school: schoolId, class: existing._id });
      if (!hasStudents && !hasSections) {
        await Class.deleteOne({ _id: existing._id, school: schoolId });
      }
    }
  }
}

module.exports = {
  listClassesForSections,
  getManageSectionsData,
  createSection,
  deleteSection,
  saveSchoolClassSetup,
};
