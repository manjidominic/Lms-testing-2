const ClassResultStatus = require('../../models/ClassResultStatus');
const PublishStatus = require('../../models/PublishStatus');
const ResultSnapshot = require('../../models/ResultSnapshot');
const PublishedStudentResult = require('../../models/PublishedStudentResult');
const FormTeacherAttendance = require('../../models/FormTeacherAttendance');
const Student = require('../../models/Students');
const Score = require('../../models/score');
const Subject = require('../../models/Subject');
const School = require('../../models/School');
const { getSchoolResultTemplateSettings } = require('./template.service');
const { ClassModel, normalizeTermLabel, getTermAliases, buildCurrentSessionStudentQuery } = require('./shared');

const TERM_ORDER = {
  'First Term': 1,
  'Second Term': 2,
  'Third Term': 3,
};

function parseAcademicYearStart(value) {
  const str = String(value || '').trim();
  const match = str.match(/(\d{4})/);
  return match ? Number(match[1]) : 0;
}

function compareSnapshots(a, b) {
  const yearDiff = parseAcademicYearStart(a.academicYear) - parseAcademicYearStart(b.academicYear);
  if (yearDiff !== 0) return yearDiff;
  return (TERM_ORDER[normalizeTermLabel(a.term)] || 99) - (TERM_ORDER[normalizeTermLabel(b.term)] || 99);
}


function getScoreRemark(score) {
  const value = Number(score || 0);
  if (value >= 75) return 'Excellent';
  if (value >= 65) return 'Very Good';
  if (value >= 50) return 'Good';
  if (value >= 40) return 'Fair';
  return 'Needs Improvement';
}

function getOverallRemark(avg) {
  const value = Number(avg || 0);
  if (value >= 75) return 'Excellent performance. Keep it up.';
  if (value >= 65) return 'Very good performance.';
  if (value >= 50) return 'Good performance with room for improvement.';
  if (value >= 40) return 'Fair performance. More effort is needed.';
  return 'Performance below expectation. Immediate support is advised.';
}

function getPrincipalComment(avg) {
  const value = Number(avg || 0);
  if (value >= 75) return 'An outstanding result. Maintain this standard.';
  if (value >= 65) return 'A commendable performance. Aim even higher next term.';
  if (value >= 50) return 'A solid effort. Continue to work consistently.';
  if (value >= 40) return 'There is potential, but stronger focus is required.';
  return 'Please work closely with teachers and parents for improvement.';
}

function getPromotionDecision(avg) {
  return Number(avg || 0) >= 40 ? 'Promoted' : 'Promotion under review';
}
async function getClassResultStatus({ schoolId, academicYear, term, classId }) {
  return ClassResultStatus.findOne({
    school: schoolId,
    academicYear: String(academicYear).trim(),
    term: String(term).trim(),
    class: classId,
  }).lean();
}

async function submitClassResults({ schoolId, academicYear, term, classId, teacherId }) {
  await ClassResultStatus.updateOne(
    {
      school: schoolId,
      academicYear: String(academicYear).trim(),
      term: String(term).trim(),
      class: classId,
    },
    {
      $set: {
        status: 'Submitted',
        submittedBy: teacherId,
        submittedAt: new Date(),
      },
    },
    { upsert: true }
  );
}

async function approveClassResults({ schoolId, academicYear, term, classId, approverAccountId }) {
  await ClassResultStatus.updateOne(
    {
      school: schoolId,
      academicYear: String(academicYear).trim(),
      term: String(term).trim(),
      class: classId,
    },
    {
      $set: {
        status: 'Approved',
        approvedBy: approverAccountId || null,
        approvedAt: new Date(),
      },
      $setOnInsert: {
        submittedAt: new Date(),
      },
    },
    { upsert: true }
  );
}

async function getClassAuditTrail({ schoolId, academicYear, term, classId }) {
  const [statusDoc, publishDoc] = await Promise.all([
    ClassResultStatus.findOne({
      school: schoolId,
      academicYear: String(academicYear).trim(),
      term: String(term).trim(),
      class: classId,
    })
      .populate('submittedBy', 'fullName firstName surname email')
      .populate('approvedBy', 'email role')
      .lean(),
    PublishStatus.findOne({
      school: schoolId,
      academicYear: String(academicYear).trim(),
      term: String(term).trim(),
    })
      .populate('publishedBy', 'email role')
      .lean(),
  ]);

  const items = [];
  if (statusDoc?.submittedAt) {
    items.push({
      key: 'submitted',
      label: 'Submitted by form teacher',
      at: statusDoc.submittedAt,
      actorName:
        statusDoc.submittedBy?.fullName ||
        [statusDoc.submittedBy?.firstName, statusDoc.submittedBy?.surname].filter(Boolean).join(' ') ||
        statusDoc.submittedBy?.email ||
        'Form Teacher',
      actorRole: 'Form Teacher',
    });
  }

  if (statusDoc?.approvedAt) {
    items.push({
      key: 'approved',
      label: 'Approved by admin',
      at: statusDoc.approvedAt,
      actorName: statusDoc.approvedBy?.email || 'Admin',
      actorRole: statusDoc.approvedBy?.role || 'Admin',
    });
  }

  if (publishDoc?.published && publishDoc?.publishedAt) {
    items.push({
      key: 'published',
      label: 'Published to student portal',
      at: publishDoc.publishedAt,
      actorName: publishDoc.publishedBy?.email || 'Admin',
      actorRole: publishDoc.publishedBy?.role || 'Admin',
    });
  }

  items.sort((a, b) => new Date(a.at) - new Date(b.at));
  return items;
}

async function getPublishStatus({ schoolId, academicYear, term }) {
  const doc = await PublishStatus.findOne({
    school: schoolId,
    academicYear: String(academicYear).trim(),
    term: String(term).trim(),
  }).lean();

  return doc || { published: false };
}

function buildPublishedResultKey(academicYear, term) {
  return `${String(academicYear).trim()}::${normalizeTermLabel(term)}`;
}

function normalizeIdentity(value) {
  return String(value || '').trim().toLowerCase();
}

function buildStudentIdentityQuery({ studentId, studentEmail, studentUsername }) {
  if (studentId) return { student: studentId };

  const or = [];
  if (studentEmail) or.push({ studentEmail: normalizeIdentity(studentEmail) });
  if (studentUsername) or.push({ studentUsername: normalizeIdentity(studentUsername) });
  return or.length ? { $or: or } : null;
}

async function findPublishedResultDoc({ schoolId, identityQuery, studentId, session = '', normalizedTerm = '', termAliases = [] }) {
  const basePopulate = (query) => query.populate('student').populate('class').populate('section');

  const publishedAliasList = [...new Set([normalizedTerm, ...termAliases].map((item) => String(item || '').trim()).filter(Boolean))];

  if (studentId && session && publishedAliasList.length) {
    const exactCurrent = await basePopulate(
      PublishedStudentResult.findOne({
        school: schoolId,
        student: studentId,
        academicYear: session,
        term: { $in: publishedAliasList },
      }).sort({ publishedAt: -1, updatedAt: -1, createdAt: -1 })
    ).lean();
    if (exactCurrent) return exactCurrent;
  }

  if (identityQuery && session && publishedAliasList.length) {
    const identityCurrent = await basePopulate(
      PublishedStudentResult.findOne({
        school: schoolId,
        academicYear: session,
        term: { $in: publishedAliasList },
        ...identityQuery,
      }).sort({ publishedAt: -1, updatedAt: -1, createdAt: -1 })
    ).lean();
    if (identityCurrent) return identityCurrent;
  }

  if (studentId) {
    const exactLatest = await basePopulate(
      PublishedStudentResult.findOne({
        school: schoolId,
        student: studentId,
      }).sort({ academicYear: -1, publishedAt: -1, updatedAt: -1, createdAt: -1 })
    ).lean();
    if (exactLatest) return exactLatest;
  }

  if (identityQuery) {
    const identityLatest = await basePopulate(
      PublishedStudentResult.findOne({
        school: schoolId,
        ...identityQuery,
      }).sort({ academicYear: -1, publishedAt: -1, updatedAt: -1, createdAt: -1 })
    ).lean();
    if (identityLatest) return identityLatest;
  }

  return null;
}

async function buildPublishedRecordsForClass({ schoolId, academicYear, normalizedTerm, termAliases, classDoc, publishedAt, publisherAccountId }) {
  const students = await Student.find(
    buildCurrentSessionStudentQuery({
      schoolId,
      classId: classDoc._id,
      session: academicYear,
      sectionId: null,
    })
  )
    .select('name email username class section phase level track')
    .sort({ name: 1 })
    .lean();

  if (!students.length) return [];

  const studentIds = students.map((item) => item._id);
  const scores = await Score.find({
    school: schoolId,
    class: classDoc._id,
    academicYear,
    term: { $in: termAliases },
    student: { $in: studentIds },
  })
    .select('student subject ca1 ca2 test1 test2 exam total grade')
    .lean();

  if (!scores.length) return [];

  const subjectIds = [...new Set(scores.map((item) => String(item.subject)).filter(Boolean))];
  const subjects = await Subject.find({ _id: { $in: subjectIds }, school: schoolId })
    .select('name code')
    .lean();
  const subjectMap = new Map(subjects.map((item) => [String(item._id), item]));

  const attendanceDocs = await FormTeacherAttendance.find({
    school: schoolId,
    academicYear,
    term: { $in: termAliases },
    class: classDoc._id,
    student: { $in: studentIds },
  })
    .select('student class attendanceTotal cleanlinessRating latenessCount teacherComment')
    .lean();
  const attendanceMap = new Map(
    attendanceDocs.map((doc) => [
      String(doc.student),
      {
        attendanceTotal: Number(doc.attendanceTotal || 0),
        cleanlinessRating: doc.cleanlinessRating || '',
        latenessCount: Number(doc.latenessCount || 0),
        teacherComment: doc.teacherComment || '',
      },
    ])
  );

  const scoresByStudent = new Map();
  for (const score of scores) {
    const key = String(score.student);
    if (!scoresByStudent.has(key)) scoresByStudent.set(key, []);
    scoresByStudent.get(key).push(score);
  }

  const rows = students.map((student) => {
    const scoreList = scoresByStudent.get(String(student._id)) || [];
    const resultSubjects = scoreList
      .map((score) => {
        const subject = subjectMap.get(String(score.subject));
        const ca1 = Number(score.ca1 ?? 0) || 0;
        const ca2Base = score.ca2 != null ? Number(score.ca2) : 0;
        const test1 = score.test1 != null ? Number(score.test1) : 0;
        const test2 = score.test2 != null ? Number(score.test2) : 0;
        const ca2 = ca2Base + test1 + test2;
        const exam = Number(score.exam ?? 0) || 0;
        const total = Number(score.total ?? (ca1 + ca2 + exam)) || 0;
        return {
          subject: score.subject,
          name: subject?.name || '',
          code: subject?.code || '',
          ca1,
          ca2,
          exam,
          total,
          grade: score.grade || '',
          remark: getScoreRemark(total),
        };
      })
      .sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));

    const overallTotal = resultSubjects.reduce((sum, item) => sum + Number(item.total || 0), 0);
    const subjectCount = resultSubjects.length;
    const average = subjectCount ? Number((overallTotal / subjectCount).toFixed(2)) : 0;

    return {
      student,
      subjects: resultSubjects,
      summary: {
        total: overallTotal,
        average,
        position: null,
        subjectCount,
      },
      attendance: attendanceMap.get(String(student._id)) || {
        attendanceTotal: 0,
        cleanlinessRating: '',
        latenessCount: 0,
        teacherComment: '',
      },
      overallRemark: getOverallRemark(average),
      principalComment: getPrincipalComment(average),
      promotionDecision: getPromotionDecision(average),
    };
  });

  rows.sort((a, b) => {
    if (b.summary.total !== a.summary.total) return b.summary.total - a.summary.total;
    return String(a.student.name || '').localeCompare(String(b.student.name || ''));
  });

  let lastTotal = null;
  let lastPosition = 0;
  rows.forEach((row, index) => {
    if (lastTotal === null || row.summary.total !== lastTotal) {
      lastPosition = index + 1;
      lastTotal = row.summary.total;
    }
    row.summary.position = lastPosition;
  });

  return rows.map((row) => ({
    school: schoolId,
    schoolName: schoolDoc?.name || '',
    schoolCode: schoolDoc?.code || '',
    academicYear,
    term: normalizedTerm,
    student: row.student._id,
    studentName: row.student.name || '',
    studentEmail: normalizeIdentity(row.student.email),
    studentUsername: normalizeIdentity(row.student.username),
    class: row.student.class || classDoc._id,
    section: row.student.section || null,
    phase: row.student.phase || classDoc.phase,
    level: row.student.level || classDoc.level,
    track: row.student.track || '',
    subjects: row.subjects,
    summary: row.summary,
    attendance: row.attendance,
    overallRemark: row.overallRemark,
    principalComment: row.principalComment,
    promotionDecision: row.promotionDecision,
    template: {
      phase: row.phase || '',
      key: (row.phase === 'Primary' ? templateResolved?.Primary?.key : templateResolved?.Secondary?.key) || '',
      title: (row.phase === 'Primary' ? templateResolved?.Primary?.title : templateResolved?.Secondary?.title) || '',
      sections: (row.phase === 'Primary' ? templateResolved?.Primary?.sections : templateResolved?.Secondary?.sections) || [],
      ratingScale: (row.phase === 'Primary' ? templateResolved?.Primary?.ratingScale : templateResolved?.Secondary?.ratingScale) || 'A-D',
      displayOptions: (row.phase === 'Primary' ? templateResolved?.Primary?.displayOptions : templateResolved?.Secondary?.displayOptions) || {},
      affectiveTraits: [],
      psychomotorTraits: [],
    },
    reportCard: {
      logoUrl: schoolDoc?.reportCardSettings?.logoUrl || '',
      faviconUrl: schoolDoc?.reportCardSettings?.faviconUrl || '',
      address: schoolDoc?.reportCardSettings?.address || '',
      phone: schoolDoc?.reportCardSettings?.phone || '',
      email: schoolDoc?.reportCardSettings?.email || '',
      principalName: schoolDoc?.reportCardSettings?.principalName || '',
      principalTitle: schoolDoc?.reportCardSettings?.principalTitle || '',
      classTeacherTitle: schoolDoc?.reportCardSettings?.classTeacherTitle || '',
      nextTermBegins: schoolDoc?.reportCardSettings?.nextTermBegins || '',
      showLogo: schoolDoc?.reportCardSettings?.showLogo !== false,
    },
    sourceSnapshotId: null,
    publishedAt,
    publishedBy: publisherAccountId || null,
  }));
}

async function createPublishedStudentResults({ schoolId, academicYear, normalizedTerm, termAliases, publisherAccountId, reqScopePhase = null, publishedAt }) {
  const schoolDoc = await School.findById(schoolId).select('name code reportCardSettings resultTemplateSettings resultTemplateConfigs').lean();
  const { resolved: templateResolved } = await getSchoolResultTemplateSettings(schoolId);
  const approvedFilter = {
    school: schoolId,
    academicYear: String(academicYear).trim(),
    term: { $in: termAliases },
    status: 'Approved',
  };

  const approvedStatuses = await ClassResultStatus.find(approvedFilter).select('class').lean();
  const approvedClassIds = [...new Set(approvedStatuses.map((item) => String(item.class)).filter(Boolean))];
  if (!approvedClassIds.length) return 0;

  const classFilter = { _id: { $in: approvedClassIds }, school: schoolId };
  if (reqScopePhase) classFilter.phase = reqScopePhase;
  const classes = await ClassModel.find(classFilter).select('name phase level').lean();
  if (!classes.length) return 0;

  await PublishedStudentResult.deleteMany({
    school: schoolId,
    academicYear: String(academicYear).trim(),
    term: normalizedTerm,
    class: { $in: classes.map((item) => item._id) },
  });

  const docs = [];
  for (const classDoc of classes) {
    const classDocs = await buildPublishedRecordsForClass({
      schoolId,
      academicYear: String(academicYear).trim(),
      normalizedTerm,
      termAliases,
      classDoc,
      publishedAt,
      publisherAccountId,
    });
    docs.push(...classDocs);
  }

  if (!docs.length) return 0;

  const operations = docs.map((doc) => ({
    updateOne: {
      filter: {
        school: doc.school,
        academicYear: doc.academicYear,
        term: doc.term,
        student: doc.student,
      },
      update: { $set: doc },
      upsert: true,
    },
  }));

  await PublishedStudentResult.bulkWrite(operations, { ordered: false });

  const publishedStudentIds = docs.map((doc) => doc.student);
  await ResultSnapshot.updateMany(
    {
      school: schoolId,
      academicYear: String(academicYear).trim(),
      term: { $in: termAliases },
      student: { $in: publishedStudentIds },
    },
    {
      $set: {
        term: normalizedTerm,
        published: true,
        publishedAt,
        publishedBy: publisherAccountId || null,
      },
    }
  );

  return docs.length;
}

async function publishResults({ schoolId, academicYear, term, publisherAccountId, requireAllApproved = true, reqScopePhase = null }) {
  const session = String(academicYear).trim();
  const normalizedTerm = normalizeTermLabel(term);
  const termAliases = getTermAliases(term);

  if (requireAllApproved) {
    const classFilter = { school: schoolId };
    if (reqScopePhase) classFilter.phase = reqScopePhase;

    const classes = await ClassModel.find(classFilter).select('_id').lean();
    const classIds = classes.map((item) => item._id);
    const totalClasses = classIds.length;
    const approvedClasses = await ClassResultStatus.countDocuments({
      school: schoolId,
      academicYear: session,
      term: { $in: termAliases },
      class: { $in: classIds },
      status: 'Approved',
    });

    if (approvedClasses < totalClasses) {
      const err = new Error('Not all classes in the current school setup have been approved yet. Wait for form teacher submission and admin approval for every class in this phase.');
      err.statusCode = 400;
      throw err;
    }
  }

  const publishedAt = new Date();

  const publishedCount = await createPublishedStudentResults({
    schoolId,
    academicYear: session,
    normalizedTerm,
    termAliases,
    publisherAccountId,
    reqScopePhase,
    publishedAt,
  });

  if (!publishedCount) {
    const err = new Error('No approved class results with student scores were found to publish for this session and term. Recompute, approve, and publish the class again.');
    err.statusCode = 400;
    throw err;
  }

  await PublishStatus.updateOne(
    {
      school: schoolId,
      academicYear: session,
      term: normalizedTerm,
    },
    {
      $set: {
        published: true,
        publishedAt,
        publishedBy: publisherAccountId || null,
      },
    },
    { upsert: true }
  );
}

async function getStudentPublishedResult({ schoolId, studentId, academicYear, term, studentEmail = '', studentUsername = '' }) {
  const session = String(academicYear || '').trim();
  const normalizedTerm = normalizeTermLabel(term);
  const termAliases = getTermAliases(term);
  const identityQuery = buildStudentIdentityQuery({ studentId, studentEmail, studentUsername });

  if (!identityQuery) {
    const err = new Error('Student identity could not be resolved for published result lookup');
    err.statusCode = 404;
    throw err;
  }

  let publishStatus = { published: false };
  if (session && normalizedTerm) {
    publishStatus = await getPublishStatus({ schoolId, academicYear: session, term: normalizedTerm });
  }

  let snapshot = await findPublishedResultDoc({
    schoolId,
    identityQuery,
    studentId,
    session,
    normalizedTerm,
    termAliases,
  });

  if (!snapshot && session && termAliases.length && studentId) {
    snapshot = await ResultSnapshot.findOne({
      school: schoolId,
      academicYear: session,
      term: { $in: termAliases },
      published: true,
      student: studentId,
    })
      .populate('student')
      .populate('class')
      .populate('section')
      .sort({ publishedAt: -1, updatedAt: -1, createdAt: -1 })
      .lean();
  }

  if (!snapshot && publishStatus.published) {
    const err = new Error('Published result record was not created for this student. Publish the approved class again.');
    err.statusCode = 404;
    throw err;
  }

  if (!snapshot) {
    const err = new Error('Results have not been published yet');
    err.statusCode = 403;
    throw err;
  }

  return { publishStatus, snapshot };
}

async function getStudentPublishedResultHistory({ schoolId, studentId, studentEmail = '', studentUsername = '' }) {
  const identityQuery = buildStudentIdentityQuery({ studentId, studentEmail, studentUsername });
  if (!identityQuery) return { snapshots: [], grouped: [] };

  const [publishedResults, publishedStatuses, explicitPublishedSnapshots, allSnapshots] = await Promise.all([
    PublishedStudentResult.find({
      school: schoolId,
      ...identityQuery,
    })
      .populate('student')
      .populate('class')
      .populate('section')
      .lean(),
    PublishStatus.find({
      school: schoolId,
      published: true,
    })
      .select('academicYear term published publishedAt')
      .lean(),
    studentId
      ? ResultSnapshot.find({
          school: schoolId,
          student: studentId,
          published: true,
        })
          .populate('student')
          .populate('class')
          .populate('section')
          .lean()
      : Promise.resolve([]),
    studentId
      ? ResultSnapshot.find({
          school: schoolId,
          student: studentId,
        })
          .populate('student')
          .populate('class')
          .populate('section')
          .lean()
      : Promise.resolve([]),
  ]);

  const deduped = new Map();

  for (const result of publishedResults) {
    deduped.set(buildPublishedResultKey(result.academicYear, result.term), result);
  }

  const publishedKeySet = new Set(
    publishedStatuses.map((item) => buildPublishedResultKey(item.academicYear, item.term))
  );

  const explicitKeys = new Set(
    explicitPublishedSnapshots.map((snapshot) => buildPublishedResultKey(snapshot.academicYear, snapshot.term))
  );

  const fallbackSnapshots = allSnapshots.filter((snapshot) => {
    const key = buildPublishedResultKey(snapshot.academicYear, snapshot.term);
    return publishedKeySet.has(key) && !explicitKeys.has(key) && !deduped.has(key);
  });

  for (const snapshot of [...explicitPublishedSnapshots, ...fallbackSnapshots]) {
    const key = buildPublishedResultKey(snapshot.academicYear, snapshot.term);
    if (deduped.has(key)) continue;
    deduped.set(key, snapshot);
  }

  const filtered = Array.from(deduped.values()).sort(compareSnapshots);

  const groupedMap = new Map();
  for (const snapshot of filtered) {
    const year = String(snapshot.academicYear).trim();
    if (!groupedMap.has(year)) groupedMap.set(year, []);
    groupedMap.get(year).push(snapshot);
  }

  const grouped = Array.from(groupedMap.entries()).map(([academicYear, items]) => ({
    academicYear,
    snapshots: items.sort(compareSnapshots),
  }));

  return { snapshots: filtered, grouped };
}

module.exports = {
  getClassResultStatus,
  submitClassResults,
  approveClassResults,
  getPublishStatus,
  getClassAuditTrail,
  publishResults,
  getStudentPublishedResult,
  getStudentPublishedResultHistory,
};
