const Student = require('../../models/Students');
const Score = require('../../models/score');
const Subject = require('../../models/Subject');
const ResultSnapshot = require('../../models/ResultSnapshot');
const PublishedStudentResult = require('../../models/PublishedStudentResult');
const ClassResultStatus = require('../../models/ClassResultStatus');
const { ClassModel, buildCurrentSessionStudentQuery, normalizeTermLabel, getTermAliases } = require('./shared');
const { computeClassTermBroadsheet } = require('./broadsheet.service');

async function computeAndFreezeClassTermResults({
  schoolId,
  classId,
  academicYear,
  term,
  reqScopePhase,
}) {
  const session = String(academicYear).trim();
  const currentTerm = normalizeTermLabel(term);
  const termAliases = getTermAliases(term);

  const broadsheet = await computeClassTermBroadsheet({
    schoolId,
    classId,
    academicYear: session,
    term: currentTerm,
    reqScopePhase,
    sectionId: null,
  });

  const cls = await ClassModel.findOne({ _id: classId, school: schoolId })
    .select('phase level')
    .lean();

  const students = await Student.find(
    buildCurrentSessionStudentQuery({
      schoolId,
      classId,
      session,
      sectionId: null,
    })
  )
    .select('name class section phase level track')
    .lean();

  const studentIds = students.map((student) => student._id);

  await PublishedStudentResult.deleteMany({
    school: schoolId,
    academicYear: session,
    term: { $in: termAliases },
    class: classId,
  });

  await ResultSnapshot.updateMany(
    {
      school: schoolId,
      academicYear: session,
      term: { $in: termAliases },
      class: classId,
    },
    {
      $set: {
        published: false,
        publishedAt: null,
        publishedBy: null,
      },
    }
  );

  if (!studentIds.length) {
    await ClassResultStatus.updateOne(
      {
        school: schoolId,
        academicYear: session,
        term: currentTerm,
        class: classId,
      },
      {
        $set: {
          status: 'Draft',
          submittedBy: null,
          submittedAt: null,
          approvedBy: null,
          approvedAt: null,
        },
      },
      { upsert: true }
    );

    return broadsheet;
  }

  const scores = await Score.find({
    school: schoolId,
    class: classId,
    academicYear: session,
    term: currentTerm,
    student: { $in: studentIds },
  })
    .select('student subject ca1 ca2 test1 test2 exam total grade remark')
    .lean();

  const subjectIds = [...new Set(scores.map((score) => String(score.subject)).filter(Boolean))];
  const subjectDocs = await Subject.find({ _id: { $in: subjectIds }, school: schoolId })
    .select('name code')
    .lean();
  const subjectMap = new Map(subjectDocs.map((subject) => [String(subject._id), subject]));

  const scoresByStudent = new Map();
  for (const score of scores) {
    const studentKey = String(score.student);
    if (!scoresByStudent.has(studentKey)) scoresByStudent.set(studentKey, []);
    scoresByStudent.get(studentKey).push(score);
  }

  const positionMap = new Map();
  for (const row of broadsheet.rows) {
    positionMap.set(String(row.studentId), {
      total: row.overallTotal,
      average: row.average,
      position: row.position,
      subjectCount: row.subjectCount,
    });
  }

  const operations = [];
  for (const student of students) {
    const scoreList = scoresByStudent.get(String(student._id)) || [];
    const subjects = scoreList
      .map((score) => {
        const subject = subjectMap.get(String(score.subject));
        return {
          subject: score.subject,
          name: subject?.name,
          code: subject?.code,
          ca1: score.ca1 ?? 0,
          ca2: score.ca2 ?? 0,
          exam: score.exam ?? 0,
          total: score.total ?? 0,
          grade: score.grade || '',
          remark: score.remark || '',
        };
      })
      .sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));

    const summary = positionMap.get(String(student._id)) || {
      total: 0,
      average: 0,
      position: null,
      subjectCount: 0,
    };

    operations.push({
      updateOne: {
        filter: {
          school: schoolId,
          academicYear: session,
          term: currentTerm,
          student: student._id,
        },
        update: {
          $set: {
            class: student.class,
            section: student.section || null,
            phase: student.phase || cls?.phase || 'Primary',
            level: student.level || cls?.level || 'Primary',
            track: student.track || null,
            subjects,
            summary: {
              total: summary.total,
              average: summary.average,
              position: summary.position,
              subjectCount: summary.subjectCount,
            },
            published: false,
            publishedAt: null,
            publishedBy: null,
            computedAt: new Date(),
          },
        },
        upsert: true,
      },
    });
  }

  if (operations.length) {
    await ResultSnapshot.bulkWrite(operations, { ordered: false });
  }

  await ClassResultStatus.updateOne(
    {
      school: schoolId,
      academicYear: session,
      term: currentTerm,
      class: classId,
    },
    {
      $set: {
        status: 'Draft',
        submittedBy: null,
        submittedAt: null,
        approvedBy: null,
        approvedAt: null,
      },
    },
    { upsert: true }
  );

  return broadsheet;
}

module.exports = {
  computeAndFreezeClassTermResults,
};
