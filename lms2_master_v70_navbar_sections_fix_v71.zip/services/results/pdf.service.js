const PDFDocument = require('pdfkit');

function safe(v, fallback = '-') {
  if (v === null || v === undefined || v === '') return fallback;
  return String(v);
}

function drawLabelValue(doc, x, y, label, value, width) {
  doc.font('Helvetica-Bold').fontSize(9).fillColor('#6b7280').text(label, x, y, { width });
  doc.font('Helvetica').fontSize(10).fillColor('#111827').text(safe(value), x, y + 12, { width });
}

function drawBox(doc, x, y, width, height, label, value) {
  doc.roundedRect(x, y, width, height, 8).fillAndStroke('#f8fafc', '#cbd5e1');
  doc.fillColor('#64748b').font('Helvetica-Bold').fontSize(8).text(label.toUpperCase(), x + 8, y + 8, { width: width - 16 });
  doc.fillColor('#0f172a').font('Helvetica-Bold').fontSize(12).text(safe(value), x + 8, y + 22, { width: width - 16 });
}

function schoolInitials(name) {
  return safe(name, 'School').split(' ').map((w) => w[0]).filter(Boolean).slice(0, 2).join('').toUpperCase();
}

function drawHeader(doc, item, margin, pageWidth) {
  const headerTop = margin;
  doc.lineWidth(2).strokeColor('#1d4ed8');
  doc.moveTo(margin, headerTop + 82).lineTo(pageWidth - margin, headerTop + 82).stroke();
  doc.roundedRect(margin, headerTop, 56, 56, 10).fillAndStroke('#eff6ff', '#93c5fd');
  doc.fillColor('#1d4ed8').font('Helvetica-Bold').fontSize(20).text(schoolInitials(item.schoolName), margin, headerTop + 16, { width: 56, align: 'center' });
  const infoX = margin + 70;
  doc.fillColor('#0f172a').font('Helvetica-Bold').fontSize(18).text(safe(item.schoolName, 'School Result'), infoX, headerTop + 2, { width: 290 });
  let lineY = headerTop + 24;
  if (item.reportCard?.address) {
    doc.fillColor('#475569').font('Helvetica').fontSize(9).text(item.reportCard.address, infoX, lineY, { width: 290 });
    lineY += 12;
  }
  const contact = [item.reportCard?.phone, item.reportCard?.email].filter(Boolean).join(' • ');
  if (contact) {
    doc.fillColor('#475569').font('Helvetica').fontSize(9).text(contact, infoX, lineY, { width: 290 });
  }
  doc.fillColor('#0f172a').font('Helvetica-Bold').fontSize(12).text('STUDENT RESULT SHEET', pageWidth - margin - 170, headerTop + 6, { width: 170, align: 'right' });
  doc.fillColor('#334155').font('Helvetica').fontSize(10).text(`Session: ${safe(item.academicYear)}`, pageWidth - margin - 170, headerTop + 28, { width: 170, align: 'right' });
  doc.text(`Term: ${safe(item.term)}`, pageWidth - margin - 170, headerTop + 42, { width: 170, align: 'right' });
  return headerTop + 95;
}

function ensurePage(doc, currentY, neededHeight, margin, bottomMargin) {
  if (currentY + neededHeight <= doc.page.height - bottomMargin) return currentY;
  doc.addPage();
  return margin;
}

function drawResultTable(doc, item, startY, margin, pageWidth, bottomMargin) {
  const cols = [
    { key: 'subject', label: 'Subject', width: 180, align: 'left' },
    { key: 'ca1', label: 'CA1', width: 42, align: 'center' },
    { key: 'ca2', label: 'CA2', width: 42, align: 'center' },
    { key: 'exam', label: 'Exam', width: 48, align: 'center' },
    { key: 'total', label: 'Total', width: 48, align: 'center' },
    { key: 'grade', label: 'Grade', width: 44, align: 'center' },
    { key: 'remark', label: 'Remark', width: pageWidth - (margin * 2) - (180 + 42 + 42 + 48 + 48 + 44), align: 'left' },
  ];
  let y = startY;
  const headerH = 24;
  const rowH = 22;

  function drawTableHeader() {
    let x = margin;
    doc.fillColor('#e8eef8').strokeColor('#cbd5e1');
    doc.rect(margin, y, pageWidth - (margin * 2), headerH).fillAndStroke('#e8eef8', '#cbd5e1');
    cols.forEach((c) => {
      doc.fillColor('#0f172a').font('Helvetica-Bold').fontSize(9).text(c.label, x + 4, y + 7, { width: c.width - 8, align: c.align });
      x += c.width;
    });
    y += headerH;
  }

  drawTableHeader();
  (item.subjects || []).forEach((s, idx) => {
    y = ensurePage(doc, y, rowH + 10, margin, bottomMargin);
    if (y === margin) {
      y = drawHeader(doc, item, margin, pageWidth);
      drawTableHeader();
    }
    const fill = idx % 2 === 0 ? '#ffffff' : '#f8fafc';
    doc.rect(margin, y, pageWidth - (margin * 2), rowH).fillAndStroke(fill, '#e2e8f0');
    let x = margin;
    const subjectText = s.code ? `${s.code} - ${s.name}` : safe(s.name);
    const values = {
      subject: subjectText,
      ca1: s.ca1,
      ca2: s.ca2,
      exam: s.exam,
      total: s.total,
      grade: s.grade,
      remark: s.remark,
    };
    cols.forEach((c) => {
      doc.fillColor('#111827').font(c.key === 'total' ? 'Helvetica-Bold' : 'Helvetica').fontSize(9).text(safe(values[c.key]), x + 4, y + 7, { width: c.width - 8, align: c.align, ellipsis: true });
      x += c.width;
    });
    y += rowH;
  });
  return y;
}

function renderSnapshotPage(doc, item, index) {
  if (index > 0) doc.addPage();
  const margin = 40;
  const pageWidth = doc.page.width;
  const bottomMargin = 50;
  let y = drawHeader(doc, item, margin, pageWidth);

  const boxW = (pageWidth - (margin * 2) - 20) / 3;
  const metaRows = [
    ['Student name', item.studentName || item.student?.name || ''],
    ['Class', item.class?.name || ''],
    ['Section', item.section?.name || ''],
    ['Level', item.level || ''],
    ['Track', item.track || ''],
    ['Published', item.publishedAt ? new Date(item.publishedAt).toLocaleDateString() : ''],
  ];
  for (let i = 0; i < metaRows.length; i += 3) {
    const row = metaRows.slice(i, i + 3);
    row.forEach((entry, idx) => {
      drawBox(doc, margin + (idx * (boxW + 10)), y, boxW, 42, entry[0], entry[1]);
    });
    y += 52;
  }

  y += 4;
  y = drawResultTable(doc, item, y, margin, pageWidth, bottomMargin);
  y += 14;

  const summaryW = (pageWidth - (margin * 2) - 25) / 6;
  const summaries = [
    ['Total', item.summary?.total],
    ['Average', item.summary?.average],
    ['Position', item.summary?.position],
    ['Subjects', item.summary?.subjectCount],
    ['Attendance', item.attendance?.attendanceTotal],
    ['Decision', item.promotionDecision],
  ];
  summaries.forEach((entry, idx) => {
    drawBox(doc, margin + (idx * (summaryW + 5)), y, summaryW, 42, entry[0], entry[1]);
  });
  y += 56;

  y = ensurePage(doc, y, 120, margin, bottomMargin);
  if (y === margin) y = drawHeader(doc, item, margin, pageWidth);

  const commentW = (pageWidth - (margin * 2) - 12) / 2;
  doc.roundedRect(margin, y, commentW, 72, 8).fillAndStroke('#ffffff', '#cbd5e1');
  doc.font('Helvetica-Bold').fontSize(10).fillColor('#0f172a').text(`${safe(item.reportCard?.classTeacherTitle, 'Class Teacher')} Comment`, margin + 8, y + 8);
  doc.font('Helvetica').fontSize(9).fillColor('#334155').text(safe(item.attendance?.teacherComment || item.overallRemark), margin + 8, y + 24, { width: commentW - 16, height: 40 });

  doc.roundedRect(margin + commentW + 12, y, commentW, 72, 8).fillAndStroke('#ffffff', '#cbd5e1');
  doc.font('Helvetica-Bold').fontSize(10).fillColor('#0f172a').text(`${safe(item.reportCard?.principalTitle, 'Principal')} Comment`, margin + commentW + 20, y + 8);
  doc.font('Helvetica').fontSize(9).fillColor('#334155').text(safe(item.principalComment), margin + commentW + 20, y + 24, { width: commentW - 16, height: 40 });
  y += 84;

  const extraW = (pageWidth - (margin * 2) - 20) / 3;
  drawBox(doc, margin, y, extraW, 42, 'Next term begins', item.reportCard?.nextTermBegins);
  drawBox(doc, margin + extraW + 10, y, extraW, 42, 'Cleanliness', item.attendance?.cleanlinessRating);
  drawBox(doc, margin + (extraW * 2) + 20, y, extraW, 42, 'Lateness', item.attendance?.latenessCount);
  y += 58;

  doc.moveTo(margin, y + 28).lineTo(margin + 170, y + 28).strokeColor('#334155').stroke();
  doc.font('Helvetica').fontSize(9).fillColor('#334155').text(`${safe(item.reportCard?.classTeacherTitle, 'Class Teacher')} Signature`, margin, y + 32, { width: 170, align: 'center' });
  doc.moveTo(pageWidth - margin - 170, y + 28).lineTo(pageWidth - margin, y + 28).strokeColor('#334155').stroke();
  doc.font('Helvetica').fontSize(9).fillColor('#334155').text(safe(item.reportCard?.principalName || item.reportCard?.principalTitle, 'Principal'), pageWidth - margin - 170, y + 32, { width: 170, align: 'center' });
}

function buildDownloadName(base, extension = 'pdf') {
  return String(base || 'result').toLowerCase().replace(/[^a-z0-9_-]+/gi, '_').replace(/^_+|_+$/g, '') + `.${extension}`;
}

function streamResultPdf(res, { title = 'Student Result', snapshots = [], downloadName = 'student_result' }) {
  const doc = new PDFDocument({ size: 'A4', margin: 40, bufferPages: true });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="${buildDownloadName(downloadName)}"`);
  doc.pipe(res);

  if (!snapshots.length) {
    doc.font('Helvetica-Bold').fontSize(18).text(title, 40, 40);
    doc.moveDown();
    doc.font('Helvetica').fontSize(11).text('No published result found.');
  } else {
    snapshots.forEach((item, index) => renderSnapshotPage(doc, item, index));
  }

  doc.end();
}

module.exports = { streamResultPdf };
