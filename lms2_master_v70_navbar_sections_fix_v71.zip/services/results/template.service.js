
const School = require('../../models/School');

const SECTION_OPTIONS = [
  { key: 'academic', label: 'Academic Scores' },
  { key: 'attendance', label: 'Attendance' },
  { key: 'affective', label: 'Affective Traits' },
  { key: 'psychomotor', label: 'Psychomotor Traits' },
  { key: 'summary', label: 'Summary' },
  { key: 'comments', label: 'Comments' },
];

const RATING_SCALES = {
  'A-D': {
    key: 'A-D',
    title: 'A - D',
    options: ['A', 'B', 'C', 'D'],
    legend: {
      A: 'Excellent',
      B: 'Very Good',
      C: 'Good',
      D: 'Fair',
    },
  },
  '1-5': {
    key: '1-5',
    title: '1 - 5',
    options: ['5', '4', '3', '2', '1'],
    legend: {
      '5': 'Excellent',
      '4': 'Very Good',
      '3': 'Good',
      '2': 'Fair',
      '1': 'Needs Improvement',
    },
  },
  'E-P': {
    key: 'E-P',
    title: 'Excellent to Poor',
    options: ['E', 'VG', 'G', 'F', 'P'],
    legend: {
      E: 'Excellent',
      VG: 'Very Good',
      G: 'Good',
      F: 'Fair',
      P: 'Poor',
    },
  },
};

const RESULT_TEMPLATES = {
  secondary_standard: {
    key: 'secondary_standard',
    title: 'Standard Secondary',
    phases: ['Secondary'],
    description: 'Academic subjects, attendance, summary, and comments.',
    sections: ['academic', 'attendance', 'summary', 'comments'],
    affectiveTraits: [],
    psychomotorTraits: [],
    ratingScale: 'A-D',
    displayOptions: {
      showPosition: true,
      showAverage: true,
      showAttendance: true,
      showComments: true,
    },
  },
  primary_plus_traits: {
    key: 'primary_plus_traits',
    title: 'Primary With Traits',
    phases: ['Primary'],
    description: 'Academic subjects with affective and psychomotor ratings.',
    sections: ['academic', 'attendance', 'affective', 'psychomotor', 'summary', 'comments'],
    affectiveTraits: [
      { key: 'punctuality', label: 'Punctuality' },
      { key: 'cleanliness', label: 'Cleanliness' },
      { key: 'communication', label: 'Communication' },
      { key: 'attentiveness', label: 'Attentiveness' },
      { key: 'honesty', label: 'Honesty' },
      { key: 'cooperation', label: 'Cooperation' },
    ],
    psychomotorTraits: [
      { key: 'handwriting', label: 'Handwriting' },
      { key: 'sports', label: 'Sports' },
      { key: 'drawing', label: 'Drawing' },
      { key: 'craft', label: 'Craft' },
    ],
    ratingScale: 'A-D',
    displayOptions: {
      showPosition: true,
      showAverage: true,
      showAttendance: true,
      showComments: true,
    },
  },
  nursery_skills: {
    key: 'nursery_skills',
    title: 'Nursery / Early Years',
    phases: ['Primary'],
    description: 'Skills-focused report for nursery and early years classes.',
    sections: ['academic', 'attendance', 'affective', 'psychomotor', 'summary', 'comments'],
    affectiveTraits: [
      { key: 'punctuality', label: 'Punctuality' },
      { key: 'cleanliness', label: 'Cleanliness' },
      { key: 'communication', label: 'Communication' },
      { key: 'cooperation', label: 'Cooperation' },
    ],
    psychomotorTraits: [
      { key: 'handwriting', label: 'Handwriting' },
      { key: 'colouring', label: 'Colouring' },
      { key: 'craft', label: 'Craft' },
      { key: 'musicRhythm', label: 'Music / Rhythm' },
    ],
    ratingScale: 'A-D',
    displayOptions: {
      showPosition: true,
      showAverage: true,
      showAttendance: true,
      showComments: true,
    },
  },
};

function getTemplateByKey(key) {
  return RESULT_TEMPLATES[key] || RESULT_TEMPLATES.secondary_standard;
}

function getTemplatesForPhase(phase) {
  const phaseLabel = String(phase || '').trim();
  return Object.values(RESULT_TEMPLATES).filter((tpl) => tpl.phases.includes(phaseLabel));
}

function getRatingScale(key) {
  return RATING_SCALES[key] || RATING_SCALES['A-D'];
}

function applyPhaseConfig(baseTemplate, phaseConfig = {}) {
  const enabledSections = Array.isArray(phaseConfig.enabledSections) && phaseConfig.enabledSections.length
    ? baseTemplate.sections.filter((section) => phaseConfig.enabledSections.includes(section))
    : [...baseTemplate.sections];

  const affectiveTraitKeys = Array.isArray(phaseConfig.affectiveTraitKeys) && phaseConfig.affectiveTraitKeys.length
    ? phaseConfig.affectiveTraitKeys
    : baseTemplate.affectiveTraits.map((item) => item.key);

  const psychomotorTraitKeys = Array.isArray(phaseConfig.psychomotorTraitKeys) && phaseConfig.psychomotorTraitKeys.length
    ? phaseConfig.psychomotorTraitKeys
    : baseTemplate.psychomotorTraits.map((item) => item.key);

  const affectiveTraits = baseTemplate.affectiveTraits.filter((item) => affectiveTraitKeys.includes(item.key));
  const psychomotorTraits = baseTemplate.psychomotorTraits.filter((item) => psychomotorTraitKeys.includes(item.key));
  const ratingScale = getRatingScale(phaseConfig.ratingScale || baseTemplate.ratingScale);

  return {
    ...baseTemplate,
    sections: enabledSections,
    affectiveTraits,
    psychomotorTraits,
    ratingScale: ratingScale.key,
    ratingScaleInfo: ratingScale,
    displayOptions: {
      ...baseTemplate.displayOptions,
      showPosition: phaseConfig.showPosition !== undefined ? Boolean(phaseConfig.showPosition) : Boolean(baseTemplate.displayOptions?.showPosition),
      showAverage: phaseConfig.showAverage !== undefined ? Boolean(phaseConfig.showAverage) : Boolean(baseTemplate.displayOptions?.showAverage),
      showAttendance: phaseConfig.showAttendance !== undefined ? Boolean(phaseConfig.showAttendance) : Boolean(baseTemplate.displayOptions?.showAttendance),
      showComments: phaseConfig.showComments !== undefined ? Boolean(phaseConfig.showComments) : Boolean(baseTemplate.displayOptions?.showComments),
    },
  };
}

function normalizeBoolean(value) {
  return value === true || value === 'true' || value === '1' || value == 1 || value === 'on';
}

function buildPhaseConfigFromRequest({ body, phase, templateKey }) {
  const prefix = String(phase || '').trim().toLowerCase();
  const baseTemplate = getTemplateByKey(templateKey);
  const sectionValues = body[`${prefix}Sections`] || [];
  const affectiveValues = body[`${prefix}AffectiveTraits`] || [];
  const psychomotorValues = body[`${prefix}PsychomotorTraits`] || [];
  const ratingScale = String(body[`${prefix}RatingScale`] || baseTemplate.ratingScale || 'A-D').trim();

  const sections = (Array.isArray(sectionValues) ? sectionValues : [sectionValues]).filter(Boolean);
  const affectiveTraitKeys = (Array.isArray(affectiveValues) ? affectiveValues : [affectiveValues]).filter(Boolean);
  const psychomotorTraitKeys = (Array.isArray(psychomotorValues) ? psychomotorValues : [psychomotorValues]).filter(Boolean);

  return {
    templateKey,
    enabledSections: baseTemplate.sections.filter((item) => sections.includes(item)),
    affectiveTraitKeys: baseTemplate.affectiveTraits.map((item) => item.key).filter((key) => affectiveTraitKeys.includes(key)),
    psychomotorTraitKeys: baseTemplate.psychomotorTraits.map((item) => item.key).filter((key) => psychomotorTraitKeys.includes(key)),
    ratingScale: getRatingScale(ratingScale).key,
    showPosition: normalizeBoolean(body[`${prefix}ShowPosition`]),
    showAverage: normalizeBoolean(body[`${prefix}ShowAverage`]),
    showAttendance: normalizeBoolean(body[`${prefix}ShowAttendance`]),
    showComments: normalizeBoolean(body[`${prefix}ShowComments`]),
  };
}

function getTemplateCustomizationOptions(template) {
  return {
    sectionOptions: SECTION_OPTIONS.filter((item) => template.sections.includes(item.key)),
    affectiveTraitOptions: template.affectiveTraits,
    psychomotorTraitOptions: template.psychomotorTraits,
    ratingScales: Object.values(RATING_SCALES),
  };
}

async function getSchoolResultTemplateSettings(schoolId) {
  const school = await School.findById(schoolId)
    .select('name resultTemplateSettings resultTemplateConfigs phases')
    .lean();
  const settings = school?.resultTemplateSettings || {};
  const configs = school?.resultTemplateConfigs || {};

  const selected = {
    Primary: settings.Primary || configs?.Primary?.templateKey || 'primary_plus_traits',
    Secondary: settings.Secondary || configs?.Secondary?.templateKey || 'secondary_standard',
  };

  const resolved = {
    Primary: applyPhaseConfig(getTemplateByKey(selected.Primary), configs?.Primary || {}),
    Secondary: applyPhaseConfig(getTemplateByKey(selected.Secondary), configs?.Secondary || {}),
  };

  return { school, selected, configs, resolved };
}

async function getActiveTemplateForSchoolPhase({ schoolId, phase }) {
  const { resolved } = await getSchoolResultTemplateSettings(schoolId);
  const phaseKey = String(phase || '').trim() === 'Primary' ? 'Primary' : 'Secondary';
  return resolved[phaseKey] || applyPhaseConfig(getTemplateByKey(phaseKey === 'Primary' ? 'primary_plus_traits' : 'secondary_standard'));
}

function normalizeTraitValue(value, ratingScaleKey = 'A-D') {
  const normalized = String(value || '').trim().toUpperCase();
  const allowed = new Set(getRatingScale(ratingScaleKey).options.map((item) => String(item).trim().toUpperCase()));
  return allowed.has(normalized) ? normalized : '';
}

module.exports = {
  RESULT_TEMPLATES,
  SECTION_OPTIONS,
  RATING_SCALES,
  getTemplateByKey,
  getTemplatesForPhase,
  getRatingScale,
  getTemplateCustomizationOptions,
  getSchoolResultTemplateSettings,
  getActiveTemplateForSchoolPhase,
  buildPhaseConfigFromRequest,
  normalizeTraitValue,
};
