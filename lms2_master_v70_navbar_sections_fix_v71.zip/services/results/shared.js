const mongoose = require('mongoose');

const ClassModel = require('../../models/class');

function assertObjectId(id, message) {
  if (!mongoose.isValidObjectId(id)) {
    const err = new Error(message);
    err.statusCode = 400;
    throw err;
  }
}

async function getClassOrThrow({ schoolId, classId, reqScopePhase }) {
  assertObjectId(classId, 'Invalid class id');

  const cls = await ClassModel.findOne({ _id: classId, school: schoolId })
    .select('name phase level isFinal order')
    .lean();

  if (!cls) {
    const err = new Error('Class not found for this school');
    err.statusCode = 404;
    throw err;
  }

  if (reqScopePhase && cls.phase !== reqScopePhase) {
    const err = new Error('You are not allowed to access results for this class');
    err.statusCode = 403;
    throw err;
  }

  return cls;
}

function rankRows(rows) {
  let lastTotal = null;
  let lastRank = 0;

  return rows.map((row, idx) => {
    if (lastTotal === null || row.overallTotal !== lastTotal) {
      lastRank = idx + 1;
      lastTotal = row.overallTotal;
    }
    return { ...row, position: lastRank };
  });
}

function ordinal(value) {
  const num = Number(value);
  if (!Number.isFinite(num) || num <= 0) return '';
  const mod100 = num % 100;
  if (mod100 >= 11 && mod100 <= 13) return `${num}th`;
  const mod10 = num % 10;
  if (mod10 === 1) return `${num}st`;
  if (mod10 === 2) return `${num}nd`;
  if (mod10 === 3) return `${num}rd`;
  return `${num}th`;
}

function gradeFromAverage(avg) {
  const n = Number(avg) || 0;
  if (n >= 70) return 'A';
  if (n >= 60) return 'B';
  if (n >= 50) return 'C';
  if (n >= 45) return 'D';
  if (n >= 40) return 'E';
  return 'F';
}

function remarkFromAverage(avg) {
  const n = Number(avg) || 0;
  if (n >= 80) return 'Excellent';
  if (n >= 70) return 'Very Good';
  if (n >= 60) return 'Good';
  if (n >= 50) return 'Credit';
  if (n >= 40) return 'Pass';
  return 'Needs Improvement';
}

function normalizeTermLabel(term) {
  const t = String(term || '').trim().toLowerCase();
  if (!t) return '';
  if (['1st', 'first', 'first term', '1', 'term 1'].includes(t)) return 'First Term';
  if (['2nd', 'second', 'second term', '2', 'term 2'].includes(t)) return 'Second Term';
  if (['3rd', 'third', 'third term', '3', 'term 3'].includes(t)) return 'Third Term';
  return String(term || '').trim();
}

function getTermAliases(term) {
  const normalized = normalizeTermLabel(term);
  if (!normalized) return [];

  const aliasMap = {
    'First Term': ['First Term', '1st Term', 'First', '1st', '1', 'Term 1'],
    'Second Term': ['Second Term', '2nd Term', 'Second', '2nd', '2', 'Term 2'],
    'Third Term': ['Third Term', '3rd Term', 'Third', '3rd', '3', 'Term 3'],
  };

  return aliasMap[normalized] || [normalized, String(term || '').trim()];
}

function getPromotionDecisionForClass(cls, yearlyAverage, missingTerms = [], completedTerms = 0) {
  const avg = Number(yearlyAverage);
  const hasAnyPublishedTerm = completedTerms > 0 && Number.isFinite(avg);
  if (!hasAnyPublishedTerm) return 'No Published Results';

  if (cls?.level === 'SSS' && cls?.isFinal) {
    return 'Graduate';
  }
  if (cls?.level === 'Primary' && cls?.isFinal) {
    return 'Complete Primary';
  }
  if (avg >= 40) return 'Promote';
  return 'Repeat';
}

function buildCurrentSessionStudentQuery({ schoolId, classId, session, sectionId = null, status = 'Active' }) {
  const query = {
    school: schoolId,
    class: classId,
    status,
  };

  if (sectionId) query.section = sectionId;

  return query;
}

function csvCell(value) {
  const str = value == null ? '' : String(value);
  return `"${str.replace(/"/g, '""')}"`;
}

module.exports = {
  mongoose,
  ClassModel,
  assertObjectId,
  getClassOrThrow,
  rankRows,
  ordinal,
  gradeFromAverage,
  remarkFromAverage,
  normalizeTermLabel,
  getTermAliases,
  getPromotionDecisionForClass,
  buildCurrentSessionStudentQuery,
  csvCell,
};
