const Student = require('../../models/Students');
const Score = require('../../models/score');
const Subject = require('../../models/Subject');
const StudentSubject = require('../../models/StudentSubject');
const ResultSnapshot = require('../../models/ResultSnapshot');
const PublishStatus = require('../../models/PublishStatus');
const SubjectResultSubmission = require('../../models/SubjectResultSubmission');
const FormTeacherAttendance = require('../../models/FormTeacherAttendance');
const {
  mongoose,
  assertObjectId,
  getClassOrThrow,
  rankRows,
  ordinal,
  gradeFromAverage,
  remarkFromAverage,
  normalizeTermLabel,
  getPromotionDecisionForClass,
  buildCurrentSessionStudentQuery,
  csvCell,
} = require('./shared');

async function getSubjectListFromIds({ schoolId, subjectIds }) {
  if (!subjectIds || !subjectIds.length) return [];
  return Subject.find({ _id: { $in: subjectIds }, school: schoolId })
    .select('name code level track tracks type')
    .sort({ name: 1 })
    .lean();
}

async function getPublishedTermsMap({ schoolId, academicYear }) {
  const docs = await PublishStatus.find({
    school: schoolId,
    academicYear: String(academicYear).trim(),
    published: true,
  })
    .select('term')
    .lean();

  const publishedTerms = new Set();
  for (const doc of docs) {
    const normalized = normalizeTermLabel(doc.term);
    if (normalized) publishedTerms.add(normalized);
  }

  return publishedTerms;
}

async function computeClassTermBroadsheet({
  schoolId,
  classId,
  academicYear,
  term,
  reqScopePhase,
  sectionId = null,
  submittedOnly = false,
  includeWholeClassSubjectsForSection = true,
}) {
  const cls = await getClassOrThrow({ schoolId, classId, reqScopePhase });
  const sessionStr = String(academicYear).trim();
  const normalizedTerm = String(term).trim();

  const studentQuery = buildCurrentSessionStudentQuery({
    schoolId,
    classId,
    session: sessionStr,
    sectionId,
  });

  const students = await Student.find(studentQuery)
    .select('name section track')
    .populate('section', 'name')
    .sort({ name: 1 })
    .lean();

  const studentIds = students.map((student) => student._id);
  if (!studentIds.length) {
    return {
      class: cls,
      subjects: [],
      academicYear: sessionStr,
      term: normalizedTerm,
      rows: [],
      classSummary: {
        students: 0,
        subjects: 0,
        totalOfTotals: 0,
        classAverage: 0,
        topStudent: null,
        bottomStudent: null,
      },
      subjectSummaries: [],
    };
  }

  const scoreMatch = {
    school: schoolId,
    class: classId,
    academicYear: sessionStr,
    term: normalizedTerm,
    student: { $in: studentIds },
  };
  if (sectionId) {
    scoreMatch.$or = includeWholeClassSubjectsForSection
      ? [{ section: sectionId }, { section: null }, { section: { $exists: false } }]
      : [{ section: sectionId }];
  }

  let submittedSubjectIds = null;
  if (submittedOnly) {
    const subFilter = { school: schoolId, class: classId, academicYear: sessionStr, term: normalizedTerm, status: 'Submitted' };
    if (sectionId) {
      subFilter.$or = includeWholeClassSubjectsForSection
        ? [{ section: sectionId }, { section: null }, { section: { $exists: false } }]
        : [{ section: sectionId }];
    }
    const subs = await SubjectResultSubmission.find(subFilter).select('subject').lean();
    submittedSubjectIds = subs.map((item) => String(item.subject));
  }

  const scores = await Score.find(scoreMatch)
    .select('student subject total grade')
    .lean();

  let scoreSubjectIds = [...new Set(scores.map((s) => String(s.subject)).filter(Boolean))];
  if (submittedSubjectIds) {
    scoreSubjectIds = scoreSubjectIds.filter((id) => submittedSubjectIds.includes(id));
  }
  let effectiveSubjects = await getSubjectListFromIds({ schoolId, subjectIds: scoreSubjectIds });

  const [enrollment, attendanceDocs] = await Promise.all([
    StudentSubject.find({
      school: schoolId,
      student: { $in: studentIds },
      session: sessionStr,
      ...(effectiveSubjects.length ? { subject: { $in: effectiveSubjects.map((subject) => subject._id) } } : {}),
    })
      .select('student subject')
      .lean(),
    FormTeacherAttendance.find({ school: schoolId, class: classId, academicYear: sessionStr, term: normalizedTerm, student: { $in: studentIds } }).select('student attendanceTotal').lean(),
  ]);

  const enrolledSubjectIds = [...new Set(enrollment.map((item) => String(item.subject)).filter(Boolean))];
  if (enrolledSubjectIds.length) {
    const enrolledSet = new Set(enrolledSubjectIds);
    scoreSubjectIds = scoreSubjectIds.filter((id) => enrolledSet.has(String(id)));
    const scoreIdSet = new Set(scoreSubjectIds);
    effectiveSubjects = effectiveSubjects.filter((subject) => scoreIdSet.has(String(subject._id)));
  } else {
    effectiveSubjects = [];
    scoreSubjectIds = [];
  }

  const scoreMap = new Map();
  for (const score of scores) {
    const subjectKey = String(score.subject);
    if (effectiveSubjects.length && !scoreSubjectIds.includes(subjectKey)) continue;
    const studentKey = String(score.student);
    if (!scoreMap.has(studentKey)) scoreMap.set(studentKey, new Map());
    scoreMap.get(studentKey).set(subjectKey, {
      total: typeof score.total === 'number' ? score.total : 0,
      grade: score.grade || '',
    });
  }

  const enrolledByStudent = new Map();
  for (const item of enrollment) {
    const studentKey = String(item.student);
    if (!enrolledByStudent.has(studentKey)) enrolledByStudent.set(studentKey, new Set());
    enrolledByStudent.get(studentKey).add(String(item.subject));
  }

  const subjectIdList = effectiveSubjects.map((subject) => String(subject._id));
  const rows = students.map((student) => {
    const studentKey = String(student._id);
    const perSubject = {};
    let overallTotal = 0;

    for (const subjectId of subjectIdList) {
      const entry = scoreMap.get(studentKey)?.get(subjectId);
      const total = entry?.total ?? 0;
      perSubject[subjectId] = total;
      overallTotal += total;
    }

    const enrolledSet = enrolledByStudent.get(studentKey);
    const subjectCount = enrolledSet ? enrolledSet.size : subjectIdList.length;
    const average = subjectCount > 0 ? Number((overallTotal / subjectCount).toFixed(2)) : 0;

    return {
      studentId: student._id,
      studentName: student.name,
      perSubject,
      overallTotal,
      subjectCount,
      average,
    };
  });

  rows.sort((a, b) => {
    if (b.overallTotal !== a.overallTotal) return b.overallTotal - a.overallTotal;
    return String(a.studentName || '').localeCompare(String(b.studentName || ''));
  });

  const rankedRows = rankRows(rows);
  const rowCount = rankedRows.length;
  const totalOfTotals = rankedRows.reduce((sum, row) => sum + (row.overallTotal || 0), 0);
  const averageOfAverages = rowCount > 0
    ? Number((rankedRows.reduce((sum, row) => sum + (row.average || 0), 0) / rowCount).toFixed(2))
    : 0;

  const topStudent = rankedRows[0] || null;
  const bottomStudent = rankedRows[rankedRows.length - 1] || null;

  const attendanceMap = new Map(attendanceDocs.map((doc) => [String(doc.student), Number(doc.attendanceTotal || 0)]));
  rankedRows.forEach((row) => { row.attendanceTotal = attendanceMap.get(String(row.studentId)) || 0; });

  const subjectSummaries = effectiveSubjects.map((subject) => {
    const key = String(subject._id);
    const totals = rankedRows.map((row) => Number(row.perSubject[key] || 0));
    const nonZero = totals.filter((value) => value > 0);
    const entries = nonZero.length;
    const subjectTotal = nonZero.reduce((sum, value) => sum + value, 0);
    const average = entries > 0 ? Number((subjectTotal / entries).toFixed(2)) : 0;
    const highest = entries > 0 ? Math.max(...nonZero) : 0;
    const lowest = entries > 0 ? Math.min(...nonZero) : 0;

    return {
      subjectId: subject._id,
      name: subject.name,
      code: subject.code || '',
      entries,
      average,
      highest,
      lowest,
    };
  });

  const subjects = Array.isArray(effectiveSubjects) ? effectiveSubjects : [];

  return {
    class: cls,
    subjects: Array.isArray(subjects) ? subjects : [],
    academicYear: sessionStr,
    term: normalizedTerm,
    rows: rankedRows,
    classSummary: {
      students: rowCount,
      subjects: effectiveSubjects.length,
      totalOfTotals,
      classAverage: averageOfAverages,
      topStudent: topStudent
        ? {
            studentId: topStudent.studentId,
            studentName: topStudent.studentName,
            overallTotal: topStudent.overallTotal,
            average: topStudent.average,
            position: topStudent.position,
            positionLabel: ordinal(topStudent.position),
          }
        : null,
      bottomStudent: bottomStudent
        ? {
            studentId: bottomStudent.studentId,
            studentName: bottomStudent.studentName,
            overallTotal: bottomStudent.overallTotal,
            average: bottomStudent.average,
            position: bottomStudent.position,
            positionLabel: ordinal(bottomStudent.position),
          }
        : null,
    },
    subjectSummaries,
  };
}

async function computeStudentTermResult({ schoolId, studentId, academicYear, term, reqScopePhase }) {
  assertObjectId(studentId, 'Invalid student id');

  const student = await Student.findOne({ _id: studentId, school: schoolId })
    .populate('class')
    .populate('section')
    .select('name class section currentSession status')
    .lean();

  if (!student) {
    const err = new Error('Student not found');
    err.statusCode = 404;
    throw err;
  }

  if (reqScopePhase && student.class?.phase !== reqScopePhase) {
    const err = new Error('You are not allowed to access this student');
    err.statusCode = 403;
    throw err;
  }

  const broadsheet = await computeClassTermBroadsheet({
    schoolId,
    classId: student.class?._id,
    academicYear,
    term,
    reqScopePhase,
    sectionId: student.section?._id || null,
    submittedOnly: true,
  });

  const row = broadsheet.rows.find((item) => String(item.studentId) === String(studentId));

  const scores = await Score.find({
    school: schoolId,
    class: student.class?._id,
    student: studentId,
    academicYear: String(academicYear).trim(),
    term: String(term).trim(),
  })
    .select('subject ca1 ca2 test1 test2 exam total grade')
    .lean();

  const subjectIds = scores.map((score) => score.subject).filter(Boolean);
  const subjectDocs = await Subject.find({ _id: { $in: subjectIds }, school: schoolId })
    .select('name code')
    .lean();
  const subjectMap = new Map(subjectDocs.map((subject) => [String(subject._id), subject]));

  const subjects = scores
    .map((score) => {
      const subject = subjectMap.get(String(score.subject));
      return {
        subjectId: score.subject,
        name: subject?.name,
        code: subject?.code,
        total: score.total ?? 0,
        grade: score.grade || '',
        ca1: score.ca1,
        ca2: score.ca2,
        test1: score.test1,
        test2: score.test2,
        exam: score.exam,
      };
    })
    .sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));

  const summary = row || {
    overallTotal: 0,
    average: 0,
    subjectCount: 0,
    position: null,
  };

  return {
    student,
    class: broadsheet.class,
    academicYear: broadsheet.academicYear,
    term: broadsheet.term,
    subjects,
    summary: {
      ...summary,
      positionLabel: summary.position ? ordinal(summary.position) : null,
      grade: gradeFromAverage(summary.average),
      remark: remarkFromAverage(summary.average),
    },
  };
}

async function computeClassAnnualBroadsheet({ schoolId, classId, academicYear, reqScopePhase, sectionId = null }) {
  const cls = await getClassOrThrow({ schoolId, classId, reqScopePhase });
  const session = String(academicYear).trim();

  const studentQuery = buildCurrentSessionStudentQuery({
    schoolId,
    classId,
    session,
    sectionId,
  });

  const students = await Student.find(studentQuery)
    .select('name')
    .sort({ name: 1 })
    .lean();

  const studentIds = students.map((student) => student._id);
  const canonicalTerms = ['First Term', 'Second Term', 'Third Term'];

  const [snapshots, publishedTerms] = await Promise.all([
    ResultSnapshot.find({
      school: schoolId,
      academicYear: session,
      class: classId,
      student: { $in: studentIds },
      ...(sectionId ? { section: sectionId } : {}),
    })
      .select('student term summary.average summary.total summary.subjectCount')
      .lean(),
    getPublishedTermsMap({ schoolId, academicYear: session }),
  ]);

  const rowsByStudent = new Map();
  for (const student of students) {
    rowsByStudent.set(String(student._id), {
      studentId: student._id,
      studentName: student.name,
      termAverages: { 'First Term': null, 'Second Term': null, 'Third Term': null },
      termTotals: { 'First Term': null, 'Second Term': null, 'Third Term': null },
      subjectCount: 0,
      yearlyAverage: null,
      yearlyTotal: 0,
      completedTerms: 0,
      missingTerms: [],
      position: null,
      positionLabel: '',
      grade: '',
      remark: '',
      decision: 'Incomplete Results',
    });
  }

  for (const snapshot of snapshots) {
    const row = rowsByStudent.get(String(snapshot.student));
    if (!row) continue;
    const termLabel = normalizeTermLabel(snapshot.term);
    if (!canonicalTerms.includes(termLabel)) continue;
    if (!publishedTerms.has(termLabel)) continue;

    row.termAverages[termLabel] = typeof snapshot?.summary?.average === 'number'
      ? Number(snapshot.summary.average)
      : 0;
    row.termTotals[termLabel] = typeof snapshot?.summary?.total === 'number'
      ? Number(snapshot.summary.total)
      : 0;
    if (typeof snapshot?.summary?.subjectCount === 'number' && snapshot.summary.subjectCount > row.subjectCount) {
      row.subjectCount = snapshot.summary.subjectCount;
    }
  }

  const rows = Array.from(rowsByStudent.values()).map((row) => {
    const values = [];
    for (const termName of canonicalTerms) {
      const value = row.termAverages[termName];
      if (typeof value === 'number') values.push(value);
      else row.missingTerms.push(termName);
    }

    row.completedTerms = values.length;
    row.yearlyTotal = values.reduce((sum, value) => sum + value, 0);
    row.yearlyAverage = values.length ? Number((row.yearlyTotal / values.length).toFixed(2)) : null;
    row.grade = row.yearlyAverage == null ? '' : gradeFromAverage(row.yearlyAverage);
    row.remark = row.yearlyAverage == null ? '' : remarkFromAverage(row.yearlyAverage);
    row.decision = getPromotionDecisionForClass(cls, row.yearlyAverage, row.missingTerms, row.completedTerms);
    row.movementAllowed = row.completedTerms > 0 && row.yearlyAverage != null;
    row.recommendedMoveAction = ['Promote', 'Graduate', 'Complete Primary'].includes(row.decision)
      ? 'PROMOTE'
      : (row.decision === 'Repeat' ? 'REPEAT' : null);

    if (row.completedTerms === 0) {
      row.moveBlockReason = 'No published frozen term result is available for this student yet.';
    } else if (row.missingTerms.length) {
      row.moveBlockReason = 'Transfer case: yearly average is based on available published terms only.';
    } else {
      row.moveBlockReason = '';
    }

    return row;
  });

  rows.sort((a, b) => {
    const left = a.yearlyAverage;
    const right = b.yearlyAverage;
    if (left == null && right == null) return String(a.studentName || '').localeCompare(String(b.studentName || ''));
    if (left == null) return 1;
    if (right == null) return -1;
    if (right !== left) return right - left;
    return String(a.studentName || '').localeCompare(String(b.studentName || ''));
  });

  let currentRank = 0;
  let lastAverage = null;
  for (let index = 0; index < rows.length; index += 1) {
    const row = rows[index];
    if (row.yearlyAverage == null) {
      row.position = null;
      row.positionLabel = '';
      continue;
    }
    if (lastAverage === null || row.yearlyAverage !== lastAverage) {
      currentRank = index + 1;
      lastAverage = row.yearlyAverage;
    }
    row.position = currentRank;
    row.positionLabel = ordinal(currentRank);
  }

  const validAverages = rows.filter((row) => row.yearlyAverage != null).map((row) => row.yearlyAverage);

  return {
    class: cls,
    academicYear: session,
    terms: canonicalTerms,
    rows,
    classSummary: {
      students: rows.length,
      completedStudents: validAverages.length,
      classAverage: validAverages.length
        ? Number((validAverages.reduce((sum, value) => sum + value, 0) / validAverages.length).toFixed(2))
        : 0,
      topStudent: rows.find((row) => row.yearlyAverage != null) || null,
      promotionReady: rows.some((row) => row.movementAllowed),
      lockedStudents: rows.filter((row) => !row.movementAllowed).length,
      transferStudents: rows.filter((row) => row.missingTerms.length > 0 && row.movementAllowed).length,
      publishedTerms: canonicalTerms.filter((termName) => publishedTerms.has(termName)),
    },
  };
}

function buildBroadsheetCsv(data) {
  const headers = [
    'Position',
    'Student',
    ...data.subjects.map((subject) => subject.code || subject.name),
    'Total',
    'Subjects',
    'Average',
  ];

  const lines = [headers.map(csvCell).join(',')];
  for (const row of data.rows) {
    lines.push([
      row.position,
      row.studentName,
      ...data.subjects.map((subject) => row.perSubject[String(subject._id)] ?? 0),
      row.overallTotal,
      row.subjectCount,
      row.average,
    ].map(csvCell).join(','));
  }

  if (data.subjectSummaries?.length) {
    lines.push('');
    lines.push('');
    lines.push([
      csvCell('Subject Summary'),
      csvCell('Entries'),
      csvCell('Average'),
      csvCell('Highest'),
      csvCell('Lowest'),
    ].join(','));
    for (const summary of data.subjectSummaries) {
      lines.push([
        csvCell(summary.code ? `${summary.code} - ${summary.name}` : summary.name),
        csvCell(summary.entries),
        csvCell(summary.average),
        csvCell(summary.highest),
        csvCell(summary.lowest),
      ].join(','));
    }
  }

  return lines.join('\n');
}

function buildAnnualBroadsheetCsv(data) {
  const headers = [
    'Position',
    'Student',
    '1st Term Avg',
    '2nd Term Avg',
    '3rd Term Avg',
    'Yearly Average',
    'Grade',
    'Remark',
    'Decision',
    'Missing Terms',
  ];

  const lines = [headers.map(csvCell).join(',')];
  for (const row of data.rows) {
    lines.push([
      row.positionLabel || '',
      row.studentName,
      row.termAverages['First Term'] ?? '',
      row.termAverages['Second Term'] ?? '',
      row.termAverages['Third Term'] ?? '',
      row.yearlyAverage ?? '',
      row.grade || '',
      row.remark || '',
      row.decision || '',
      row.missingTerms.join('; '),
    ].map(csvCell).join(','));
  }

  return lines.join('\n');
}

module.exports = {
  computeClassTermBroadsheet,
  computeStudentTermResult,
  computeClassAnnualBroadsheet,
  buildBroadsheetCsv,
  buildAnnualBroadsheetCsv,
};
