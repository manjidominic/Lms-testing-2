const Student = require('../../models/Students');
const Class = require('../../models/class');
const Teacher = require('../../models/Teacher');
const Subject = require('../../models/Subject');
const Section = require('../../models/section');
const AcademicYear = require('../../models/AcademicYear');
const Term = require('../../models/Term');
const AssessmentPolicy = require('../../models/assessmentPolicy');

async function getDashboardData({ schoolId, reqScopePhase }) {
  const classFilter = { school: schoolId };
  const studentFilter = { school: schoolId };
  const teacherFilter = { school: schoolId };
  const subjectFilter = { school: schoolId };
  const sectionFilter = { school: schoolId };

  if (reqScopePhase) {
    classFilter.phase = reqScopePhase;
    studentFilter.phase = reqScopePhase;
    teacherFilter.phase = reqScopePhase;
    sectionFilter.phase = reqScopePhase;
    subjectFilter.level = reqScopePhase === 'Primary' ? 'Primary' : { $in: ['JSS', 'SSS'] };
  }

  const [studentsCount, activeStudentsCount, graduatedCount, classesCount, teachersCount, subjectsCount, sectionsCount, classes, latestStudents, activeYear, activeTerm] = await Promise.all([
    Student.countDocuments(studentFilter),
    Student.countDocuments({ ...studentFilter, status: 'Active' }),
    Student.countDocuments({ ...studentFilter, status: { $in: ['Graduated', 'Completed'] } }),
    Class.countDocuments(classFilter),
    Teacher.countDocuments(teacherFilter),
    Subject.countDocuments(subjectFilter),
    Section.countDocuments(sectionFilter),
    Class.find(classFilter).sort({ order: 1, name: 1 }).lean(),
    Student.find(studentFilter).sort({ createdAt: -1 }).limit(8).populate('class').populate('section').lean(),
    AcademicYear.findOne({ school: schoolId, isActive: true }).lean(),
    Term.findOne({ school: schoolId, isActive: true }).lean(),
  ]);

  const policyCount = activeYear ? await AssessmentPolicy.countDocuments({ school: schoolId, academicYear: activeYear.name }) : 0;

  return {
    studentsCount,
    activeStudentsCount,
    graduatedCount,
    classesCount,
    teachersCount,
    subjectsCount,
    sectionsCount,
    policyCount,
    latestStudents,
    classes,
    activeYear,
    activeTerm,
  };
}

module.exports = { getDashboardData };
