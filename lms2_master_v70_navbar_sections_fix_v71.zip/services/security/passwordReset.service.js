const crypto = require('crypto');
const bcrypt = require('bcrypt');
const Account = require('../../models/Account');

function buildAccountQuery({ schoolId, role, q, limit = 100 }) {
  const query = {
    school: schoolId,
    role: { $ne: 'owner' },
  };

  if (role) {
    query.role = role;
  }

  if (q) {
    const regex = new RegExp(String(q).trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
    query.$or = [
      { email: regex },
      { username: regex },
    ];
  }

  return Account.find(query)
    .populate('student', 'name firstName surname email username phase class status admissionYear')
    .populate('teacher', 'fullName email username phase status')
    .populate('parent', 'fullName email phone username isActive')
    .sort({ role: 1, email: 1 })
    .limit(limit)
    .lean();
}

function resolveDisplayName(account) {
  if (account.student?.name) return account.student.name;
  if (account.teacher?.fullName) return account.teacher.fullName;
  if (account.parent?.fullName) return account.parent.fullName;
  return account.username || account.email || '—';
}

function resolveStatus(account) {
  if (account.student?.status) return account.student.status;
  if (account.teacher?.status) return account.teacher.status;
  if (account.parent) return account.parent.isActive ? 'Active' : 'Inactive';
  return account.isActive ? 'Active' : 'Inactive';
}

function resolveScope(account) {
  if (account.role === 'student') {
    return account.student?.phase || account.scopePhase || '';
  }
  if (account.role === 'parent') {
    return 'Parent';
  }
  return account.scopePhase || '';
}

async function listSchoolAccounts({ schoolId, role = '', q = '' }) {
  const accounts = await buildAccountQuery({ schoolId, role: role || undefined, q: q || undefined });

  return accounts.map((account) => ({
    ...account,
    displayName: resolveDisplayName(account),
    statusLabel: resolveStatus(account),
    scopeLabel: resolveScope(account),
    loginIdentifier: account.username || account.email,
  }));
}

function generateTemporaryPassword() {
  return crypto.randomBytes(6).toString('base64url');
}

async function adminResetAccountPassword({ schoolId, accountId, temporaryPassword, mustChangePassword = true }) {
  const account = await Account.findOne({ _id: accountId, school: schoolId });
  if (!account) {
    const err = new Error('Account not found for this school.');
    err.statusCode = 404;
    throw err;
  }

  const nextPassword = String(temporaryPassword || '').trim() || generateTemporaryPassword();
  if (nextPassword.length < 8) {
    const err = new Error('Temporary password must be at least 8 characters.');
    err.statusCode = 400;
    throw err;
  }

  account.passwordHash = await bcrypt.hash(nextPassword, 10);
  account.mustChangePassword = !!mustChangePassword;
  await account.save();

  return {
    account,
    temporaryPassword: nextPassword,
  };
}

module.exports = {
  listSchoolAccounts,
  adminResetAccountPassword,
};
