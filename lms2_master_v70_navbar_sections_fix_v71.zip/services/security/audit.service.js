const AuditLog = require('../../models/AuditLog');

async function recordAudit(payload = {}) {
  try {
    return await AuditLog.create({
      school: payload.school || null,
      actorAccount: payload.actorAccount || null,
      actorRole: payload.actorRole || '',
      action: payload.action || 'unknown',
      category: payload.category || 'general',
      targetType: payload.targetType || '',
      targetId: payload.targetId ? String(payload.targetId) : '',
      message: payload.message || '',
      metadata: payload.metadata || {},
      ipAddress: payload.ipAddress || '',
      userAgent: payload.userAgent || '',
    });
  } catch (err) {
    return null;
  }
}

module.exports = { recordAudit };
