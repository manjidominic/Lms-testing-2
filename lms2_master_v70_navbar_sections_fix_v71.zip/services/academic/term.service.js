const Term = require('../../models/Term');
const AcademicYear = require('../../models/AcademicYear');

// Helper: ensure academic year belongs to this school
async function ensureAcademicYear({ schoolId, academicYearId }) {
  const year = await AcademicYear.findOne({ _id: academicYearId, school: schoolId });
  if (!year) {
    const err = new Error('Academic year not found for this school.');
    err.statusCode = 404;
    throw err;
  }
  return year;
}

// List terms (optionally filter by academicYear)
exports.listTerms = async ({ schoolId, academicYearId }) => {
  const filter = { school: schoolId };
  if (academicYearId) filter.academicYear = academicYearId;

  return Term.find(filter)
    .populate('academicYear', 'name isActive')
    .sort({ createdAt: -1 });
};

// Create term
exports.createTerm = async ({ schoolId, academicYearId, name, makeActive }) => {
  await ensureAcademicYear({ schoolId, academicYearId });

  if (!name) {
    const err = new Error('Term name is required.');
    err.statusCode = 400;
    throw err;
  }

  // if making active, deactivate all other terms across the school
  if (makeActive) {
    await Term.updateMany(
      { school: schoolId },
      { $set: { isActive: false } }
    );

    await AcademicYear.updateMany(
      { school: schoolId },
      { $set: { isActive: false } }
    );

    await AcademicYear.updateOne(
      { _id: academicYearId, school: schoolId },
      { $set: { isActive: true } }
    );
  }

  try {
    return await Term.create({
      school: schoolId,
      academicYear: academicYearId,
      name,
      isActive: !!makeActive,
      isResultOpen: true,
    });
  } catch (e) {
    if (e.code === 11000) {
      const err = new Error('This term already exists in that academic year.');
      err.statusCode = 400;
      throw err;
    }
    throw e;
  }
};

// Activate term (only one active term and one active academic year per school)
exports.activateTerm = async ({ schoolId, termId }) => {
  const term = await Term.findOne({ _id: termId, school: schoolId }).select('academicYear');
  if (!term) {
    const err = new Error('Term not found.');
    err.statusCode = 404;
    throw err;
  }

  await AcademicYear.updateMany(
    { school: schoolId },
    { $set: { isActive: false } }
  );

  await AcademicYear.updateOne(
    { _id: term.academicYear, school: schoolId },
    { $set: { isActive: true } }
  );

  await Term.updateMany(
    { school: schoolId },
    { $set: { isActive: false } }
  );

  const updated = await Term.findOneAndUpdate(
    { _id: termId, school: schoolId },
    { $set: { isActive: true } },
    { new: true }
  ).populate('academicYear', 'name');

  return updated;
};
// Toggle result entry open/close
exports.toggleResultOpen = async ({ schoolId, termId }) => {
  const term = await Term.findOne({ _id: termId, school: schoolId });
  if (!term) {
    const err = new Error('Term not found.');
    err.statusCode = 404;
    throw err;
  }

  term.isResultOpen = !term.isResultOpen;
  await term.save();

  return term;
};

// For later: get active term
exports.getActiveTermByAcademicYear = async ({ schoolId, academicYearId }) => {
  return Term.findOne({
    school: schoolId,
    academicYear: academicYearId,
    isActive: true,
  }).populate('academicYear', 'name');
};