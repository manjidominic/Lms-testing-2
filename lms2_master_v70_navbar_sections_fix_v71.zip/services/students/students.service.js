const bcrypt = require('bcrypt');
const mongoose = require('mongoose');

const Student = require('../../models/Students');
const Account = require('../../models/Account');
const Parent = require('../../models/Parent');
const Class = require('../../models/class');
const Section = require('../../models/section');
const TeachingAssignment = require('../../models/TeachingAssignment');
const Teacher = require('../../models/Teacher');
const School = require('../../models/School');
const { validateYear } = require('../../utils/validation.util');
const { requireSplitNames } = require('../../utils/name.util');
const { generateScopedUsername } = require('../../utils/username.util');
const enrollmentService = require('./enrollment.service');
const AppError = require('../../utils/AppError');

const DEFAULT_SSS_SECTIONS = ['SCIENCE', 'ART', 'COMMERCIAL'];


function deriveTrackFromSectionName(sectionName) {
  const name = String(sectionName || '').trim().toUpperCase();
  if (name === 'SCIENCE') return 'Science';
  if (name === 'ART') return 'Art';
  if (name === 'COMMERCIAL') return 'Commercial';
  return null;
}

async function ensureDefaultSSSSections({ schoolId, classObj }) {
  if (!classObj || classObj.level !== 'SSS') return;

  const existing = await Section.find({ school: schoolId, class: classObj._id }).select('name').lean();
  const existingNames = new Set(existing.map((item) => String(item.name || '').trim().toUpperCase()));

  const docs = DEFAULT_SSS_SECTIONS
    .filter((name) => !existingNames.has(name))
    .map((name) => ({
      school: schoolId,
      phase: classObj.phase,
      class: classObj._id,
      name,
    }));

  if (docs.length) {
    await Section.insertMany(docs, { ordered: false });
  }
}

function normalizeParentContact(value) {
  const cleaned = String(value || '').trim();
  return cleaned || undefined;
}

function slugifyFragment(value) {
  return String(value || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '')
    .slice(0, 24);
}

function buildRandomParentUsernamePrefix({ schoolCode }) {
  const normalizedSchoolCode = slugifyFragment(schoolCode) || 'sch';
  return `${normalizedSchoolCode}-p`;
}

async function ensureUniqueParentUsername({ schoolId, candidatePrefix }) {
  const prefix = String(candidatePrefix || '').trim().toLowerCase() || 'sch-p';

  while (true) {
    const suffix = Math.floor(1000 + Math.random() * 9000);
    const username = `${prefix}${suffix}`;

    const [accountExists, parentExists] = await Promise.all([
      Account.exists({ school: schoolId, username }),
      Parent.exists({ school: schoolId, username }),
    ]);

    if (!accountExists && !parentExists) return username;
  }
}

async function findOrCreateParentAccess({ schoolId, parentName, parentEmail, parentPhone }) {
  const fullName = String(parentName || '').trim();
  const school = await School.findById(schoolId).select('code').lean();
  const schoolCode = school?.code || 'sch';
  if (!fullName) {
    throw new AppError('Please enter the parent or guardian full name before saving the student.', 400, { code: 'PARENT_NAME_REQUIRED' });
  }

  const email = normalizeParentContact(parentEmail)?.toLowerCase();
  const phone = normalizeParentContact(parentPhone);

  if (!email && !phone) {
    throw new AppError('Enter either the parent email address or phone number so the parent account can be created.', 400, { code: 'PARENT_CONTACT_REQUIRED' });
  }

  let parent = null;
  if (email) parent = await Parent.findOne({ school: schoolId, email });
  if (!parent && phone) parent = await Parent.findOne({ school: schoolId, phone });

  if (!parent) {
    const username = await ensureUniqueParentUsername({ schoolId, candidatePrefix: buildRandomParentUsernamePrefix({ schoolCode }) });
    parent = await Parent.create({ school: schoolId, fullName, email, phone, username });
  } else {
    const update = {};
    if (!parent.fullName && fullName) update.fullName = fullName;
    if (!parent.email && email) update.email = email;
    if (!parent.phone && phone) update.phone = phone;
    if (Object.keys(update).length) {
      await Parent.updateOne({ _id: parent._id }, { $set: update });
      parent = await Parent.findById(parent._id);
    }
  }

  let account = await Account.findOne({ school: schoolId, role: 'parent', parent: parent._id });
  if (!account) {
    const username = await ensureUniqueParentUsername({ schoolId, candidatePrefix: buildRandomParentUsernamePrefix({ schoolCode }) });
    const passwordHash = await bcrypt.hash('123456', 10);
    account = await Account.create({
      school: schoolId,
      role: 'parent',
      username,
      email: parent.email || `${username}@parent.local`,
      passwordHash,
      mustChangePassword: true,
      isActive: true,
      parent: parent._id,
    });
    if (parent.username !== username) {
      await Parent.updateOne({ _id: parent._id }, { $set: { username } });
      parent = await Parent.findById(parent._id);
    }
  }

  return { parent, account };
}

module.exports = {
  async generateStudentUsername({ schoolId, surname, firstName, admissionYear }) {
    return generateScopedUsername({
      schoolId,
      surname,
      firstName,
      year: admissionYear,
    });
  },
async updateStudentStatus({ schoolId, reqScopePhase, studentId, status, currentAcademicYear }) {
  const allowed = ['Active', 'Graduated', 'Withdrawn'];
  if (!allowed.includes(status)) {
    const err = new Error('Invalid status');
    err.statusCode = 400;
    throw err;
  }

  const filter = { _id: studentId, school: schoolId };
  // Owner bypass: only enforce phase for scoped users
  if (reqScopePhase) filter.phase = reqScopePhase;

  const update = { status };
  if (status === 'Active') {
    update.statusAcademicYear = undefined;
  } else {
    update.statusAcademicYear = currentAcademicYear ? String(currentAcademicYear).trim() : undefined;
  }

  const student = await Student.findOneAndUpdate(filter, update, { new: true });

  if (!student) {
    const err = new Error('Student not found');
    err.statusCode = 404;
    throw err;
  }

  return { student };
},

 async getStudentsByClass({ schoolId, reqScopePhase, classId, status }) {
  const filter = { school: schoolId };
  if (reqScopePhase) filter.phase = reqScopePhase;

  if (classId) {
    // also validate class belongs to this scopePhase (optional but recommended)
    const classWhere = { _id: classId, school: schoolId };
    if (reqScopePhase) classWhere.phase = reqScopePhase;
    const classObj = await Class.findOne(classWhere);
    if (!classObj) {
      const err = new Error('Invalid class for this school/scopePhase');
    err.userMessage = 'That class is not available for this school or section. Please choose another class.';
      err.statusCode = 400;
      throw err;
    }
    filter.class = classObj._id;
  }

  const normalizedStatus = String(status || '').trim().toLowerCase();
  if (normalizedStatus && normalizedStatus !== 'all') {
    const statusMap = { active: 'Active', graduated: 'Graduated', withdrawn: 'Withdrawn' };
    if (statusMap[normalizedStatus]) filter.status = statusMap[normalizedStatus];
  }

  const students = await Student.find(filter)
    .sort({ name: 1 })
    .populate('class')
    .populate('section');

  const selectedClass = classId
    ? await Class.findOne((() => {
        const w = { _id: classId, school: schoolId };
        if (reqScopePhase) w.phase = reqScopePhase;
        return w;
      })())
    : null;

  return { students, selectedClass };
},

  async getGraduatedStudentsByYear({ schoolId, reqScopePhase, academicYear }) {
    const filter = {
      school: schoolId,
      status: { $in: ['Graduated', 'Withdrawn'] },
    };
    if (reqScopePhase) filter.phase = reqScopePhase;

    const normalizedYear = String(academicYear || 'all').trim();
    if (normalizedYear && normalizedYear.toLowerCase() !== 'all') {
      filter.statusAcademicYear = normalizedYear;
    }

    const students = await Student.find(filter)
      .populate('class')
      .populate('section')
      .sort({ statusAcademicYear: -1, name: 1 })
      .lean();

    const yearDocs = await Student.find({
      school: schoolId,
      ...(reqScopePhase ? { phase: reqScopePhase } : {}),
      status: { $in: ['Graduated', 'Withdrawn'] },
      statusAcademicYear: { $nin: [null, ''] },
    }).distinct('statusAcademicYear');

    const years = (yearDocs || []).filter(Boolean).sort().reverse();
    return { students, years };
  },

  async getAddStudentFormData ({ schoolId, reqScopePhase }){
    // Owner sees all classes in the school; scoped users see only their phase
    const where = { school: schoolId };
    if (reqScopePhase) where.phase = reqScopePhase;

    const classes = await Class.find(where).sort({ level: 1, order: 1 });
    return { classes };
  },  
  async registerStudent({ schoolId, reqScopePhase, surname, middleName, firstName, name, admissionYear, classId, sectionId, academicYear, parentName, parentEmail, parentPhone }) {
  const personName = requireSplitNames({
    surname,
    middleName,
    firstName,
    fallbackName: name,
    label: 'Student name',
  });
  const normalizedAdmissionYear = validateYear(admissionYear, 'Admission year');

  if (!classId) {
    throw new AppError('Please select a class before creating the student.', 400, { code: 'CLASS_REQUIRED' });
  }

  // Owner bypass: reqScopePhase can be null; we derive phase from the selected class.

  // Validate ObjectIds early (prevents BSONError)
  if (!mongoose.Types.ObjectId.isValid(schoolId)) {
    throw new AppError('The selected school record is not valid. Please sign in again and retry.', 400, { code: 'INVALID_SCHOOL_ID' });
  }
  if (!mongoose.Types.ObjectId.isValid(classId)) {
    throw new AppError('The selected class is not valid. Please choose the class again.', 400, { code: 'INVALID_CLASS_ID' });
  }
  if (sectionId && sectionId !== 'none' && !mongoose.Types.ObjectId.isValid(sectionId)) {
    throw new AppError('The selected section is not valid. Please choose the section again.', 400, { code: 'INVALID_SECTION_ID' });
  }

  // ✅ Enforce school + phase isolation on class selection
  const classWhere = { _id: classId, school: schoolId };
  if (reqScopePhase) classWhere.phase = reqScopePhase;
  const classObj = await Class.findOne(classWhere);

  if (!classObj) {
    throw new AppError('That class is not available for this school or section. Please choose another class.', 400, { code: 'CLASS_SCOPE_MISMATCH' });
  }

  await ensureDefaultSSSSections({ schoolId, classObj });

  const availableSections = await Section.find({ school: schoolId, class: classObj._id }).select('_id name').lean();
  const classHasSections = availableSections.length > 0;

  if (classHasSections && (!sectionId || sectionId === 'none')) {
    throw new AppError(`Please choose the correct section for ${classObj.name} before saving the student.`, 400, { code: 'SECTION_REQUIRED' });
  }

  // Section must belong to the chosen class
  let sectionObj = null;
  if (sectionId && sectionId !== 'none') {
    sectionObj = await Section.findOne({
      _id: sectionId,
      school: schoolId,
      class: classObj._id,
    });

    if (!sectionObj) {
      throw new AppError('The selected section does not belong to this class. Please choose the correct section.', 400, { code: 'SECTION_CLASS_MISMATCH' });
    }
  }

  // ✅ Derive level from class (solves "level is required" forever)
  const level = classObj.level; // 'Primary' | 'JSS' | 'SSS'

  // Always generate email server-side (ignore any email from req.body)
  // NOTE: In CommonJS, `exports` no longer points to `module.exports` after reassigning
  // `module.exports = { ... }`. So we call via `module.exports` to avoid "not a function".
  const username = await module.exports.generateStudentUsername({
    schoolId,
    surname: personName.surname,
    firstName: personName.firstName,
    admissionYear: normalizedAdmissionYear,
  });

  const studentPhase = classObj.phase; // always trust the class

  const derivedTrack = level === 'SSS' ? (deriveTrackFromSectionName(sectionObj?.name) || 'General') : 'General';
  const { parent } = await findOrCreateParentAccess({
    schoolId,
    parentName,
    parentEmail,
    parentPhone,
  });

  const student = await Student.create({
    school: schoolId,
    phase: studentPhase,
    surname: personName.surname,
    middleName: personName.middleName,
    firstName: personName.firstName,
    name: personName.fullName,
    parent: parent?._id || null,
    parentName: parent?.fullName || String(parentName || '').trim(),
    parentEmail: parent?.email || normalizeParentContact(parentEmail)?.toLowerCase(),
    parentPhone: parent?.phone || normalizeParentContact(parentPhone),
    username,
    email: username,
    level,                         // derived from class
    class: classObj._id,
    section: sectionObj ? sectionObj._id : null,  // ✅ prevents "none" BSONError
    track: derivedTrack,
    admissionYear: normalizedAdmissionYear,
    // ✅ required for results + form-teacher broadsheets. Older records may not have this.
    currentSession: academicYear ? String(academicYear).trim() : undefined,
    status: 'Active',
    portalAccess: studentPhase === 'Primary' ? 'parent_only' : 'student_and_parent',
  });

  if (studentPhase === 'Secondary') {
    const defaultPassword = '123456';
    const passwordHash = await bcrypt.hash(defaultPassword, 10);

    await Account.create({
      school: schoolId,
      role: 'student',
      username,
      email: username,
      passwordHash,
      mustChangePassword: true,
      scopePhase: studentPhase,
      student: student._id,
    });
  }

  await enrollmentService.saveEnrollment({
    schoolId,
    reqScopePhase,
    studentId: student._id,
    session: student.currentSession,
    selectedElectiveSubjectIds: [],
    newTrack: student.track,
  });

  return {
    student,
    parentAccess: {
      parentName: parent?.fullName || null,
      parentUsername: parent?.username || null,
      loginIdentifier: parent?.username || parent?.email || parent?.phone || null,
      portalAccess: studentPhase === 'Primary' ? 'parent_only' : 'student_and_parent',
    },
  };
},

  
  async getStudentProfile({ schoolId, reqScopePhase, studentId }) {
  const where = { _id: studentId, school: schoolId };
  if (reqScopePhase) where.phase = reqScopePhase;

  const student = await Student.findOne(where)
    .populate('class')
    .populate('section')
    .populate('parent');

  if (!student) {
    const err = new Error('Student not found');
    err.statusCode = 404;
    throw err;
  }
  return student;
},
  async getSectionsForClass({ schoolId, reqScopePhase, classId }) {
    const classFilter = { _id: classId, school: schoolId };
    if (reqScopePhase) classFilter.phase = reqScopePhase;

    const cls = await Class.findOne(classFilter);
    if (!cls) return [];

    await ensureDefaultSSSSections({ schoolId, classObj: cls });

    return Section.find({ school: schoolId, class: cls._id }).sort({ name: 1 }).lean();
  },
};
