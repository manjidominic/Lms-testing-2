const Student = require('../../models/Students');
const Subject = require('../../models/Subject');
const ClassSubject = require('../../models/ClassSubject');
const ClassModel = require('../../models/class');
const StudentSubject = require('../../models/StudentSubject');

function httpError(message, statusCode = 400) {
  const err = new Error(message);
  err.statusCode = statusCode;
  return err;
}

function asArray(v) {
  if (!v) return [];
  if (Array.isArray(v)) return v;
  return [v];
}


function deriveTrackFromSectionName(sectionName) {
  const name = String(sectionName || '').trim().toUpperCase();
  if (name === 'SCIENCE') return 'Science';
  if (name === 'ART') return 'Art';
  if (name === 'COMMERCIAL') return 'Commercial';
  return null;
}

function getEffectiveStudentTrack(studentLike) {
  return studentLike?.track || deriveTrackFromSectionName(studentLike?.section?.name) || 'General';
}

function isTrackMatch(subjectTracks, studentTrack) {
  if (!Array.isArray(subjectTracks) || subjectTracks.length === 0) return true;
  if (!studentTrack) return false;
  return subjectTracks.includes(studentTrack);
}

async function ensureBaseEnrollmentsForStudents({ schoolId, studentIds, classId, sessionName, studentTrackById = new Map() }) {
  if (!studentIds || !studentIds.length) return;

  const offerings = await ClassSubject.find({ school: schoolId, class: classId })
    .populate('subject')
    .lean();

  const docs = [];
  for (const studentId of studentIds) {
    const track = studentTrackById.get(String(studentId)) || null;
    for (const off of offerings) {
      const subj = off.subject;
      if (!subj) continue;
      const offeringType = off.offeringType || subj.type || 'GENERAL';
      if (offeringType === 'ELECTIVE') continue;
      if (offeringType === 'TRACK_CORE' && !isTrackMatch(subj.tracks, track)) continue;
      docs.push({
        updateOne: {
          filter: { school: schoolId, student: studentId, subject: subj._id, session: sessionName },
          update: { $setOnInsert: { school: schoolId, student: studentId, subject: subj._id, session: sessionName, type: 'base' } },
          upsert: true,
        }
      });
    }
  }
  if (docs.length) await StudentSubject.bulkWrite(docs, { ordered: false });
}

async function computeBaseSubjectsForStudent({ schoolId, classId, studentTrack }) {
  const offerings = await ClassSubject.find({ school: schoolId, class: classId })
    .populate('subject')
    .lean();

  const base = [];
  const electives = [];

  for (const off of offerings) {
    const subj = off.subject;
    if (!subj) continue;

    const offeringType = off.offeringType || subj.type || 'CORE';

    if (offeringType === 'ELECTIVE') {
      electives.push(subj);
      continue;
    }

    if (offeringType === 'TRACK_CORE') {
      if (isTrackMatch(subj.tracks, studentTrack)) {
        base.push(subj);
      }
      continue;
    }

    // GENERAL / CORE
    base.push(subj);
  }

  return { baseSubjects: base, electiveSubjects: electives };
}

exports.getEnrollmentPageData = async ({ schoolId, reqScopePhase, studentId, sessionName }) => {
  const where = { _id: studentId, school: schoolId };
  if (reqScopePhase) where.phase = reqScopePhase;
  const student = await Student.findOne(where).populate('class');
  if (!student) throw httpError('Student not found', 404);

  const session = sessionName || student.currentSession;
  if (student.level === 'SSS' && (!student.track || student.track === 'General') && student.section?.name) {
    student.track = deriveTrackFromSectionName(student.section.name) || student.track;
  }
  if (!session) throw httpError('Student session is not set. Ensure an active academic year exists and student has currentSession.', 400);

  const classId = student.class?._id || student.class;
  const { baseSubjects, electiveSubjects } = await computeBaseSubjectsForStudent({
    schoolId,
    classId,
    studentTrack: student.track,
  });

  // ✅ Auto-enroll CORE/TRACK_CORE subjects server-side.
  // This makes enrollment truly "automatic" — visiting the page will ensure base subjects
  // are already saved for the student for that academic session.
  for (const subj of baseSubjects) {
    // upsert (idempotent)
    // NOTE: we key by (school, student, subject, session)
    await StudentSubject.updateOne(
      { school: schoolId, student: student._id, subject: subj._id, session },
      {
        $setOnInsert: {
          school: schoolId,
          student: student._id,
          subject: subj._id,
          session,
          type: 'base',
        },
      },
      { upsert: true }
    );
  }

  // current enrollments
  const enrollments = await StudentSubject.find({ school: schoolId, student: student._id, session })
    .populate('subject')
    .lean();

  const enrolledBaseIds = new Set(
    enrollments.filter((e) => e.type === 'base').map((e) => String(e.subject?._id || e.subject))
  );
  const enrolledBorrowedIds = new Set(
    enrollments.filter((e) => e.type === 'borrowed').map((e) => String(e.subject?._id || e.subject))
  );

  return {
    student,
    session,
    baseSubjects,
    electiveSubjects,
    enrolledBaseIds,
    enrolledBorrowedIds,
  };
};

exports.saveEnrollment = async ({
  schoolId,
  reqScopePhase,
  studentId,
  session,
  selectedElectiveSubjectIds,
  newTrack,
}) => {
  const where = { _id: studentId, school: schoolId };
  if (reqScopePhase) where.phase = reqScopePhase;
  const student = await Student.findOne(where);
  if (!student) throw httpError('Student not found', 404);

  const sessionName = session || student.currentSession;
  if (!sessionName) throw httpError('Session is required', 400);

  // Track change (SSS only) - optional
  const cleanNewTrack = newTrack ? String(newTrack).trim() : '';
  if (cleanNewTrack && student.level === 'SSS') {
    student.track = cleanNewTrack;
    await student.save();
  }

  const { baseSubjects, electiveSubjects } = await computeBaseSubjectsForStudent({
    schoolId,
    classId: student.class,
    studentTrack: student.track,
  });

  // Ensure base enrollments exist (upsert)
  for (const subj of baseSubjects) {
    await StudentSubject.updateOne(
      { school: schoolId, student: student._id, subject: subj._id, session: sessionName },
      { $setOnInsert: { school: schoolId, student: student._id, subject: subj._id, session: sessionName, type: 'base' } },
      { upsert: true }
    );
  }

  // Replace borrowed enrollments with selected elective subjects
  const selected = new Set(asArray(selectedElectiveSubjectIds).map(String));
  const allowedElectiveSet = new Set(electiveSubjects.map((s) => String(s._id)));
  for (const id of selected) {
    if (!allowedElectiveSet.has(id)) {
      throw httpError('One or more selected elective subjects are not offered for this class.', 400);
    }
  }

  await StudentSubject.deleteMany({
    school: schoolId,
    student: student._id,
    session: sessionName,
    type: 'borrowed',
  });

  const borrowedDocs = Array.from(selected).map((sid) => ({
    school: schoolId,
    student: student._id,
    subject: sid,
    session: sessionName,
    type: 'borrowed',
  }));
  if (borrowedDocs.length) await StudentSubject.insertMany(borrowedDocs);

  return { ok: true };
};

// =============================
// Bulk Elective Enrollment (Whole Class)
// =============================

exports.getBulkEnrollElectivesPageData = async ({ schoolId, reqScopePhase, classId, session }) => {
  const classWhere = { _id: classId, school: schoolId };
  if (reqScopePhase) classWhere.phase = reqScopePhase;

  const classObj = await ClassModel.findOne(classWhere);
  if (!classObj) throw httpError('Class not found (or not permitted for this admin scope).', 404);

  const sessionName = session;
  if (!sessionName) throw httpError('Session is required', 400);

  const allOfferings = await ClassSubject.find({
    school: schoolId,
    class: classObj._id,
  })
    .populate('subject')
    .sort({ 'subject.name': 1 });

  const baseOfferings = allOfferings.filter((o) => (o.offeringType || o.subject?.type || 'GENERAL') !== 'ELECTIVE');
  const electiveOfferings = allOfferings.filter((o) => (o.offeringType || o.subject?.type || 'GENERAL') === 'ELECTIVE');

  const studentWhere = { school: schoolId, class: classObj._id, status: 'Active' };
  if (reqScopePhase) studentWhere.phase = reqScopePhase;
  const students = await Student.find(studentWhere).select('_id');

  // Pre-check using the first student's borrowed subjects (nice UX)
  let prechecked = new Set();
  if (students.length && electiveOfferings.length) {
    const allowedSubjectIds = electiveOfferings.map((o) => o.subject?._id).filter(Boolean);
    const existing = await StudentSubject.find({
      school: schoolId,
      student: students[0]._id,
      session: sessionName,
      type: 'borrowed',
      subject: { $in: allowedSubjectIds },
    }).select('subject');
    prechecked = new Set(existing.map((x) => String(x.subject)));
  }

  const studentTrackById = new Map();
  if (students.length) {
    const fullStudents = await Student.find({ _id: { $in: students.map((s) => s._id) } }).select('_id track section').populate('section', 'name');
    fullStudents.forEach((s) => studentTrackById.set(String(s._id), getEffectiveStudentTrack(s)));
    await ensureBaseEnrollmentsForStudents({
      schoolId,
      studentIds: students.map((s) => s._id),
      classId: classObj._id,
      sessionName,
      studentTrackById,
    });
  }

  return {
    ok: true,
    classObj,
    session: sessionName,
    baseOfferings,
    electiveOfferings,
    prechecked,
    studentCount: students.length,
  };
};

exports.bulkEnrollClassElectives = async ({
  schoolId,
  reqScopePhase,
  classId,
  session,
  electiveSubjectIds,
}) => {
  const classWhere = { _id: classId, school: schoolId };
  if (reqScopePhase) classWhere.phase = reqScopePhase;
  const classObj = await ClassModel.findOne(classWhere);
  if (!classObj) throw httpError('Class not found (or not permitted for this admin scope).', 404);

  const sessionName = session;
  if (!sessionName) throw httpError('Session is required', 400);

  // Allowed elective subjects for this class (by offering)
  const offerings = await ClassSubject.find({
    school: schoolId,
    class: classObj._id,
    offeringType: 'ELECTIVE',
  }).select('subject');
  const allowedSet = new Set(offerings.map((o) => String(o.subject)));

  const selected = new Set(asArray(electiveSubjectIds).map(String));
  for (const id of selected) {
    if (!allowedSet.has(id)) {
      throw httpError('One or more selected elective subjects are not offered for this class.', 400);
    }
  }

  const studentWhere = { school: schoolId, class: classObj._id, status: 'Active' };
  if (reqScopePhase) studentWhere.phase = reqScopePhase;
  const students = await Student.find(studentWhere).select('_id track section').populate('section', 'name');
  const studentIds = students.map((s) => s._id);
  const studentTrackById = new Map(students.map((s) => [String(s._id), getEffectiveStudentTrack(s)]));

  await ensureBaseEnrollmentsForStudents({
    schoolId,
    studentIds,
    classId: classObj._id,
    sessionName,
    studentTrackById,
  });

  // Remove existing borrowed electives that belong to this class offerings
  await StudentSubject.deleteMany({
    school: schoolId,
    session: sessionName,
    type: 'borrowed',
    student: { $in: studentIds },
    subject: { $in: Array.from(allowedSet) },
  });

  const docs = [];
  for (const studentId of studentIds) {
    for (const sid of selected) {
      docs.push({
        school: schoolId,
        student: studentId,
        subject: sid,
        session: sessionName,
        type: 'borrowed',
      });
    }
  }
  if (docs.length) await StudentSubject.insertMany(docs, { ordered: false });

  return { ok: true };
};
