const PromotionHistory = require('../../models/PromotionHistory');

function summarizeArchiveGroups(groups = []) {
  return (Array.isArray(groups) ? groups : []).map((group) => {
    const snapshots = Array.isArray(group?.snapshots) ? group.snapshots : [];
    const classNames = Array.from(new Set(snapshots.map((item) => item?.class?.name).filter(Boolean)));
    const terms = snapshots.map((item) => item?.term).filter(Boolean);
    const averages = snapshots
      .map((item) => (typeof item?.summary?.average === 'number' ? item.summary.average : null))
      .filter((value) => value !== null);

    return {
      academicYear: group?.academicYear || '-',
      classes: classNames,
      classDisplay: classNames.join(', ') || '-',
      terms,
      termCount: snapshots.length,
      averageDisplay: averages.length
        ? (Math.round((averages.reduce((sum, value) => sum + value, 0) / averages.length) * 100) / 100).toFixed(2)
        : '-',
      latestSnapshot: snapshots[snapshots.length - 1] || null,
      snapshots,
    };
  });
}

function buildCurrentStanding({ student, archiveGroups = [], movementHistory = [] }) {
  const latestMovement = movementHistory[0] || null;
  const latestArchive = archiveGroups[archiveGroups.length - 1] || null;

  return {
    status: student?.status || '-',
    currentSession: student?.currentSession || latestArchive?.academicYear || '-',
    currentClassName: student?.class?.name || latestArchive?.latestSnapshot?.class?.name || '-',
    currentSectionName: student?.section?.name || latestArchive?.latestSnapshot?.section?.name || '-',
    lastMovement: latestMovement,
  };
}

async function getStudentAcademicHistory({ schoolId, student, resultHistory = [] }) {
  const movementHistory = await PromotionHistory.find({
    school: schoolId,
    student: student?._id,
  })
    .populate('fromClass', 'name level phase')
    .populate('toClass', 'name level phase')
    .populate('performedBy', 'fullName username email')
    .sort({ createdAt: -1 })
    .lean();

  const archiveGroups = summarizeArchiveGroups(resultHistory);
  const currentStanding = buildCurrentStanding({ student, archiveGroups, movementHistory });

  return {
    currentStanding,
    archiveGroups,
    movementHistory,
  };
}

module.exports = {
  getStudentAcademicHistory,
};
