const Student = require('../../models/Students');
const Account = require('../../models/Account');
const StudentSubject = require('../../models/StudentSubject');
const Term = require('../../models/Term');
const AcademicYear = require('../../models/AcademicYear');
const mongoose = require('mongoose');
const { getStudentPublishedResultHistory } = require('../results');
const { getStudentAcademicHistory } = require('./academicHistory.service');

async function getStudentRecord({ schoolId, studentId }) {
  const student = await Student.findOne({ _id: studentId, school: schoolId })
    .populate('class')
    .populate('section');

  if (!student) {
    const err = new Error('Student not found for this school');
    err.statusCode = 404;
    throw err;
  }

  return student;
}

async function getStudentAccount({ schoolId, studentId }) {
  return Account.findOne({ school: schoolId, student: studentId, role: 'student' }).lean();
}

async function resolveAcademicYearId({ schoolId, currentAcademicYear }) {
  if (!schoolId || !currentAcademicYear) return null;

  if (mongoose.Types.ObjectId.isValid(String(currentAcademicYear))) {
    return String(currentAcademicYear);
  }

  const yearDoc = await AcademicYear.findOne({
    school: schoolId,
    name: String(currentAcademicYear).trim(),
  }).select('_id name').lean();

  return yearDoc?._id ? String(yearDoc._id) : null;
}

async function getActiveTermInfo({ schoolId, currentAcademicYear, currentTerm }) {
  let activeTerm = null;
  const academicYearId = await resolveAcademicYearId({ schoolId, currentAcademicYear });

  if (schoolId && academicYearId) {
    const termFilter = {
      school: schoolId,
      academicYear: academicYearId,
      isActive: true,
    };
    if (currentTerm) termFilter.name = currentTerm;

    activeTerm = await Term.findOne(termFilter).lean();

    if (!activeTerm && currentTerm) {
      activeTerm = await Term.findOne({
        school: schoolId,
        academicYear: academicYearId,
        name: currentTerm,
      }).lean();
    }
  }

  return {
    currentAcademicYear: currentAcademicYear || null,
    currentTerm: currentTerm || activeTerm?.name || null,
    activeTerm,
  };
}

async function getCurrentSubjects({ schoolId, studentId, currentAcademicYear }) {
  if (!currentAcademicYear) return [];

  return StudentSubject.find({
    school: schoolId,
    student: studentId,
    session: currentAcademicYear,
  })
    .populate('subject')
    .sort({ type: 1, createdAt: 1 })
    .lean();
}

async function getDashboardData({ schoolId, studentId, currentAcademicYear, currentTerm }) {
  const student = await getStudentRecord({ schoolId, studentId });
  const account = await getStudentAccount({ schoolId, studentId });
  const subjects = await getCurrentSubjects({ schoolId, studentId, currentAcademicYear });
  const termInfo = await getActiveTermInfo({ schoolId, currentAcademicYear, currentTerm });

  return {
    student,
    account,
    subjects,
    currentClass: student.class || null,
    ...termInfo,
  };
}

async function getProfileData({ schoolId, studentId, currentAcademicYear, currentTerm }) {
  const student = await getStudentRecord({ schoolId, studentId });
  const account = await getStudentAccount({ schoolId, studentId });
  const history = await getStudentPublishedResultHistory({ schoolId, studentId, studentEmail: student.email || account?.email || '', studentUsername: student.username || account?.username || '' });
  const academicHistory = await getStudentAcademicHistory({ schoolId, student, resultHistory: history.grouped });
  const subjects = await getCurrentSubjects({ schoolId, studentId, currentAcademicYear });
  const termInfo = await getActiveTermInfo({ schoolId, currentAcademicYear, currentTerm });

  return {
    student,
    account,
    subjects,
    currentClass: student.class || null,
    ...termInfo,
    resultHistory: history.grouped,
    resultSnapshots: history.snapshots,
    academicArchive: academicHistory.archiveGroups,
    movementHistory: academicHistory.movementHistory,
    currentStanding: academicHistory.currentStanding,
  };
}

module.exports = { getDashboardData, getProfileData };
