const Account = require('../../models/Account');
const Student = require('../../models/Students');
const mongoose = require('mongoose');

async function findStudentByDirectId({ schoolId, studentId }) {
  if (!studentId || !mongoose.isValidObjectId(String(studentId))) return null;
  return Student.findOne({ _id: studentId, school: schoolId })
    .select('_id school email username class phase level')
    .lean();
}

async function findStudentByAccountFields({ schoolId, account }) {
  if (!account) return null;
  const email = String(account.email || '').trim().toLowerCase();
  const username = String(account.username || '').trim().toLowerCase();

  const or = [];
  if (email) or.push({ email });
  if (username) or.push({ username });
  if (!or.length) return null;

  return Student.findOne({ school: schoolId, $or: or })
    .select('_id school email username class phase level')
    .lean();
}

async function syncAccountStudentLink({ accountId, schoolId, studentId }) {
  if (!accountId || !studentId) return;
  await Account.updateOne(
    { _id: accountId, school: schoolId, role: 'student' },
    { $set: { student: studentId } }
  );
}

async function resolveStudentIdentity({ schoolId, sessionAccount }) {
  if (!sessionAccount) {
    const err = new Error('Student account session not found');
    err.statusCode = 401;
    throw err;
  }

  let student = await findStudentByDirectId({ schoolId, studentId: sessionAccount.student });
  if (student) return student;

  let accountDoc = null;
  if (sessionAccount.id && mongoose.isValidObjectId(String(sessionAccount.id))) {
    accountDoc = await Account.findOne({ _id: sessionAccount.id, school: schoolId, role: 'student', isActive: true })
      .select('_id school email username student role isActive')
      .lean();

    if (accountDoc?.student) {
      student = await findStudentByDirectId({ schoolId, studentId: accountDoc.student });
      if (student) return student;
    }
  }

  const candidate = await findStudentByAccountFields({ schoolId, account: accountDoc || sessionAccount });
  if (candidate) {
    await syncAccountStudentLink({ accountId: accountDoc?._id || sessionAccount.id, schoolId, studentId: candidate._id });
    return candidate;
  }

  const err = new Error('Student record is not linked to this login account');
  err.statusCode = 404;
  throw err;
}

module.exports = { resolveStudentIdentity, syncAccountStudentLink };
