const TeachingAssignment = require('../../models/TeachingAssignment');
const Account = require('../../models/Account');
const School = require('../../models/School');
const bcrypt = require('bcrypt');
const Teacher = require('../../models/Teacher');
const { validateYear, normalizeNigerianPhone } = require('../../utils/validation.util');
const { requireSplitNames } = require('../../utils/name.util');
const { generateScopedUsername } = require('../../utils/username.util');

async function attachTeacherAssignments(teachers, { schoolId, academicYear = null }) {
  const teacherIds = teachers.map((t) => t._id);
  if (!teacherIds.length) return teachers;
  const assignments = await TeachingAssignment.find({
    school: schoolId,
    teacher: { $in: teacherIds },
    ...(academicYear ? { academicYear } : {}),
  })
    .populate('class', 'name')
    .populate('subject', 'name code')
    .populate('section', 'name')
    .lean();

  const map = new Map();
  for (const t of teachers) map.set(String(t._id), []);
  for (const a of assignments) {
    const key = String(a.teacher?._id || a.teacher);
    if (!map.has(key)) map.set(key, []);
    map.get(key).push(a);
  }

  return teachers.map((teacher) => ({
    ...teacher,
    assignments: (map.get(String(teacher._id)) || []).sort((a, b) =>
      `${a.class?.name || ''} ${a.subject?.name || ''}`.localeCompare(`${b.class?.name || ''} ${b.subject?.name || ''}`)
    ),
  }));
}

exports.listTeachers = async ({ schoolId, status, reqScopePhase, academicYear }) => {
  const filter = { school: schoolId };
  if (status && status !== 'all') filter.status = status;
  if (reqScopePhase) filter.phase = reqScopePhase;
  const teachers = await Teacher.find(filter).sort({ fullName: 1 }).lean();
  return attachTeacherAssignments(teachers, { schoolId, academicYear });
};

exports.generateTeacherUsername = async ({ schoolId, surname, firstName, startYear }) => {
  return generateScopedUsername({ schoolId, surname, firstName, year: startYear });
};

exports.createTeacher = async ({ surname, middleName, firstName, name, schoolId, startYear, phone, reqScopePhase }) => {
  const personName = requireSplitNames({ surname, middleName, firstName, fallbackName: name, label: 'Teacher name' });
  const normalizedStartYear = validateYear(startYear, 'Start year');
  const normalizedPhone = normalizeNigerianPhone(phone);
  const username = await this.generateTeacherUsername({ schoolId, surname: personName.surname, firstName: personName.firstName, startYear: normalizedStartYear });

  const school = await School.findById(schoolId).select('phases');
  if (!school) {
    const err = new Error('School not found');
    err.statusCode = 404;
    throw err;
  }

  let scopePhase = null;
  if (reqScopePhase) scopePhase = reqScopePhase;
  else if (Array.isArray(school.phases) && school.phases.length === 1) scopePhase = school.phases[0];
  else if (Array.isArray(school.phases) && school.phases.includes('Secondary')) scopePhase = 'Secondary';
  else scopePhase = 'Primary';

  const defaultPassword = '123456';
  const passwordHash = await bcrypt.hash(defaultPassword, 10);

  const account = await Account.create({
    school: schoolId,
    role: 'teacher',
    username: username.toLowerCase().trim(),
    email: username.toLowerCase().trim(),
    passwordHash,
    mustChangePassword: true,
    scopePhase,
  });

  const teacher = await Teacher.create({
    school: schoolId,
    surname: personName.surname,
    middleName: personName.middleName,
    firstName: personName.firstName,
    fullName: personName.fullName,
    username: username.toLowerCase(),
    email: username.toLowerCase(),
    phone: normalizedPhone,
    phase: scopePhase,
    startYear: normalizedStartYear,
    account: account._id,
  });

  account.teacher = teacher._id;
  await account.save();
  return teacher;
};

exports.getTeacherProfile = async ({ schoolId, teacherId, academicYear }) => {
  const teacher = await Teacher.findOne({ school: schoolId, _id: teacherId }).lean();
  if (!teacher) {
    const err = new Error('teacher not found');
    err.status = 404;
    throw err;
  }
  const [teacherWithAssignments] = await attachTeacherAssignments([teacher], { schoolId, academicYear });
  return teacherWithAssignments;
};

exports.updateTeacherStatus = async ({ schoolId, reqScopePhase, teacherId, status }) => {
  const allowed = ['Active', 'Inactive'];
  if (!allowed.includes(status)) {
    const err = new Error('Invalid status');
    err.statusCode = 400;
    throw err;
  }

  const where = { _id: teacherId, school: schoolId };
  if (reqScopePhase) where.phase = reqScopePhase;

  const teacher = await Teacher.findOneAndUpdate(where, { status }, { new: true });
  if (!teacher) {
    const err = new Error('Teacher not found');
    err.statusCode = 404;
    throw err;
  }

  await Account.updateOne({ _id: teacher.account, school: schoolId }, { $set: { isActive: status === 'Active' } });
  return teacher;
};

exports.getMySubjects = async ({ schoolId, teacherId }) => {
  const assignments = await TeachingAssignment.find({ school: schoolId, teacher: teacherId })
    .populate('class', 'name level')
    .populate('subject', 'name code level')
    .sort({ createdAt: -1 });
  return { assignments };
};

exports.getClassSubjectPage = async ({ schoolId, teacherId, classId, subjectId }) => {
  const assignment = await TeachingAssignment.findOne({ school: schoolId, teacher: teacherId, class: classId, subject: subjectId })
    .populate('class', 'name level')
    .populate('subject', 'name code level');
  return { assignment };
};
