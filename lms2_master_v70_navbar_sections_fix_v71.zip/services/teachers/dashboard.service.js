const TeachingAssignment = require('../../models/TeachingAssignment');
const SubjectResultSubmission = require('../../models/SubjectResultSubmission');
const Student = require('../../models/Students');
const FormTeacherAssignment = require('../../models/FormTeacherAssignment');

function formatTeacherDisplayName(teacher) {
  if (!teacher) return null;
  return teacher.fullName || [teacher.firstName, teacher.surname].filter(Boolean).join(' ').trim() || null;
}

function buildFormTeacherSummary(assignments) {
  const valid = (assignments || []).filter(Boolean);
  if (!valid.length) return null;

  const wholeClassAssignment = valid.find((item) => !item.section);
  if (wholeClassAssignment) {
    return formatTeacherDisplayName(wholeClassAssignment.teacher);
  }

  return valid
    .map((item) => {
      const teacherName = formatTeacherDisplayName(item.teacher) || 'Unassigned';
      const sectionName = item.section?.name || 'Whole Class';
      return `${sectionName}: ${teacherName}`;
    })
    .join(' · ');
}


function buildSubmissionStatusMeta(submission, studentCount) {
  if (!studentCount) {
    return {
      label: 'No Students',
      tone: 'neutral',
      sortRank: 0,
      hint: 'This assignment currently has no active students.',
    };
  }

  if (!submission) {
    return {
      label: 'Not Started',
      tone: 'warning',
      sortRank: 1,
      hint: 'No subject computation or submission has been recorded yet.',
    };
  }

  if (submission.status === 'Submitted') {
    return {
      label: submission.hasIncompleteScores ? 'Submitted (Incomplete)' : 'Submitted',
      tone: submission.hasIncompleteScores ? 'warning' : 'success',
      sortRank: 4,
      hint: submission.hasIncompleteScores
        ? `${submission.incompleteStudentCount || 0} student record(s) are still incomplete.`
        : 'This subject has been submitted to the form teacher.',
    };
  }

  if (submission.status === 'Draft') {
    return {
      label: submission.hasIncompleteScores ? 'In Progress (Incomplete)' : 'In Progress',
      tone: submission.hasIncompleteScores ? 'warning' : 'primary',
      sortRank: 3,
      hint: submission.hasIncompleteScores
        ? `${submission.incompleteStudentCount || 0} student record(s) still need attention before submission.`
        : 'Scores have been worked on but not yet submitted.',
    };
  }

  return {
    label: submission.status || 'Open',
    tone: 'neutral',
    sortRank: 2,
    hint: 'Status recorded.',
  };
}

async function getAssignmentBundles({ schoolId, teacherId, academicYear, term }) {
  const assignments = await TeachingAssignment.find({
    school: schoolId,
    teacher: teacherId,
    ...(academicYear ? { academicYear: String(academicYear).trim() } : {}),
  })
    .populate('class')
    .populate('subject')
    .populate('section')
    .sort({ createdAt: -1 })
    .lean();

  if (!assignments.length) return [];

  const studentCountCache = new Map();
  const classFormTeacherCache = new Map();
  const submissions = await SubjectResultSubmission.find({
    school: schoolId,
    teacher: teacherId,
    ...(academicYear ? { academicYear: String(academicYear).trim() } : {}),
    ...(term ? { term: String(term).trim() } : {}),
  })
    .select('academicYear term class subject section status hasIncompleteScores incompleteStudentCount submittedAt computedAt')
    .lean();

  const submissionMap = new Map();
  for (const sub of submissions) {
    submissionMap.set(`${sub.academicYear}::${sub.term}::${String(sub.class)}::${String(sub.subject)}::${sub.section ? String(sub.section) : ''}`, sub);
  }

  const bundles = [];
  for (const assignment of assignments) {
    const classId = String(assignment.class?._id || assignment.class);
    const sectionId = assignment.section?._id ? String(assignment.section._id) : (assignment.section ? String(assignment.section) : '');
    const countKey = `${classId}::${sectionId}`;
    const formTeacherKey = sectionId ? `${classId}::${sectionId}` : `${classId}::all`;

    let studentCount = studentCountCache.get(countKey);
    if (typeof studentCount !== 'number') {
      const query = { school: schoolId, class: assignment.class?._id || assignment.class, status: 'Active' };
      if (sectionId) query.section = assignment.section?._id || assignment.section;
      studentCount = await Student.countDocuments(query);
      studentCountCache.set(countKey, studentCount);
    }

    let formTeacher = classFormTeacherCache.get(formTeacherKey);
    if (formTeacher === undefined) {
      if (sectionId) {
        formTeacher = await FormTeacherAssignment.findOne({
          school: schoolId,
          class: assignment.class?._id || assignment.class,
          academicYear: assignment.academicYear,
          section: assignment.section?._id || assignment.section,
        }).populate('teacher', 'fullName firstName surname').populate('section', 'name').lean();
      } else {
        const formTeacherAssignments = await FormTeacherAssignment.find({
          school: schoolId,
          class: assignment.class?._id || assignment.class,
          academicYear: assignment.academicYear,
        }).populate('teacher', 'fullName firstName surname').populate('section', 'name').lean();
        formTeacher = formTeacherAssignments.length === 1 ? formTeacherAssignments[0] : { teacher: { fullName: buildFormTeacherSummary(formTeacherAssignments) } };
      }
      classFormTeacherCache.set(formTeacherKey, formTeacher || null);
    }

    const subKey = `${assignment.academicYear}::${term || ''}::${String(assignment.class?._id || assignment.class)}::${String(assignment.subject?._id || assignment.subject)}::${sectionId}`;
    const submission = submissionMap.get(subKey) || null;
    const statusMeta = buildSubmissionStatusMeta(submission, studentCount);

    bundles.push({
      ...assignment,
      studentCount,
      submission,
      statusMeta,
      formTeacher,
      hasIncompleteScores: !!submission?.hasIncompleteScores,
      incompleteStudentCount: submission?.incompleteStudentCount || 0,
      isSubmitted: submission?.status === 'Submitted',
    });
  }

  return bundles;
}

async function getDashboardData({ schoolId, teacherId, academicYear, term }) {
  const assignments = await getAssignmentBundles({ schoolId, teacherId, academicYear, term });

  const classMap = new Map();
  let submittedCount = 0;
  let inProgressCount = 0;
  let pendingCount = 0;
  let incompleteCount = 0;

  for (const assignment of assignments) {
    const classId = String(assignment.class?._id || assignment.class);
    if (!classMap.has(classId)) {
      classMap.set(classId, {
        classId,
        className: assignment.class?.name || 'Class',
        sectionName: assignment.section?.name || null,
        subjectCount: 0,
        studentCount: 0,
        submittedCount: 0,
        inProgressCount: 0,
        pendingCount: 0,
        incompleteCount: 0,
        formTeacherName: null,
        _studentCountSeen: new Set(),
        _formTeacherNames: new Set(),
      });
    }
    const bucket = classMap.get(classId);
    const studentBucketKey = `${classId}::${assignment.section?._id || assignment.section || 'whole'}`;
    if (!bucket._studentCountSeen.has(studentBucketKey)) {
      bucket.studentCount += assignment.studentCount || 0;
      bucket._studentCountSeen.add(studentBucketKey);
    }
    const currentFormTeacherName = formatTeacherDisplayName(assignment.formTeacher?.teacher);
    if (currentFormTeacherName) bucket._formTeacherNames.add(currentFormTeacherName);
    bucket.subjectCount += 1;
    if (assignment.isSubmitted) bucket.submittedCount += 1;
    else if (assignment.submission?.status === 'Draft') bucket.inProgressCount += 1;
    else if ((assignment.studentCount || 0) > 0) bucket.pendingCount += 1;
    if (assignment.hasIncompleteScores) bucket.incompleteCount += 1;

    if (assignment.isSubmitted) submittedCount += 1;
    else if (assignment.submission?.status === 'Draft') inProgressCount += 1;
    else if ((assignment.studentCount || 0) > 0) pendingCount += 1;
    if (assignment.hasIncompleteScores) incompleteCount += 1;
  }

  const classSummaries = Array.from(classMap.values()).map((item) => {
    item.formTeacherName = item._formTeacherNames.size ? Array.from(item._formTeacherNames).join(' · ') : null;
    delete item._studentCountSeen;
    delete item._formTeacherNames;
    return item;
  }).sort((a, b) => a.className.localeCompare(b.className));
  const recentAssignments = [...assignments]
    .sort((a, b) => {
      const aRank = a.statusMeta?.sortRank || 0;
      const bRank = b.statusMeta?.sortRank || 0;
      if (bRank !== aRank) return bRank - aRank;
      return String(a.class?.name || '').localeCompare(String(b.class?.name || ''));
    })
    .slice(0, 8);

  return {
    assignments,
    assignmentsCount: assignments.length,
    classesCount: classSummaries.length,
    submittedCount,
    inProgressCount,
    pendingCount,
    incompleteCount,
    classSummaries,
    recentAssignments,
    academicYear,
    term,
  };
}

async function getClassOverviewData({ schoolId, teacherId, classId, academicYear, term }) {
  const assignments = (await getAssignmentBundles({ schoolId, teacherId, academicYear, term }))
    .filter((assignment) => String(assignment.class?._id || assignment.class) === String(classId))
    .sort((a, b) => String(a.subject?.name || '').localeCompare(String(b.subject?.name || '')));

  if (!assignments.length) {
    const err = new Error('Class overview not found for this teacher.');
    err.statusCode = 404;
    throw err;
  }

  const first = assignments[0];
  const classStudentCount = await Student.countDocuments({
    school: schoolId,
    class: first.class?._id || first.class,
    status: 'Active',
  });

  const formTeacherAssignments = await FormTeacherAssignment.find({
    school: schoolId,
    class: first.class?._id || first.class,
    academicYear: first.academicYear,
  }).populate('teacher', 'fullName firstName surname').populate('section', 'name').lean();

  return {
    classInfo: {
      id: String(first.class?._id || first.class),
      name: first.class?.name || 'Class',
      level: first.class?.level || null,
      phase: first.class?.phase || null,
      studentCount: classStudentCount,
      teacherSubjectCount: assignments.length,
      formTeacherName: buildFormTeacherSummary(formTeacherAssignments) || formatTeacherDisplayName(first.formTeacher?.teacher) || null,
      academicYear: first.academicYear,
      term: term || null,
    },
    assignments,
  };
}

module.exports = {
  getDashboardData,
  getClassOverviewData,
};
