const TeachingAssignment = require('../../models/TeachingAssignment');
const Student = require('../../models/Students');
const Score = require('../../models/score'); // we’ll create this model next
const Class = require('../../models/class');
const AssessmentPolicy = require('../../models/assessmentPolicy');
const { mongoTotalExpr, mongoGradeExpr } = require('../../utils/grading.util');
//const { getActiveAcademicYearName } = require('../academicYears/academicYear.service');
const AcademicYear = require('../../models/AcademicYear'); // adjust path if needed
const Term = require('../../models/Term'); // if you want active term too
const { Types } = require('mongoose');

const { getActiveTermByAcademicYear } = require('../academic/term.service');
const mongoose = require('mongoose');
const Students = require('../../models/Students');
const StudentSubject = require('../../models/StudentSubject');
const SubjectResultSubmission = require('../../models/SubjectResultSubmission');


function deriveTrackFromSectionName(sectionName) {
  const name = String(sectionName || '').trim().toUpperCase();
  if (name === 'SCIENCE') return 'Science';
  if (name === 'ART') return 'Art';
  if (name === 'COMMERCIAL') return 'Commercial';
  return null;
}

function getEffectiveStudentTrack(studentLike) {
  return studentLike?.track || deriveTrackFromSectionName(studentLike?.section?.name) || 'General';
}

async function resolveAcademicYearId(schoolId, academicYear) {
  if (mongoose.isValidObjectId(academicYear)) return academicYear;

  const doc = await AcademicYear.findOne({
    school: schoolId,
    name: String(academicYear).trim(),
  }).select('_id');

  return doc?._id || null;
}
// ✅ helper: teacher must own this assignment inside this school

async function ensureEligibleSubjectEnrollments({ schoolId, classId, sectionId, subjectDoc, sessionName }) {
  const studentQuery = { school: schoolId, class: classId, status: 'Active' };
  if (sectionId) studentQuery.section = sectionId;
  const students = await Student.find(studentQuery).select('_id track section').populate('section', 'name');
  if (!students.length) return [];

  const docs = [];
  for (const s of students) {
    const subjectType = subjectDoc?.type || 'GENERAL';
    if (subjectType === 'TRACK_CORE') {
      const tracks = Array.isArray(subjectDoc.tracks) ? subjectDoc.tracks : [];
      const effectiveTrack = getEffectiveStudentTrack(s);
      if (tracks.length && !tracks.includes(effectiveTrack)) continue;
    }
    docs.push({
      updateOne: {
        filter: { school: schoolId, student: s._id, subject: subjectDoc._id, session: sessionName },
        update: { $setOnInsert: { school: schoolId, student: s._id, subject: subjectDoc._id, session: sessionName, type: subjectType === 'ELECTIVE' ? 'borrowed' : 'base' } },
        upsert: true,
      }
    });
  }
  if (docs.length) await StudentSubject.bulkWrite(docs, { ordered: false });
  return students.map((s) => s._id);
}

async function getOwnedAssignment({ schoolId, teacherId, assignmentId }) {
  const assignment = await TeachingAssignment.findOne({
    _id: assignmentId,
    school: schoolId,
    teacher: teacherId,
  })
    .populate('class')
    .populate('subject')
    .populate('section');

  if (!assignment) {
    const err = new Error('Assignment not found or not allowed');
    err.statusCode = 403;
    throw err;
  }

  return assignment;
}

// 1) list teacher assignments
async function listTeacherAssignments({ schoolId, teacherId, academicYear, term }) {
  const assignments = await TeachingAssignment.find({
    school: schoolId,
    teacher: teacherId,
    ...(academicYear ? { academicYear: String(academicYear).trim() } : {}),
  })
    .populate('class')
    .populate('subject')
    .populate('section')
    .sort({ createdAt: -1 });

  const out = [];
  for (const assignment of assignments) {
    const classId = assignment.class?._id || assignment.class;
    const subjectId = assignment.subject?._id || assignment.subject;
    const sectionId = assignment.section?._id || assignment.section || null;
    let studentCount = 0;
    let resultStatus = 'Open';
    let setupIssue = '';
    let termName = term || '';

    try {
      await ensureEligibleSubjectEnrollments({
        schoolId,
        classId,
        sectionId,
        subjectDoc: assignment.subject,
        sessionName: assignment.academicYear,
      });

      const enrolled = await StudentSubject.find({ school: schoolId, subject: subjectId, session: assignment.academicYear }).select('student');
      const enrolledIds = enrolled.map((item) => item.student);
      const studentQuery = { school: schoolId, class: classId, status: 'Active', _id: { $in: enrolledIds } };
      if (sectionId) studentQuery.section = sectionId;
      studentCount = await Student.countDocuments(studentQuery);

      const academicYearId = await resolveAcademicYearId(schoolId, assignment.academicYear);
      if (!academicYearId) {
        setupIssue = `Academic year "${assignment.academicYear}" is not linked yet.`;
      } else {
        const activeTerm = await getActiveTermByAcademicYear({ schoolId, academicYearId });
        if (!activeTerm) {
          setupIssue = `No active term is set for ${assignment.academicYear}.`;
        } else {
          termName = activeTerm.name;
          const sub = await SubjectResultSubmission.findOne({
            school: schoolId,
            academicYear: assignment.academicYear,
            term: termName,
            class: classId,
            subject: subjectId,
            section: sectionId,
          }).select('status autoSubmitted').lean();
          if (sub?.autoSubmitted) resultStatus = 'Auto Submitted (No Students)';
          else if (sub?.status) resultStatus = sub.status;
          if (!studentCount) {
            resultStatus = 'No Students Yet';
          }
        }
      }
    } catch (err) {
      setupIssue = err.message || 'This assignment needs setup before score entry can open.';
      resultStatus = 'Setup Required';
    }

    if (setupIssue && resultStatus === 'Open') resultStatus = 'Setup Required';

    out.push({ ...assignment.toObject(), resultStatus, studentCount, setupIssue, term: termName || term || '' });
  }
  return { assignments: out };
}

// 2) get entry page data: students + existing saved scores for that assessment type
// assumes these are imported above this file:
// const Student = require('../models/Student');
// const Class = require('../models/Class');
// const Score = require('../models/Score');
// const AssessmentPolicy = require('../models/assessmentPolicy');
// const { getActiveTerm } = require('../services/terms.service'); // or whichever file exports getActiveTerm
// and getOwnedAssignment is available in scope

async function getEntryPageData({ schoolId, teacherId, assignmentId }) {
  const assignment = await getOwnedAssignment({ schoolId, teacherId, assignmentId });

  // ✅ normalize ids
  const classId = assignment.class?._id || assignment.class;
  const subjectId = assignment.subject?._id || assignment.subject;
  const sectionId = assignment.section?._id || assignment.section || null;

  // ✅ students are separated by section (if assignment has section)
  const studentQuery = {
    school: schoolId,
    class: classId,
    // do not depend on student.currentSession here; actual subject enrollment already carries the session
    status: 'Active',
  };
  if (sectionId) studentQuery.section = sectionId;

  // Ensure GENERAL/TRACK_CORE subjects have enrollment records for eligible students.
  await ensureEligibleSubjectEnrollments({
    schoolId,
    classId,
    sectionId,
    subjectDoc: assignment.subject,
    sessionName: assignment.academicYear,
  });

  const enrolled = await StudentSubject.find({
    school: schoolId,
    subject: subjectId,
    session: assignment.academicYear,
  }).select('student');

  const enrolledIds = enrolled.map((e) => e.student);
  studentQuery._id = { $in: enrolledIds };

  const students = await Student.find(studentQuery).select('name').sort({ name: 1 });

  // ✅ level (Primary/JSS/SSS)
  let level = assignment.class?.level;
  if (!level) {
    const cls = await Class.findById(classId).select('level').lean();
    level = cls?.level;
  }

  // ✅ policy lookup uses academicYear string
  const policy = await AssessmentPolicy.findOne({
    school: schoolId,
    academicYear: assignment.academicYear, // string
    level,
  }).select('max');

  if (!policy) {
    const err = new Error(
      `No assessment policy set for ${level} (${assignment.academicYear}). Ask admin.`
    );
    err.statusCode = 400;
    throw err;
  }

  // Scoresheet now captures all components at once, so there is no single `type` here.
  // Keep returning the full component max map for the UI and downstream validation.
  const maxAllowed = null;

  // ✅ resolve academicYearId for Term lookup (Term uses ObjectId)
  const academicYearId = await resolveAcademicYearId(schoolId, assignment.academicYear);
  if (!academicYearId) {
    const err = new Error(`Academic year "${assignment.academicYear}" not found for this school`);
    err.statusCode = 400;
    throw err;
  }

  // ✅ get active term for that academicYear (term is saved as STRING in Score)
  const activeTerm = await getActiveTermByAcademicYear({ schoolId, academicYearId });
  if (!activeTerm) {
    const err = new Error(`No active term set for ${assignment.academicYear}`);
    err.statusCode = 400;
    throw err;
  }

  const term = activeTerm.name; // ✅ STRING e.g "First Term"
  const academicYear = assignment.academicYear; // ✅ STRING

  // ✅ existing scores for those students (match class+subject+year+term + optional section)
  const scoreQuery = {
    school: schoolId,
    class: classId,
    subject: subjectId,
    academicYear, // string
    term,         // string
    student: { $in: students.map(s => s._id) },
  };
  //if (sectionId) scoreQuery.section = sectionId;

  const existing = await Score.find(scoreQuery);

  // ✅ map studentId -> scoreDoc
  const scoreMap = {};
  for (const doc of existing) {
    scoreMap[String(doc.student)] = doc;
  }

  return {
    assignment,
    students,
    scoreMap,
    academicYear,
    term,       // ✅ string for UI + score queries
    componentMax: policy.max || {},
    maxAllowed,
  };
}// 3) save scores (incremental updates)
// scores is an object: { studentId1: "12", studentId2: "" }
async function saveScores({ schoolId, teacherId, assignmentId, scores }) {
  const toId = (v) => (Types.ObjectId.isValid(v) ? new Types.ObjectId(v) : v);
  const assignment = await getOwnedAssignment({ schoolId, teacherId, assignmentId });

  const classId = assignment.class?._id || assignment.class;
  const subjectId = assignment.subject?._id || assignment.subject;
  const sectionId = assignment.section?._id || assignment.section || null;
  const academicYear = assignment.academicYear;

  const academicYearId = await resolveAcademicYearId(schoolId, academicYear);
  if (!academicYearId) {
    throw Object.assign(new Error(`Academic year "${academicYear}" not found`), { statusCode: 400 });
  }

  const activeTerm = await getActiveTermByAcademicYear({ schoolId, academicYearId });
  if (!activeTerm) {
    throw Object.assign(new Error(`No active term set for ${academicYear}`), { statusCode: 400 });
  }

  if (activeTerm.isResultOpen === false) {
    throw Object.assign(new Error(`Term is locked: ${activeTerm.name}. Score entry is closed.`), { statusCode: 403 });
  }

  const term = activeTerm.name;

  let level = assignment.class?.level;
  if (!level) {
    const cls = await Class.findById(classId).select('level').lean();
    level = cls?.level;
  }
  if (!level) {
    throw Object.assign(new Error('Class level not found (Primary/JSS/SSS)'), { statusCode: 400 });
  }

  const policy = await AssessmentPolicy.findOne({ school: schoolId, academicYear, level }).select('max').lean();
  if (!policy) {
    throw Object.assign(new Error(`No assessment policy set for ${level} (${academicYear}). Ask admin.`), { statusCode: 400 });
  }

  const schoolObjId = toId(schoolId);
  const classObjId = toId(classId);
  const subjectObjId = toId(subjectId);
  const sectionObjId = sectionId ? toId(sectionId) : null;
  const ops = [];
  const totalExpr = mongoTotalExpr();
  const gradeExpr = mongoGradeExpr(totalExpr);

  for (const [studentId, rawScores] of Object.entries(scores || {})) {
    if (!rawScores || typeof rawScores !== 'object') continue;

    const studentObjId = toId(studentId);
    const setFields = {
      school: schoolObjId,
      student: studentObjId,
      class: classObjId,
      subject: subjectObjId,
      academicYear,
      term,
      ...(sectionObjId ? { section: sectionObjId } : {}),
    };

    let hasAnyProvidedValue = false;

    for (const key of ['ca1', 'ca2', 'test1', 'test2', 'exam']) {
      if (!(key in rawScores)) continue;
      const raw = rawScores[key];
      if (raw === '' || raw === null || raw === undefined) continue;

      const value = Number(raw);
      if (Number.isNaN(value) || value < 0) continue;

      const maxAllowed = policy.max?.[key];
      if (typeof maxAllowed !== 'number') {
        throw Object.assign(new Error(`No max score set for "${key}" in policy`), { statusCode: 400 });
      }
      if (value > maxAllowed) {
        throw Object.assign(new Error(`${key.toUpperCase()} cannot be more than ${maxAllowed} for ${level} (${academicYear})`), { statusCode: 400 });
      }

      setFields[key] = value;
      hasAnyProvidedValue = true;
    }

    if (!hasAnyProvidedValue) continue;

    const filter = {
      school: schoolObjId,
      student: studentObjId,
      class: classObjId,
      subject: subjectObjId,
      academicYear,
      term,
    };

    ops.push({
      updateOne: {
        filter,
        update: [
          { $set: setFields },
          { $set: { total: totalExpr, grade: gradeExpr } },
        ],
        upsert: true,
      },
    });
  }

  if (ops.length) {
    await Score.bulkWrite(ops);
  }

  return { saved: ops.length, term, academicYear };
}
module.exports = {
  listTeacherAssignments,
  getEntryPageData,
  saveScores,
};


function buildIncompleteSummary(students, scoreMap) {
  const requiredComponents = ['ca1', 'ca2', 'test1', 'test2', 'exam'];
  const incompleteStudents = [];
  for (const student of students || []) {
    const doc = scoreMap[String(student._id)];
    const missingComponents = requiredComponents.filter((key) => !doc || doc[key] === null || doc[key] === undefined || doc[key] === '');
    if (missingComponents.length) {
      incompleteStudents.push({
        student: student._id,
        name: student.name,
        missingComponents,
      });
    }
  }
  return {
    hasIncompleteScores: incompleteStudents.length > 0,
    incompleteStudentCount: incompleteStudents.length,
    incompleteStudents,
  };
}

async function listSubjectSubmissionMap({ schoolId, academicYear, term, teacherId }) {
  const docs = await SubjectResultSubmission.find({ school: schoolId, academicYear, term, teacher: teacherId })
    .select('class subject section status');
  const map = new Map();
  for (const doc of docs) {
    map.set(`${doc.class}::${doc.subject}::${doc.section || ''}`, doc.status);
  }
  return map;
}

async function computeSubjectResult({ schoolId, teacherId, assignmentId, allowIncomplete = false }) {
  const data = await getEntryPageData({ schoolId, teacherId, assignmentId });
  if (!data.students.length) {
    const assignment = await getOwnedAssignment({ schoolId, teacherId, assignmentId });
    await SubjectResultSubmission.findOneAndUpdate({
      school: schoolId,
      academicYear: assignment.academicYear,
      term: data.term,
      class: assignment.class?._id || assignment.class,
      subject: assignment.subject?._id || assignment.subject,
      section: assignment.section?._id || assignment.section || null,
    }, {
      $set: {
        teacher: teacherId,
        status: 'Submitted',
        computedAt: new Date(),
        submittedAt: new Date(),
        autoSubmitted: true,
        hasIncompleteScores: false,
        incompleteStudentCount: 0,
        incompleteStudents: [],
      }
    }, { upsert: true, new: true });
    return { autoSubmitted: true, hasIncompleteScores: false, incompleteStudents: [] };
  }
  const incompleteSummary = buildIncompleteSummary(data.students, data.scoreMap);
  if (incompleteSummary.hasIncompleteScores && !allowIncomplete) {
    const err = new Error('Enter all score components for all students first so totals can be computed.');
    err.statusCode = 400;
    err.incompleteSummary = incompleteSummary;
    throw err;
  }
  const assignment = await getOwnedAssignment({ schoolId, teacherId, assignmentId });
  await SubjectResultSubmission.findOneAndUpdate({
      school: schoolId,
      academicYear: assignment.academicYear,
      term: data.term,
      class: assignment.class?._id || assignment.class,
      subject: assignment.subject?._id || assignment.subject,
      section: assignment.section?._id || assignment.section || null,
    }, {
      $set: {
        teacher: teacherId,
        status: 'Draft',
        computedAt: new Date(),
        hasIncompleteScores: incompleteSummary.hasIncompleteScores,
        incompleteStudentCount: incompleteSummary.incompleteStudentCount,
        incompleteStudents: incompleteSummary.incompleteStudents,
      }
    }, { upsert: true, new: true });
  return { hasIncompleteScores: incompleteSummary.hasIncompleteScores, incompleteStudents: incompleteSummary.incompleteStudents };
}

async function submitSubjectResult({ schoolId, teacherId, assignmentId, allowIncomplete = false }) {
  const computed = await computeSubjectResult({ schoolId, teacherId, assignmentId, allowIncomplete });
  const assignment = await getOwnedAssignment({ schoolId, teacherId, assignmentId });
  if (computed && computed.autoSubmitted) return { ...computed, classId: assignment.class?._id || assignment.class, subjectId: assignment.subject?._id || assignment.subject, term: activeTerm.name, academicYear: assignment.academicYear };
  const academicYearId = await resolveAcademicYearId(schoolId, assignment.academicYear);
  const activeTerm = await getActiveTermByAcademicYear({ schoolId, academicYearId });
  await SubjectResultSubmission.findOneAndUpdate({
      school: schoolId,
      academicYear: assignment.academicYear,
      term: activeTerm.name,
      class: assignment.class?._id || assignment.class,
      subject: assignment.subject?._id || assignment.subject,
      section: assignment.section?._id || assignment.section || null,
    }, {
      $set: {
        status: 'Submitted',
        teacher: teacherId,
        submittedAt: new Date(),
        hasIncompleteScores: !!computed?.hasIncompleteScores,
        incompleteStudentCount: computed?.incompleteStudents?.length || 0,
        incompleteStudents: computed?.incompleteStudents || [],
      }
    }, { upsert: true, new: true });
  return { ...(computed || {}), classId: assignment.class?._id || assignment.class, subjectId: assignment.subject?._id || assignment.subject, term: activeTerm.name, academicYear: assignment.academicYear };
}

module.exports.computeSubjectResult = computeSubjectResult;
module.exports.submitSubjectResult = submitSubjectResult;
