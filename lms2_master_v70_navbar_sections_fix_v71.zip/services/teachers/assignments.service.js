const TeachingAssignment = require('../..//models/TeachingAssignment');
const Subject = require('../../models/Subject');
const Teacher = require('../../models/Teacher');
const ClassModel = require('../../models/class');
const Section = require('../../models/section');
const ClassSubject = require('../../models/ClassSubject');

function ensureAcademicYearName(academicYear) {
  const name = String(academicYear || '').trim();
  if (!name) {
    const err = new Error('No active academic year set for this school. Set it under Academic Years.');
    err.statusCode = 400;
    throw err;
  }
  return name;
}

function subjectFilterByScope(reqScopePhase) {
  if (reqScopePhase === 'Primary') return { level: 'Primary' };
  if (reqScopePhase === 'Secondary') return { level: { $in: ['JSS', 'SSS'] } };
  return {}; // owner
}

function classFilterByScope(reqScopePhase) {
  if (reqScopePhase === 'Primary') return { phase: 'Primary' };
  if (reqScopePhase === 'Secondary') return { phase: 'Secondary' };
  return {}; // owner
}

function teacherFilterByScope(reqScopePhase) {
  if (reqScopePhase === 'Primary') return { phase: 'Primary' };
  if (reqScopePhase === 'Secondary') return { phase: 'Secondary' };
  return {}; // owner
}

exports.getAssignmentsPageData = async ({ schoolId, reqScopePhase }) => {
  const [teachers, rawClasses, assignments, subjects, sections] = await Promise.all([
    Teacher.find({ school: schoolId, ...teacherFilterByScope(reqScopePhase) }).sort({ fullName: 1 }).lean(),
    ClassModel.find({ school: schoolId, ...classFilterByScope(reqScopePhase) }).sort({ phase: 1, level: 1, name: 1 }).lean(),
    TeachingAssignment.find({ school: schoolId })
      .populate('teacher', 'fullName phase')
      .populate('subject', 'name code level type tracks')
      .populate('class', 'name phase level')
      .populate('section', 'name')
      .lean(),
    Subject.find({ school: schoolId, status: 'Active', ...subjectFilterByScope(reqScopePhase) }).sort({ level: 1, name: 1 }).lean(),
    Section.find({ school: schoolId }).select('_id class name').lean(),
  ]);

  const sectionsByClass = new Map();
  for (const sec of sections) {
    const key = String(sec.class);
    if (!sectionsByClass.has(key)) sectionsByClass.set(key, []);
    sectionsByClass.get(key).push(sec);
  }

  const classes = rawClasses.map((klass) => ({
    ...klass,
    sections: (sectionsByClass.get(String(klass._id)) || []).sort((a, b) => String(a.name).localeCompare(String(b.name))),
  }));

  return {
    title: 'Assign Subjects to Teachers',
    teachers,
    classes,
    assignments,
    allSubjects: subjects,
  };
};

exports.createAssignment = async ({
  schoolId,
  reqScopePhase,
  academicYear,
  teacherId,
  subjectIds = [],
  classIds = [],
}) => {
  const yearName = ensureAcademicYearName(academicYear);
  const ids = Array.isArray(subjectIds) ? subjectIds.filter(Boolean) : [subjectIds].filter(Boolean);
  const clsIds = Array.isArray(classIds) ? classIds.filter(Boolean) : [classIds].filter(Boolean);

  if (!teacherId || ids.length === 0 || clsIds.length === 0) {
    const err = new Error('Teacher, at least one subject, and at least one class are required.');
    err.statusCode = 400;
    throw err;
  }

  const [teacher, subjects, classes, classSections] = await Promise.all([
    Teacher.findOne({ _id: teacherId, school: schoolId }).select('_id phase fullName'),
    Subject.find({ _id: { $in: ids }, school: schoolId, status: 'Active' }).select('_id level name code type tracks'),
    ClassModel.find({ _id: { $in: clsIds }, school: schoolId }).select('_id name phase level'),
    Section.find({ school: schoolId, class: { $in: clsIds } }).select('_id class name phase').lean(),
  ]);

  if (!teacher) {
    const err = new Error('Teacher not found');
    err.statusCode = 404;
    throw err;
  }
  if (subjects.length === 0 || classes.length === 0) {
    const err = new Error('Selected subjects or classes were not found');
    err.statusCode = 404;
    throw err;
  }

  const classMap = new Map(classes.map((c) => [String(c._id), c]));
  const sectionsByClass = {};
  for (const sec of classSections) {
    const key = String(sec.class);
    if (!sectionsByClass[key]) sectionsByClass[key] = [];
    sectionsByClass[key].push(sec);
  }

  function findSectionByTrack(classId, trackName) {
    const wanted = String(trackName || '').trim().toLowerCase();
    return (sectionsByClass[String(classId)] || []).find((sec) => String(sec.name || '').trim().toLowerCase() === wanted);
  }

  const docs = [];
  for (const rawClassId of clsIds) {
    const cls = classMap.get(String(rawClassId));
    if (!cls) continue;

    if (reqScopePhase && cls.phase !== reqScopePhase) continue;
    if (teacher.phase !== cls.phase) continue;

    for (const subject of subjects) {
      if (cls.phase === 'Primary' && subject.level !== 'Primary') continue;
      if (cls.level === 'JSS' && subject.level !== 'JSS') continue;
      if (cls.level === 'SSS' && subject.level !== 'SSS') continue;

      const tracks = Array.isArray(subject.tracks) ? subject.tracks.filter(Boolean) : [];
      const hasTrackTargeting = cls.level === 'SSS' && tracks.length > 0;

      if (hasTrackTargeting) {
        for (const track of tracks) {
          const sec = findSectionByTrack(cls._id, track);
          if (!sec) continue;
          docs.push({
            school: schoolId,
            teacher: teacher._id,
            subject: subject._id,
            class: cls._id,
            section: sec._id,
            academicYear: yearName,
          });
        }
      } else {
        docs.push({
          school: schoolId,
          teacher: teacher._id,
          subject: subject._id,
          class: cls._id,
          section: null,
          academicYear: yearName,
        });
      }
    }
  }

  let createdCount = 0;
  for (const doc of docs) {
    try {
      await TeachingAssignment.create(doc);
      createdCount += 1;
    } catch (e) {
      if (e.code !== 11000) throw e;
    }
  }

  return { createdCount };
};

exports.deleteAssignment = async ({ schoolId, assignmentId }) => {
  const deleted = await TeachingAssignment.findOneAndDelete({
    _id: assignmentId,
    school: schoolId,
  });

  if (!deleted) {
    const err = new Error('Assignment not found');
    err.statusCode = 404;
    throw err;
  }
};