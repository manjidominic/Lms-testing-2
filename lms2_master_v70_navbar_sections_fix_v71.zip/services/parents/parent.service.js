const Parent = require('../../models/Parent');
const Student = require('../../models/Students');
const { getStudentPublishedResult, getStudentPublishedResultHistory } = require('../results');
const { getStudentAcademicHistory } = require('../students/academicHistory.service');

async function getParentRecord({ schoolId, parentId }) {
  const parent = await Parent.findOne({ _id: parentId, school: schoolId, isActive: true }).lean();
  if (!parent) {
    const err = new Error('Parent record not found');
    err.statusCode = 404;
    throw err;
  }
  return parent;
}

async function getChildren({ schoolId, parentId }) {
  return Student.find({ school: schoolId, parent: parentId })
    .populate('class')
    .populate('section')
    .sort({ phase: 1, level: 1, name: 1 })
    .lean();
}

async function getOwnedChild({ schoolId, parentId, studentId }) {
  const child = await Student.findOne({ _id: studentId, school: schoolId, parent: parentId })
    .populate('class')
    .populate('section')
    .lean();
  if (!child) {
    const err = new Error('Child not found for this parent');
    err.statusCode = 404;
    throw err;
  }
  return child;
}

async function getDashboardData({ schoolId, parentId, currentAcademicYear, currentTerm }) {
  const parent = await getParentRecord({ schoolId, parentId });
  const children = await getChildren({ schoolId, parentId });
  const cards = await Promise.all(children.map(async (child) => {
    let latest = null;
    try {
      const history = await getStudentPublishedResultHistory({ schoolId, studentId: child._id, studentEmail: child.email || '', studentUsername: child.username || '' });
      latest = history.snapshots?.[history.snapshots.length - 1] || null;
    } catch (err) {}
    return { child, latest };
  }));
  return { parent, children, cards, currentAcademicYear, currentTerm };
}

async function getChildResultData({ schoolId, parentId, studentId, academicYear, term }) {
  const child = await getOwnedChild({ schoolId, parentId, studentId });
  let snapshot = null;
  let infoMessage = null;
  let pageAcademicYear = academicYear || null;
  let pageTerm = term || null;
  try {
    const data = await getStudentPublishedResult({ schoolId, studentId: child._id, academicYear, term, studentEmail: child.email || '', studentUsername: child.username || '' });
    snapshot = data.snapshot;
  } catch (err) {
    if (err.statusCode !== 403 && err.statusCode !== 404) throw err;
    const history = await getStudentPublishedResultHistory({ schoolId, studentId: child._id, studentEmail: child.email || '', studentUsername: child.username || '' });
    if (history.snapshots?.length) {
      snapshot = history.snapshots[history.snapshots.length - 1];
      pageAcademicYear = snapshot.academicYear;
      pageTerm = snapshot.term;
      infoMessage = 'Current term result is not published yet. Showing the latest published result instead.';
    } else {
      infoMessage = 'No published result is available yet.';
    }
  }
  return { child, snapshot, infoMessage, academicYear: pageAcademicYear, term: pageTerm };
}

async function getChildProfileData({ schoolId, parentId, studentId }) {
  const child = await getOwnedChild({ schoolId, parentId, studentId });
  const history = await getStudentPublishedResultHistory({ schoolId, studentId: child._id, studentEmail: child.email || '', studentUsername: child.username || '' });
  const academicHistory = await getStudentAcademicHistory({ schoolId, student: child, resultHistory: history.grouped });
  return { child, resultHistory: history.grouped, resultSnapshots: history.snapshots, academicArchive: academicHistory.archiveGroups, movementHistory: academicHistory.movementHistory, currentStanding: academicHistory.currentStanding };
}

async function listParentsWithChildren({ schoolId }) {
  const parents = await Parent.find({ school: schoolId }).sort({ fullName: 1 }).lean();
  const students = await Student.find({ school: schoolId, parent: { $ne: null } }).select('parent name class').populate('class').lean();
  const grouped = new Map();
  for (const st of students) {
    const key = String(st.parent);
    if (!grouped.has(key)) grouped.set(key, []);
    grouped.get(key).push(st);
  }
  return { parents: parents.map((p) => ({ ...p, children: grouped.get(String(p._id)) || [] })) };
}

async function getParentAdminView({ schoolId, parentId }) {
  const parent = await Parent.findOne({ _id: parentId, school: schoolId }).lean();
  if (!parent) {
    const err = new Error('Parent not found');
    err.statusCode = 404;
    throw err;
  }
  const children = await getChildren({ schoolId, parentId });
  return { parent, children };
}

async function getLinkFormData({ schoolId, parentId, q = '' }) {
  const parent = await Parent.findOne({ _id: parentId, school: schoolId }).lean();
  const regex = q ? new RegExp(String(q).trim(), 'i') : null;
  const find = { school: schoolId };
  if (regex) {
    find.$or = [
      { name: regex },
      { surname: regex },
      { firstName: regex },
      { admissionNo: regex },
      { email: regex },
      { username: regex },
    ];
  }
  const students = await Student.find(find).populate('class').sort({ name: 1 }).limit(50).lean();
  return { parent, students, q };
}

async function linkStudentsToParent({ schoolId, parentId, studentIds = [] }) {
  if (!studentIds.length) return 0;
  const parent = await Parent.findOne({ _id: parentId, school: schoolId }).lean();
  if (!parent) {
    const err = new Error('Parent not found');
    err.statusCode = 404;
    throw err;
  }
  const result = await Student.updateMany(
    { school: schoolId, _id: { $in: studentIds } },
    {
      $set: {
        parent: parentId,
        parentName: parent.fullName || null,
        parentEmail: parent.email || null,
        parentPhone: parent.phone || null,
      },
    },
  );
  return result.modifiedCount || 0;
}

async function unlinkStudentFromParent({ schoolId, parentId, studentId }) {
  const student = await Student.findOne({ school: schoolId, _id: studentId, parent: parentId }).select('phase');
  if (!student) return;
  await Student.updateOne(
    { _id: student._id },
    {
      $set: {
        parent: null,
        parentName: null,
        parentEmail: null,
        parentPhone: null,
        portalAccess: student.phase === 'Primary' ? 'parent_only' : 'student_and_parent',
      },
    },
  );
}

module.exports = { getDashboardData, getChildResultData, getChildProfileData, listParentsWithChildren, getParentAdminView, getLinkFormData, linkStudentsToParent, unlinkStudentFromParent };
