const Term = require('../../models/Term');
const AcademicYear = require('../../models/AcademicYear');


async function ensureStandardTerms({ schoolId, academicYearId, activateFirstTerm = false }) {
  const count = await Term.countDocuments({ school: schoolId, academicYear: academicYearId });
  if (count > 0) {
    if (activateFirstTerm) {
      await Term.updateMany({ school: schoolId }, { $set: { isActive: false } });
      await Term.findOneAndUpdate(
        { school: schoolId, academicYear: academicYearId, name: 'First Term' },
        { $set: { isActive: true } },
        { new: true }
      );
    }
    return;
  }

  await Term.insertMany([
    { school: schoolId, academicYear: academicYearId, name: 'First Term', isActive: !!activateFirstTerm, isResultOpen: true },
    { school: schoolId, academicYear: academicYearId, name: 'Second Term', isActive: false, isResultOpen: true },
    { school: schoolId, academicYear: academicYearId, name: 'Third Term', isActive: false, isResultOpen: true },
  ]);
}

function normalizeYearName(value) {
  const name = String(value || '').trim();
  const ok = /^\d{4}\/\d{4}$/.test(name);
  if (!ok) {
    const err = new Error("Academic year must look like 2025/2026");
    err.statusCode = 400;
    throw err;
  }
  return name;
}

// List all years for this school
exports.listAcademicYears = async ({ schoolId }) => {
  return AcademicYear.find({ school: schoolId }).sort({ createdAt: -1 });
};

// Create a year (optionally set active)
exports.createAcademicYear = async ({ schoolId, name, makeActive }) => {
  const yearName = normalizeYearName(name);

  // If this new year should be active, deactivate others first
  if (makeActive) {
    await AcademicYear.updateMany(
      { school: schoolId },
      { $set: { isActive: false } }
    );
    await Term.updateMany(
      { school: schoolId },
      { $set: { isActive: false } }
    );
  }

  try {
    const created = await AcademicYear.create({
      school: schoolId,
      name: yearName,
      isActive: !!makeActive,
    });

    await ensureStandardTerms({ schoolId, academicYearId: created._id, activateFirstTerm: !!makeActive });
    return created;
  } catch (e) {
    // Duplicate year name for same school
    if (e.code === 11000) {
      const err = new Error('This academic year already exists for your school.');
      err.statusCode = 400;
      throw err;
    }
    throw e;
  }
};

// Set one year active (and all others inactive)
exports.activateAcademicYear = async ({ schoolId, academicYearId }) => {
  // Turn off all first
  await AcademicYear.updateMany(
    { school: schoolId },
    { $set: { isActive: false } }
  );
  await Term.updateMany(
    { school: schoolId },
    { $set: { isActive: false } }
  );

  const updated = await AcademicYear.findOneAndUpdate(
    { _id: academicYearId, school: schoolId },
    { $set: { isActive: true } },
    { new: true }
  );

  if (!updated) {
    const err = new Error('Academic year not found.');
    err.statusCode = 404;
    throw err;
  }

  await ensureStandardTerms({ schoolId, academicYearId: updated._id, activateFirstTerm: true });
  return updated;
};

// Helper for later (term/results)
exports.getActiveAcademicYear = async ({ schoolId }) => {
  return AcademicYear.findOne({ school: schoolId, isActive: true });
};