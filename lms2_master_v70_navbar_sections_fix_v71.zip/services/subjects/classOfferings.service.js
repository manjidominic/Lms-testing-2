const Subject = require('../../models/Subject');
const ClassModel = require('../../models/class');
const ClassSubject = require('../../models/ClassSubject');

function httpError(message, statusCode = 400) {
  const err = new Error(message);
  err.statusCode = statusCode;
  return err;
}

function normalizeIds(ids) {
  if (!ids) return [];
  if (Array.isArray(ids)) return ids.map(String);
  return [String(ids)];
}

exports.getSubjectClassOfferings = async ({ schoolId, subjectId, reqScopePhase }) => {
  const subject = await Subject.findOne({ _id: subjectId, school: schoolId });
  if (!subject) throw httpError('Subject not found', 404);

  // Classes available must match subject level
  const classFilter = { school: schoolId, level: subject.level };
  if (reqScopePhase === 'Primary') classFilter.phase = 'Primary';
  if (reqScopePhase === 'Secondary') classFilter.phase = 'Secondary';

  const classes = await ClassModel.find(classFilter).sort({ order: 1, name: 1 });
  const offerings = await ClassSubject.find({ school: schoolId, subject: subject._id }).select('class offeringType');
  const offeredClassIds = new Set(offerings.map((o) => String(o.class)));

  return { subject, classes, offeredClassIds };
};

exports.updateSubjectClassOfferings = async ({ schoolId, subjectId, classIds, reqScopePhase }) => {
  const subject = await Subject.findOne({ _id: subjectId, school: schoolId });
  if (!subject) throw httpError('Subject not found', 404);

  const desired = new Set(normalizeIds(classIds));

  // Validate classes belong to this school and match subject level (+ scopePhase)
  const classFilter = { school: schoolId, level: subject.level, _id: { $in: Array.from(desired) } };
  if (reqScopePhase === 'Primary') classFilter.phase = 'Primary';
  if (reqScopePhase === 'Secondary') classFilter.phase = 'Secondary';

  const validClasses = await ClassModel.find(classFilter).select('_id');
  const validSet = new Set(validClasses.map((c) => String(c._id)));

  for (const id of desired) {
    if (!validSet.has(id)) {
      throw httpError('One or more selected classes are invalid for this subject (wrong school/level/phase).', 400);
    }
  }

  // Current offerings
  const existing = await ClassSubject.find({ school: schoolId, subject: subject._id }).select('_id class');
  const existingSet = new Set(existing.map((e) => String(e.class)));

  // Remove offerings not desired
  const toRemove = existing.filter((e) => !desired.has(String(e.class))).map((e) => e._id);
  if (toRemove.length) {
    await ClassSubject.deleteMany({ _id: { $in: toRemove } });
  }

  // Add missing
  const toAdd = Array.from(desired).filter((id) => !existingSet.has(id));
  if (toAdd.length) {
    await ClassSubject.insertMany(
      toAdd.map((cid) => ({
        school: schoolId,
        class: cid,
        subject: subject._id,
        offeringType: subject.type || 'CORE',
      }))
    );
  }

  return { ok: true };
};
