const Subject = require('../../models/Subject');
const School = require('../../models/School');
const ClassSubject = require('../../models/ClassSubject');
const TeachingAssignment = require('../../models/TeachingAssignment');
const StudentSubject = require('../../models/StudentSubject');

function allowedLevelsForScope(scopePhase) {
  if (scopePhase === 'Primary') return new Set(['Primary']);
  if (scopePhase === 'Secondary') return new Set(['JSS', 'SSS']);
  return new Set(['Primary', 'JSS', 'SSS']);
}

async function resolveSchoolDefaultScopePhase(schoolId) {
  const school = await School.findById(schoolId).select('phases').lean();
  if (!school) {
    const err = new Error('School not found');
    err.statusCode = 404;
    throw err;
  }
  const phases = Array.isArray(school.phases) ? school.phases : [];
  return { phases };
}

exports.listSubjects = async ({ schoolId, status = 'Active', reqScopePhase }) => {
  const filter = { school: schoolId };
  if (status !== 'all') filter.status = 'Active';
  if (reqScopePhase === 'Primary') filter.level = 'Primary';
  if (reqScopePhase === 'Secondary') filter.level = { $in: ['JSS', 'SSS'] };
  return Subject.find(filter).sort({ name: 1 });
};

exports.createSubject = async ({ schoolId, reqScopePhase, name, code, level, status, type, tracks }) => {
  const cleanName = String(name || '').trim();
  const cleanCode = String(code || '').trim();
  const cleanLevel = String(level || '').trim();
  let cleanType = String(type || '').trim() || 'GENERAL';
  if (cleanType === 'CORE') cleanType = 'GENERAL';
  const cleanTracks = Array.isArray(tracks)
    ? tracks.map((t) => String(t).trim()).filter(Boolean)
    : String(tracks || '')
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean);
  const cleanStatus = status === 'Inactive' ? 'Inactive' : 'Active';

  const { phases } = await resolveSchoolDefaultScopePhase(schoolId);
  const schoolAllowsPrimary = phases.includes('Primary');
  const schoolAllowsSecondary = phases.includes('Secondary');
  const allowedLevels = allowedLevelsForScope(reqScopePhase);

  if (!allowedLevels.has(cleanLevel)) {
    const err = new Error('You are not allowed to create subjects for this level (scopePhase restriction).');
    err.statusCode = 403;
    throw err;
  }
  if (cleanLevel === 'Primary' && !schoolAllowsPrimary) {
    const err = new Error('This school does not have Primary phase enabled.');
    err.statusCode = 400;
    throw err;
  }
  if ((cleanLevel === 'JSS' || cleanLevel === 'SSS') && !schoolAllowsSecondary) {
    const err = new Error('This school does not have Secondary phase enabled.');
    err.statusCode = 400;
    throw err;
  }
  if (!cleanName || !cleanLevel) {
    const err = new Error('Name and level are required.');
    err.statusCode = 400;
    throw err;
  }

  try {
    return await Subject.create({
      school: schoolId,
      name: cleanName,
      code: cleanCode,
      level: cleanLevel,
      status: cleanStatus,
      type: cleanType,
      tracks: cleanTracks,
    });
  } catch (e) {
    if (e.code === 11000) {
      const err = new Error('This subject already exists for this level in your school.');
      err.statusCode = 400;
      throw err;
    }
    throw e;
  }
};

exports.updateSubject = async ({ schoolId, subjectId, reqScopePhase, name, code, level, status, type, tracks }) => {
  const cleanName = String(name || '').trim();
  const cleanCode = String(code || '').trim();
  const cleanLevel = String(level || '').trim();
  const cleanStatus = status === 'Inactive' ? 'Inactive' : 'Active';
  let cleanType = String(type || '').trim() || 'GENERAL';
  if (cleanType === 'CORE') cleanType = 'GENERAL';
  const cleanTracks = Array.isArray(tracks)
    ? tracks.map((t) => String(t).trim()).filter(Boolean)
    : String(tracks || '')
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean);

  if (!cleanName || !cleanLevel) {
    const err = new Error('Name and level are required.');
    err.statusCode = 400;
    throw err;
  }

  const { phases } = await resolveSchoolDefaultScopePhase(schoolId);
  const schoolAllowsPrimary = phases.includes('Primary');
  const schoolAllowsSecondary = phases.includes('Secondary');
  const allowedLevels = allowedLevelsForScope(reqScopePhase);

  if (!allowedLevels.has(cleanLevel)) {
    const err = new Error('You are not allowed to update subjects for this level (scopePhase restriction).');
    err.statusCode = 403;
    throw err;
  }
  if (cleanLevel === 'Primary' && !schoolAllowsPrimary) {
    const err = new Error('This school does not have Primary phase enabled.');
    err.statusCode = 400;
    throw err;
  }
  if ((cleanLevel === 'JSS' || cleanLevel === 'SSS') && !schoolAllowsSecondary) {
    const err = new Error('This school does not have Secondary phase enabled.');
    err.statusCode = 400;
    throw err;
  }

  try {
    const updated = await Subject.findOneAndUpdate(
      { _id: subjectId, school: schoolId },
      { name: cleanName, code: cleanCode, level: cleanLevel, status: cleanStatus, type: cleanType, tracks: cleanTracks },
      { new: true, runValidators: true }
    );
    if (!updated) {
      const err = new Error('Subject not found');
      err.statusCode = 404;
      throw err;
    }
    return updated;
  } catch (e) {
    if (e.code === 11000) {
      const err = new Error('This subject already exists for this level in your school.');
      err.statusCode = 400;
      throw err;
    }
    throw e;
  }
};

exports.deleteSubject = async ({ schoolId, subjectId }) => {
  const updated = await Subject.findOneAndUpdate(
    { _id: subjectId, school: schoolId },
    { status: 'Inactive' },
    { new: true }
  );
  if (!updated) {
    const err = new Error('Subject not found');
    err.statusCode = 404;
    throw err;
  }
  return updated;
};

exports.getSubjectOverview = async ({ schoolId, subjectId, sessionName }) => {
  const subject = await Subject.findOne({ _id: subjectId, school: schoolId }).lean();
  if (!subject) {
    const err = new Error('Subject not found');
    err.statusCode = 404;
    throw err;
  }

  const offerings = await ClassSubject.find({ school: schoolId, subject: subjectId })
    .populate('class', 'name level phase')
    .lean();

  const assignments = await TeachingAssignment.find({
    school: schoolId,
    subject: subjectId,
    ...(sessionName ? { academicYear: sessionName } : {}),
  })
    .populate('teacher', 'fullName username')
    .populate('class', 'name')
    .populate('section', 'name')
    .lean();

  const enrollments = await StudentSubject.find({
    school: schoolId,
    subject: subjectId,
    ...(sessionName ? { session: sessionName } : {}),
  })
    .populate({
      path: 'student',
      select: 'fullName name firstName surname middleName class section status',
      populate: [
        { path: 'class', select: 'name' },
        { path: 'section', select: 'name' },
      ],
    })
    .lean();

  const assignmentMap = new Map();
  for (const item of assignments) {
    const key = String(item.class?._id || item.class);
    if (!assignmentMap.has(key)) assignmentMap.set(key, []);
    assignmentMap.get(key).push(item);
  }

  const studentMap = new Map();
  for (const item of enrollments) {
    const student = item.student;
    if (!student || student.status === 'Withdrawn') continue;
    const key = String(student.class?._id || student.class);
    if (!studentMap.has(key)) studentMap.set(key, []);
    studentMap.get(key).push(student);
  }

  const classes = offerings
    .map((off) => ({
      class: off.class,
      assignments: assignmentMap.get(String(off.class?._id || off.class)) || [],
      students: (studentMap.get(String(off.class?._id || off.class)) || []).sort((a, b) => String(a.fullName || a.name).localeCompare(String(b.fullName || b.name))),
    }))
    .sort((a, b) => String(a.class?.name || '').localeCompare(String(b.class?.name || '')));

  return { subject, classes, sessionName: sessionName || null };
};
