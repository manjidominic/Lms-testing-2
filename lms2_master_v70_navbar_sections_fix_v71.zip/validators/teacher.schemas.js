const { Joi, objectId, nigerianPhone, yearString } = require('./common.schemas');

const createTeacherSchema = Joi.object({
  surname: Joi.string().trim().min(2).max(60).required().messages({
    'any.required': 'Surname is required.',
  }),
  middleName: Joi.string().trim().allow('').max(60),
  firstName: Joi.string().trim().min(2).max(60).required().messages({
    'any.required': 'First name is required.',
  }),
  name: Joi.string().trim().allow('').max(180),
  startYear: yearString.required().messages({
    'any.required': 'Starting year is required.',
  }),
  phone: nigerianPhone.required().messages({
    'any.required': 'Phone number is required.',
  }),
});

const teacherStatusSchema = Joi.object({
  status: Joi.string().trim().valid('Active', 'Inactive').required().messages({
    'any.only': 'Teacher status is invalid.',
    'any.required': 'Teacher status is required.',
  }),
});

module.exports = {
  createTeacherSchema,
  teacherStatusSchema,
};
