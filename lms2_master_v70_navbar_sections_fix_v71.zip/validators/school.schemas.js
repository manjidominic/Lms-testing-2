const { Joi, schoolCode } = require('./common.schemas');

const primaryClassValues = ['Creche', 'Nursery 1', 'Nursery 2', 'Primary 1', 'Primary 2', 'Primary 3', 'Primary 4', 'Primary 5', 'Primary 6'];

const registerSchoolSchema = Joi.object({
  name: Joi.string().trim().min(2).max(120).required().messages({
    'any.required': 'School name is required.',
  }),
  type: Joi.string().trim().lowercase().valid('primary', 'secondary', 'both').required().messages({
    'any.only': 'Choose Primary, Secondary, or Both for school type.',
    'any.required': 'School type is required.',
  }),
  code: schoolCode.required().messages({
    'any.required': 'School code is required.',
  }),
  adminEmail: Joi.string().trim().lowercase().email().allow(''),
  adminPassword: Joi.string().allow('').max(120),
  primaryAdminEmail: Joi.string().trim().lowercase().email().allow(''),
  primaryAdminPassword: Joi.string().allow('').max(120),
  secondaryAdminEmail: Joi.string().trim().lowercase().email().allow(''),
  secondaryAdminPassword: Joi.string().allow('').max(120),
  primaryClasses: Joi.alternatives().try(
    Joi.array().items(Joi.string().valid(...primaryClassValues)).unique(),
    Joi.string().valid(...primaryClassValues),
    Joi.allow('')
  ),
}).custom((value, helpers) => {
  if (value.type === 'both') {
    if (!value.primaryAdminEmail || !value.primaryAdminPassword) {
      return helpers.error('any.custom', { message: 'Primary admin email and password are required for a school with both phases.' });
    }
    if (!value.secondaryAdminEmail || !value.secondaryAdminPassword) {
      return helpers.error('any.custom', { message: 'Secondary admin email and password are required for a school with both phases.' });
    }
  } else {
    if (!value.adminEmail || !value.adminPassword) {
      return helpers.error('any.custom', { message: 'Admin email and password are required.' });
    }
  }
  return value;
}).messages({
  'any.custom': '{{#message}}',
});

module.exports = { registerSchoolSchema };
