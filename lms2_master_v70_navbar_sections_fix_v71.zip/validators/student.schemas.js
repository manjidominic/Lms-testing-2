const { Joi, objectId, yearString, nigerianPhone } = require('./common.schemas');

const createStudentSchema = Joi.object({
  surname: Joi.string().trim().min(2).max(60).required().messages({
    'any.required': 'Surname is required.',
  }),
  middleName: Joi.string().trim().allow('').max(60),
  firstName: Joi.string().trim().min(2).max(60).required().messages({
    'any.required': 'First name is required.',
  }),
  name: Joi.string().trim().allow('').max(180),
  admissionYear: yearString.required().messages({
    'any.required': 'Admission year is required.',
  }),
  classId: objectId.required().messages({
    'any.required': 'Please select a class.',
    'string.length': 'Please select a valid class.',
  }),
  sectionId: Joi.string().trim().allow(''),
  parentName: Joi.string().trim().min(3).max(120).required().messages({
    'any.required': 'Parent or guardian name is required.',
  }),
  parentEmail: Joi.string().trim().lowercase().email().allow(''),
  parentPhone: nigerianPhone.allow(''),
}).custom((value, helpers) => {
  if (!value.parentEmail && !value.parentPhone) {
    return helpers.error('any.custom', { message: 'Enter either the parent email address or phone number.' });
  }
  if (value.sectionId && !/^[a-fA-F0-9]{24}$/.test(value.sectionId)) {
    return helpers.error('any.custom', { message: 'Please choose a valid section.' });
  }
  return value;
}).messages({ 'any.custom': '{{#message}}' });

const studentStatusSchema = Joi.object({
  status: Joi.string().trim().valid('Active', 'Withdrawn', 'Graduated').required().messages({
    'any.only': 'Student status is invalid.',
    'any.required': 'Student status is required.',
  }),
});

module.exports = {
  createStudentSchema,
  studentStatusSchema,
};
