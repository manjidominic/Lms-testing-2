const { Joi } = require('../middlewares/joiValidation.middleware');

const objectId = Joi.string().trim().hex().length(24);
const nigerianPhone = Joi.string().trim().pattern(/^0\d{10}$/).messages({
  'string.pattern.base': 'Phone number must use Nigerian format, for example 09083339287.',
});
const yearString = Joi.string().trim().pattern(/^(19|20)\d{2}$/).messages({
  'string.pattern.base': 'Enter a valid 4-digit year.',
});
const schoolCode = Joi.string().trim().lowercase().pattern(/^[a-z0-9-]{2,20}$/).messages({
  'string.pattern.base': 'School code can contain only letters, numbers, and hyphens.',
});

module.exports = {
  Joi,
  objectId,
  nigerianPhone,
  yearString,
  schoolCode,
};
