const { Joi, objectId } = require('./common.schemas');

const ownerSchoolIdParamsSchema = Joi.object({
  schoolId: objectId.required().messages({
    'any.required': 'School id is required.',
    'string.length': 'School id is invalid.',
  }),
});

const renewSubscriptionSchema = Joi.object({
  durationValue: Joi.number().integer().min(1).max(60).required().messages({
    'number.base': 'Duration value must be a number.',
    'number.min': 'Duration value must be at least 1.',
    'number.max': 'Duration value is too large.',
    'any.required': 'Duration value is required.',
  }),
  durationUnit: Joi.string().trim().valid('months', 'years').required().messages({
    'any.only': 'Duration unit must be months or years.',
    'any.required': 'Duration unit is required.',
  }),
});

module.exports = {
  ownerSchoolIdParamsSchema,
  renewSubscriptionSchema,
};
