const { Joi, schoolCode } = require('./common.schemas');

const setupOwnerSchema = Joi.object({
  email: Joi.string().trim().lowercase().email().required().messages({
    'string.email': 'Enter a valid email address.',
    'any.required': 'Email is required.',
  }),
  password: Joi.string().min(8).max(120).required().messages({
    'string.min': 'Password must be at least 8 characters.',
    'any.required': 'Password is required.',
  }),
  confirmPassword: Joi.any().valid(Joi.ref('password')).required().messages({
    'any.only': 'Password and confirm password do not match.',
    'any.required': 'Confirm password is required.',
  }),
});

const loginSchema = Joi.object({
  schoolCode: Joi.string().allow('').trim().max(40),
  identifier: Joi.string().trim().max(120).required().messages({
    'any.required': 'Enter your username or email address.',
    'string.empty': 'Enter your username or email address.',
  }),
  password: Joi.string().min(1).max(120).required().messages({
    'any.required': 'Password is required.',
    'string.empty': 'Password is required.',
  }),
}).custom((value, helpers) => {
  const identifier = String(value.identifier || '').trim();
  const school = String(value.schoolCode || '').trim();
  const isOwnerEmailLike = /@/.test(identifier);
  if (!isOwnerEmailLike && !school) {
    return helpers.error('any.custom', { message: 'School code is required for non-owner logins.' });
  }
  return value;
}).messages({
  'any.custom': '{{#message}}',
});

const changePasswordSchema = Joi.object({
  password: Joi.string().min(8).max(120).required().messages({
    'string.min': 'Password must be at least 8 characters.',
    'any.required': 'Password is required.',
  }),
  confirmPassword: Joi.any().valid(Joi.ref('password')).required().messages({
    'any.only': 'Password and confirm password do not match.',
    'any.required': 'Confirm password is required.',
  }),
});

module.exports = {
  setupOwnerSchema,
  loginSchema,
  changePasswordSchema,
};
