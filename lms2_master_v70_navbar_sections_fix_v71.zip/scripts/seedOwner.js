/*
  Seed a PLATFORM OWNER account (superuser across all schools).

  Usage:
    node scripts/seedOwner.js

  Optional env:
    OWNER_EMAIL=owner@lms.com
    OWNER_PASSWORD=Owner12345

  Notes:
  - Owner has role 'owner'
  - Owner has NO school and NO scopePhase
  - mustChangePassword defaults to true (first login forces change)
*/

require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

const Account = require('../models/Account');

async function main() {
  const mongoUri = process.env.MONGO_URI || process.env.MONGODB_URI;
  if (!mongoUri) throw new Error('Missing MONGO_URI (or MONGODB_URI) in .env');

  const email = String(process.env.OWNER_EMAIL || 'owner@lms.com').toLowerCase().trim();
  const password = String(process.env.OWNER_PASSWORD || 'Owner12345');

  await mongoose.connect(mongoUri);

  const existing = await Account.findOne({ role: 'owner', email });
  if (existing) {
    console.log('✅ Owner already exists:', email);
    await mongoose.disconnect();
    return;
  }

  const passwordHash = await bcrypt.hash(password, 10);

  await Account.create({
    role: 'owner',
    email,
    passwordHash,
    // school: undefined (owner has no school)
    scopePhase: undefined,
    mustChangePassword: true,
    isActive: true,
  });

  console.log('✅ Owner account created');
  console.log('   Email:', email);
  console.log('   Temp Password:', password);
  console.log('   (You will be forced to change password on first login)');

  await mongoose.disconnect();
}

main().catch(async (err) => {
  console.error('❌ Seed owner failed:', err);
  try {
    await mongoose.disconnect();
  } catch (e) {}
  process.exit(1);
});
