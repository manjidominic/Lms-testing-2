const mongoose = require('mongoose');

module.exports = async function fixAccountUsernameIndex() {
  if (mongoose.connection.readyState !== 1) {
    throw new Error('fixAccountUsernameIndex requires an active mongoose connection');
  }
  const collection = mongoose.connection.collection('accounts');
  const indexes = await collection.indexes();
  const legacy = indexes.find((idx) => idx.name === 'school_1_username_1');
  if (legacy) {
    const partial = legacy.partialFilterExpression || null;
    const isSafePartial = partial && partial.username && partial.username.$exists === true && partial.username.$type === 'string';
    if (!isSafePartial) {
      await collection.dropIndex('school_1_username_1');
    }
  }
  const refreshed = await collection.indexes();
  const exists = refreshed.find((idx) => idx.name === 'school_1_username_1');
  if (!exists) {
    await collection.createIndex(
      { school: 1, username: 1 },
      {
        name: 'school_1_username_1',
        unique: true,
        partialFilterExpression: {
          username: { $exists: true, $type: 'string' },
        },
      }
    );
  }
  await collection.updateMany({ username: null }, { $unset: { username: '' } });
};
