require('dotenv').config();
const mongoose = require('mongoose');

async function run() {
  const uri = process.env.MONGO_URI || process.env.MONGODB_URI;
  if (!uri) throw new Error('Missing MONGO_URI or MONGODB_URI in .env');
  await mongoose.connect(uri);
  const collection = mongoose.connection.collection('accounts');
  const indexes = await collection.indexes();
  const legacy = indexes.find((idx) => idx.name === 'school_1_username_1');

  if (legacy) {
    const partial = legacy.partialFilterExpression || null;
    const isSafePartial = partial && partial.username && partial.username.$exists === true && partial.username.$type === 'string';
    if (!isSafePartial) {
      await collection.dropIndex('school_1_username_1');
      console.log('Dropped legacy index school_1_username_1');
    } else {
      console.log('Safe username index already present');
    }
  }

  const refreshed = await collection.indexes();
  const stillExists = refreshed.find((idx) => idx.name === 'school_1_username_1');
  if (!stillExists) {
    await collection.createIndex(
      { school: 1, username: 1 },
      {
        name: 'school_1_username_1',
        unique: true,
        partialFilterExpression: {
          username: { $exists: true, $type: 'string' },
        },
      }
    );
    console.log('Created safe partial index school_1_username_1');
  }

  await collection.updateMany(
    { username: null },
    { $unset: { username: '' } }
  );
  console.log('Removed null usernames from existing accounts');

  await mongoose.disconnect();
  console.log('Account username index fix complete');
}

run().catch(async (err) => {
  console.error('Account username index fix failed:', err);
  try { await mongoose.disconnect(); } catch (_) {}
  process.exit(1);
});
