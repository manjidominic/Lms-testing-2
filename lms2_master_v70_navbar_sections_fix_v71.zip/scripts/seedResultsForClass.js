/*
  Seed scores for a particular class (for testing Compute -> Form Teacher Submit -> Publish).

  Usage:
    node scripts/seedResultsForClass.js --classId=YOUR_CLASS_ID
    node scripts/seedResultsForClass.js --classId=YOUR_CLASS_ID --limit=20
    node scripts/seedResultsForClass.js --classId=YOUR_CLASS_ID --subjects="Mathematics,English,Basic Science"

  Notes:
  - Uses active AcademicYear + active Term for the class' school.
  - Ensures StudentSubject enrollments exist so averages are based on enrolled subjects.
  - Deletes existing scores for the same class+session+term+subjects+students before inserting.
*/

require('dotenv').config();
const mongoose = require('mongoose');

const School = require('../models/School');
const ClassModel = require('../models/class');
const Student = require('../models/Students');
const Subject = require('../models/Subject');
const Score = require('../models/score');
const AcademicYear = require('../models/AcademicYear');
const Term = require('../models/Term');
const StudentSubject = require('../models/StudentSubject');

function getArg(name, fallback = null) {
  const prefix = `--${name}=`;
  const hit = process.argv.find((a) => a.startsWith(prefix));
  if (!hit) return fallback;
  return hit.slice(prefix.length);
}

function parseCSV(s) {
  if (!s) return [];
  return String(s)
    .split(',')
    .map((x) => x.trim())
    .filter(Boolean);
}

function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function clamp(n, min, max) {
  return Math.max(min, Math.min(max, n));
}

function gradeFromTotal(total) {
  if (total >= 70) return { grade: 'A', remark: 'Excellent' };
  if (total >= 60) return { grade: 'B', remark: 'Very Good' };
  if (total >= 50) return { grade: 'C', remark: 'Good' };
  if (total >= 45) return { grade: 'D', remark: 'Fair' };
  if (total >= 40) return { grade: 'E', remark: 'Pass' };
  return { grade: 'F', remark: 'Fail' };
}

async function main() {
  const classId = getArg('classId');
  const limit = parseInt(getArg('limit', '0'), 10); // 0 => all students
  const subjectNamesFromArgs = parseCSV(getArg('subjects'));

  const mongoUri = process.env.MONGO_URI || process.env.MONGODB_URI;
  if (!mongoUri) throw new Error('Missing MONGO_URI (or MONGODB_URI) in .env');
  if (!classId) throw new Error('Please provide --classId=YOUR_CLASS_ID');

  await mongoose.connect(mongoUri);

  const cls = await ClassModel.findById(classId);
  if (!cls) throw new Error('Class not found');

  const school = await School.findById(cls.school);
  if (!school) throw new Error('School not found for this class');

  const activeYear = await AcademicYear.findOne({ school: school._id, isActive: true });
  if (!activeYear) throw new Error('No active academic year found for this school');

  const activeTerm = await Term.findOne({
    school: school._id,
    academicYear: activeYear._id,
    isActive: true,
  });
  if (!activeTerm) throw new Error('No active term found for this school');

  // Students in class (Active)
  let studentsQ = Student.find({
    school: school._id,
    class: cls._id,
    status: 'Active',
  });
  if (limit && limit > 0) studentsQ = studentsQ.limit(limit);
  const students = await studentsQ;

  if (!students.length) {
    throw new Error(
      'No Active students found in this class. Register students first, then re-run this seeder.'
    );
  }

  // Subjects for this class level
  const classLevel = cls.level; // 'Primary' | 'JSS' | 'SSS'
  let subjects = [];

  if (subjectNamesFromArgs.length) {
    for (const name of subjectNamesFromArgs) {
      let sub = await Subject.findOne({ school: school._id, name, level: classLevel });
      if (!sub) {
        // Track only required for SSS. We default to 'General'.
        const createDoc = {
          school: school._id,
          name,
          level: classLevel,
          status: 'Active',
        };
        if (classLevel === 'SSS') createDoc.track = 'General';
        sub = await Subject.create(createDoc);
      }
      subjects.push(sub);
    }
  } else {
    subjects = await Subject.find({ school: school._id, level: classLevel, status: 'Active' }).limit(
      12
    );

    if (!subjects.length) {
      const defaults =
        classLevel === 'Primary'
          ? ['Mathematics', 'English', 'Basic Science', 'Social Studies']
          : ['Mathematics', 'English', 'Basic Science', 'Social Studies', 'Civic Education'];

      for (const name of defaults) {
        const createDoc = {
          school: school._id,
          name,
          level: classLevel,
          status: 'Active',
        };
        if (classLevel === 'SSS') createDoc.track = 'General';
        const sub = await Subject.create(createDoc);
        subjects.push(sub);
      }
    }
  }

  // Ensure StudentSubject enrollments exist (type is required in schema)
  for (const st of students) {
    for (const sub of subjects) {
      await StudentSubject.updateOne(
        { school: school._id, student: st._id, subject: sub._id, session: activeYear.name },
        {
          $setOnInsert: {
            school: school._id,
            student: st._id,
            subject: sub._id,
            session: activeYear.name,
            type: 'base',
          },
        },
        { upsert: true }
      );
    }
  }

  // Delete old scores for these students/subjects for the same term/year
  await Score.deleteMany({
    school: school._id,
    class: cls._id,
    academicYear: activeYear.name,
    term: activeTerm.name,
    student: { $in: students.map((s) => s._id) },
    subject: { $in: subjects.map((s) => s._id) },
  });

  // Seed new scores
  const maxCA1 = 20;
  const maxCA2 = 20;
  const maxExam = 60;

  const scoreDocs = [];
  for (const st of students) {
    for (const sub of subjects) {
      const ca1 = randInt(5, maxCA1);
      const ca2 = randInt(5, maxCA2);
      const exam = randInt(10, maxExam);
      const total = clamp(ca1 + ca2 + exam, 0, 100);
      const gr = gradeFromTotal(total);

      scoreDocs.push({
        school: school._id,
        student: st._id,
        class: cls._id,
        subject: sub._id,
        section: st.section || null,
        academicYear: activeYear.name,
        term: activeTerm.name,
        ca1,
        ca2,
        exam,
        total,
        grade: gr.grade,
      });
    }
  }

  await Score.insertMany(scoreDocs);

  console.log('✅ Seeded scores successfully');
  console.log('  School :', school.name);
  console.log('  Class  :', cls.name);
  console.log('  Session:', activeYear.name);
  console.log('  Term   :', activeTerm.name);
  console.log('  Students:', students.length);
  console.log('  Subjects:', subjects.length);

  await mongoose.disconnect();
}

main().catch(async (err) => {
  console.error('❌ Seed failed:', err.message);
  try {
    await mongoose.disconnect();
  } catch (_) {}
  process.exit(1);
});
