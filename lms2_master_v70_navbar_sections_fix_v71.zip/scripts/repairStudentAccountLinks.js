require('dotenv').config();
const mongoose = require('mongoose');
const Account = require('../models/Account');
const Student = require('../models/Students');

async function main() {
  const mongoUri = process.env.MONGO_URI || process.env.MONGODB_URI;
  if (!mongoUri) throw new Error('Missing MONGO_URI (or MONGODB_URI) in .env');
  await mongoose.connect(mongoUri);

  const accounts = await Account.find({ role: 'student', isActive: true })
    .select('_id school email username student')
    .lean();

  let fixed = 0;
  let alreadyOk = 0;
  let unresolved = 0;

  for (const account of accounts) {
    const existing = account.student
      ? await Student.findOne({ _id: account.student, school: account.school }).select('_id').lean()
      : null;

    if (existing) {
      alreadyOk += 1;
      continue;
    }

    const email = String(account.email || '').trim().toLowerCase();
    const username = String(account.username || '').trim().toLowerCase();
    const query = { school: account.school, $or: [] };
    if (email) query.$or.push({ email });
    if (username) query.$or.push({ username });

    if (!query.$or.length) {
      unresolved += 1;
      continue;
    }

    const student = await Student.findOne(query).select('_id name email username').lean();
    if (!student) {
      unresolved += 1;
      continue;
    }

    await Account.updateOne({ _id: account._id }, { $set: { student: student._id } });
    fixed += 1;
  }

  console.log('Student account link repair completed');
  console.log('Already linked :', alreadyOk);
  console.log('Fixed          :', fixed);
  console.log('Unresolved     :', unresolved);

  await mongoose.disconnect();
}

main().catch(async (err) => {
  console.error('Repair failed:', err);
  try { await mongoose.disconnect(); } catch (_) {}
  process.exit(1);
});
