require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

const registerSchoolService = require('../services/school/registerSchool.service');
const { generateScopedUsername } = require('../utils/username.util');
const seedSchoolClasses = require('../utils/seedSchoolClasses.util');
const { computeAndFreezeClassTermResults } = require('../services/results/freeze.service');
const { publishResults, submitClassResults } = require('../services/results/publish.service');

const School = require('../models/School');
const Account = require('../models/Account');
const AcademicYear = require('../models/AcademicYear');
const Term = require('../models/Term');
const ClassModel = require('../models/class');
const Subject = require('../models/Subject');
const ClassSubject = require('../models/ClassSubject');
const Teacher = require('../models/Teacher');
const Student = require('../models/Students');
const TeachingAssignment = require('../models/TeachingAssignment');
const TeacherSubject = require('../models/TeacherSubject');
const FormTeacherAssignment = require('../models/FormTeacherAssignment');
const StudentSubject = require('../models/StudentSubject');
const Score = require('../models/score');
const ClassResultStatus = require('../models/ClassResultStatus');
const PublishStatus = require('../models/PublishStatus');

const TERMS = ['First Term', 'Second Term', 'Third Term'];
const DEFAULT_PASSWORD = '123456';

const SUBJECT_BLUEPRINTS = {
  Primary: [
    { name: 'Mathematics', code: 'MTH', type: 'CORE' },
    { name: 'English Language', code: 'ENG', type: 'CORE' },
    { name: 'Basic Science', code: 'BSC', type: 'CORE' },
    { name: 'Social Studies', code: 'SOS', type: 'CORE' },
    { name: 'Civic Education', code: 'CVE', type: 'CORE' },
    { name: 'Computer Studies', code: 'ICT', type: 'CORE' },
  ],
  JSS: [
    { name: 'Mathematics', code: 'MTH', type: 'CORE' },
    { name: 'English Language', code: 'ENG', type: 'CORE' },
    { name: 'Basic Science', code: 'BSC', type: 'CORE' },
    { name: 'Social Studies', code: 'SOS', type: 'CORE' },
    { name: 'Business Studies', code: 'BST', type: 'CORE' },
    { name: 'Basic Technology', code: 'BTE', type: 'CORE' },
    { name: 'Civic Education', code: 'CVE', type: 'CORE' },
  ],
  SSS: [
    { name: 'English Language', code: 'ENG', type: 'CORE' },
    { name: 'Mathematics', code: 'MTH', type: 'CORE' },
    { name: 'Civic Education', code: 'CVE', type: 'CORE' },
    { name: 'Physics', code: 'PHY', type: 'TRACK_CORE', tracks: ['Science'] },
    { name: 'Chemistry', code: 'CHM', type: 'TRACK_CORE', tracks: ['Science'] },
    { name: 'Biology', code: 'BIO', type: 'TRACK_CORE', tracks: ['Science'] },
    { name: 'Literature in English', code: 'LIT', type: 'TRACK_CORE', tracks: ['Art'] },
    { name: 'Government', code: 'GOV', type: 'TRACK_CORE', tracks: ['Art'] },
    { name: 'CRS', code: 'CRS', type: 'TRACK_CORE', tracks: ['Art'] },
    { name: 'Financial Accounting', code: 'ACC', type: 'TRACK_CORE', tracks: ['Commercial'] },
    { name: 'Commerce', code: 'COM', type: 'TRACK_CORE', tracks: ['Commercial'] },
    { name: 'Economics', code: 'ECO', type: 'TRACK_CORE', tracks: ['Commercial'] },
    { name: 'Agricultural Science', code: 'AGR', type: 'ELECTIVE' },
    { name: 'Geography', code: 'GEO', type: 'ELECTIVE' },
  ],
};

const FIRST_NAMES = ['Musa', 'Amina', 'Fatima', 'Maryam', 'John', 'Grace', 'Ibrahim', 'Zainab', 'David', 'Hauwa', 'Yusuf', 'Blessing', 'Samuel', 'Ruth', 'Abdullahi', 'Hadiza', 'Daniel', 'Esther', 'Mustapha', 'Khadija'];
const SURNAMES = ['Abdullahi', 'Bello', 'Garba', 'Usman', 'Ibrahim', 'Mohammed', 'Yusuf', 'Aliyu', 'Sani', 'Okafor', 'Balogun', 'Musa', 'Adeyemi', 'Olawale', 'Eze', 'Lawal', 'Adamu', 'Isah', 'Bature', 'Mustapha'];
const MIDDLE_NAMES = ['Ali', 'Aisha', 'Chioma', 'Tunde', 'Kabiru', 'Ngozi', 'Sule', 'Janet', 'Paul', 'Ado', 'Rabi', 'Emeka', 'Joy', 'Binta', 'Miriam', 'Nura'];
const TRACKS = ['Science', 'Art', 'Commercial'];

function getArg(name, fallback = null) {
  const prefix = `--${name}=`;
  const hit = process.argv.find((arg) => arg.startsWith(prefix));
  if (!hit) return fallback;
  return hit.slice(prefix.length);
}

function asBool(value, fallback = false) {
  if (value == null) return fallback;
  return ['1', 'true', 'yes', 'y'].includes(String(value).trim().toLowerCase());
}

function normalize(value) {
  return String(value || '').trim();
}

function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function sample(arr) {
  return arr[randInt(0, arr.length - 1)];
}

function titleCase(value) {
  return String(value || '')
    .toLowerCase()
    .split(' ')
    .filter(Boolean)
    .map((v) => v.charAt(0).toUpperCase() + v.slice(1))
    .join(' ');
}

function buildPerson(index, label) {
  const firstName = FIRST_NAMES[index % FIRST_NAMES.length];
  const surname = SURNAMES[(index * 3) % SURNAMES.length];
  const middleName = MIDDLE_NAMES[(index * 5) % MIDDLE_NAMES.length];
  return {
    surname: titleCase(surname),
    middleName: titleCase(middleName),
    firstName: titleCase(firstName),
    fullName: [titleCase(surname), titleCase(middleName), titleCase(firstName)].filter(Boolean).join(' '),
    label: `${label}-${index + 1}`,
  };
}

function subjectAllowedForTrack(subject, track) {
  if (!subject) return false;
  const type = subject.type || 'CORE';
  if (type === 'CORE') return true;
  if (type === 'ELECTIVE') return true;
  const tracks = Array.isArray(subject.tracks) ? subject.tracks : [];
  return tracks.length === 0 || tracks.includes(track);
}

function gradeFromTotal(total) {
  if (total >= 70) return 'A';
  if (total >= 60) return 'B';
  if (total >= 50) return 'C';
  if (total >= 45) return 'D';
  if (total >= 40) return 'E';
  return 'F';
}

async function ensureSchool({ schoolCode, schoolName, createIfMissing }) {
  let school = null;
  if (schoolCode) {
    school = await School.findOne({ code: normalize(schoolCode).toLowerCase() });
  }
  if (!school && !schoolCode) {
    school = await School.findOne().sort({ createdAt: 1 });
  }

  if (school) return school;

  if (!createIfMissing) {
    throw new Error('School not found. Pass --schoolCode=YOURCODE or set --createSchool=true.');
  }

  const code = normalize(schoolCode || 'demo');
  const name = normalize(schoolName || 'Demo International School');
  console.log(`ℹ️  School not found. Creating demo school ${name} (${code}) ...`);

  school = await registerSchoolService({
    name,
    type: 'both',
    code,
    primaryAdminEmail: `primaryadmin@${code}.local`,
    primaryAdminPassword: 'Admin12345',
    secondaryAdminEmail: `secondaryadmin@${code}.local`,
    secondaryAdminPassword: 'Admin12345',
  });

  return school;
}

async function ensureAcademicSession({ schoolId, sessionName, activeTermName }) {
  await AcademicYear.updateMany({ school: schoolId, isActive: true }, { $set: { isActive: false } });

  const academicYear = await AcademicYear.findOneAndUpdate(
    { school: schoolId, name: sessionName },
    { $set: { isActive: true } },
    { new: true, upsert: true, setDefaultsOnInsert: true }
  );

  await Term.updateMany({ school: schoolId, academicYear: academicYear._id, isActive: true }, { $set: { isActive: false } });

  for (const name of TERMS) {
    await Term.findOneAndUpdate(
      { school: schoolId, academicYear: academicYear._id, name },
      { $set: { isActive: name === activeTermName, isResultOpen: true } },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
  }

  return academicYear;
}

async function ensureClasses(school) {
  const count = await ClassModel.countDocuments({ school: school._id });
  if (count === 0) {
    await seedSchoolClasses({ schoolId: school._id, phases: school.phases || ['Primary', 'Secondary'] });
  }
  return ClassModel.find({ school: school._id }).sort({ phase: 1, level: 1, order: 1 }).lean();
}

async function ensureSubjectsAndOfferings(school, classes) {
  const subjectMap = new Map();

  for (const cls of classes) {
    const blueprints = SUBJECT_BLUEPRINTS[cls.level] || [];

    for (const bp of blueprints) {
      const filter = { school: school._id, name: bp.name, level: cls.level };
      const update = {
        $set: {
          code: bp.code,
          status: 'Active',
          type: bp.type,
          tracks: bp.type === 'TRACK_CORE' ? (bp.tracks || []) : [],
          track: null,
        },
        $setOnInsert: {
          school: school._id,
          name: bp.name,
          level: cls.level,
        },
      };

      const subject = await Subject.findOneAndUpdate(filter, update, {
        new: true,
        upsert: true,
        setDefaultsOnInsert: true,
      });

      subjectMap.set(`${cls.level}:${bp.name}`, subject);

      await ClassSubject.findOneAndUpdate(
        { school: school._id, class: cls._id, subject: subject._id },
        {
          $set: {
            offeringType: bp.type,
          },
          $setOnInsert: {
            school: school._id,
            class: cls._id,
            subject: subject._id,
          },
        },
        { upsert: true, new: true, setDefaultsOnInsert: true }
      );
    }
  }

  return subjectMap;
}

async function ensureTeacher({ school, phase, index, startYear }) {
  const person = buildPerson(index, 'teacher');
  const username = await generateScopedUsername({
    schoolId: school._id,
    surname: person.surname,
    firstName: person.firstName,
    year: startYear,
  });

  let account = await Account.findOne({ school: school._id, username });
  const passwordHash = await bcrypt.hash(DEFAULT_PASSWORD, 10);

  if (!account) {
    account = await Account.create({
      school: school._id,
      role: 'teacher',
      scopePhase: phase,
      username,
      email: username,
      passwordHash,
      mustChangePassword: false,
      isActive: true,
    });
  }

  let teacher = await Teacher.findOne({ school: school._id, account: account._id });
  if (!teacher) {
    teacher = await Teacher.create({
      school: school._id,
      phase,
      account: account._id,
      surname: person.surname,
      middleName: person.middleName,
      firstName: person.firstName,
      fullName: person.fullName,
      username,
      email: username,
      phone: `0${String(8000000000 + randInt(1000000, 9999999)).slice(0, 10)}`,
      startYear,
      status: 'Active',
    });
    await Account.updateOne({ _id: account._id }, { $set: { teacher: teacher._id } });
  }

  return teacher;
}

async function ensureStudent({ school, cls, academicYearName, index, admissionYear }) {
  const person = buildPerson(index, 'student');
  const username = await generateScopedUsername({
    schoolId: school._id,
    surname: person.surname,
    firstName: person.firstName,
    year: admissionYear,
  });

  let student = await Student.findOne({ school: school._id, username });
  if (!student) {
    const track = cls.level === 'SSS' ? TRACKS[index % TRACKS.length] : 'General';
    student = await Student.create({
      school: school._id,
      phase: cls.phase,
      surname: person.surname,
      middleName: person.middleName,
      firstName: person.firstName,
      name: person.fullName,
      username,
      email: username,
      level: cls.level,
      class: cls._id,
      track,
      admissionYear,
      currentSession: academicYearName,
      status: 'Active',
    });

    const passwordHash = await bcrypt.hash(DEFAULT_PASSWORD, 10);
    await Account.create({
      school: school._id,
      role: 'student',
      scopePhase: cls.phase,
      username,
      email: username,
      passwordHash,
      mustChangePassword: false,
      isActive: true,
      student: student._id,
    });
  } else {
    await Student.updateOne(
      { _id: student._id },
      {
        $set: {
          currentSession: academicYearName,
          class: cls._id,
          level: cls.level,
          phase: cls.phase,
          status: 'Active',
        },
      }
    );
    student = await Student.findById(student._id);
  }

  return student;
}

async function ensureAssignments({ school, classes, teachers, academicYearName }) {
  const assignments = [];

  for (let i = 0; i < classes.length; i += 1) {
    const cls = classes[i];
    const classSubjects = await ClassSubject.find({ school: school._id, class: cls._id })
      .populate('subject')
      .lean();

    const phaseTeachers = teachers.filter((t) => t.phase === cls.phase);
    const formTeacher = phaseTeachers[i % phaseTeachers.length];
    if (formTeacher) {
      await FormTeacherAssignment.findOneAndUpdate(
        { school: school._id, class: cls._id, academicYear: academicYearName },
        {
          $set: {
            teacher: formTeacher._id,
          },
          $setOnInsert: {
            school: school._id,
            class: cls._id,
            academicYear: academicYearName,
          },
        },
        { upsert: true, new: true }
      );
    }

    for (let s = 0; s < classSubjects.length; s += 1) {
      const off = classSubjects[s];
      const teacher = phaseTeachers[s % phaseTeachers.length];
      if (!teacher || !off.subject) continue;

      await TeachingAssignment.findOneAndUpdate(
        {
          school: school._id,
          teacher: teacher._id,
          class: cls._id,
          subject: off.subject._id,
          academicYear: academicYearName,
          section: null,
        },
        {
          $setOnInsert: {
            school: school._id,
            teacher: teacher._id,
            class: cls._id,
            subject: off.subject._id,
            academicYear: academicYearName,
            section: null,
          },
        },
        { upsert: true, new: true }
      );

      await TeacherSubject.findOneAndUpdate(
        {
          school: school._id,
          teacher: teacher._id,
          subject: off.subject._id,
          class: cls._id,
        },
        {
          $set: { status: 'Active' },
          $setOnInsert: {
            school: school._id,
            teacher: teacher._id,
            subject: off.subject._id,
            class: cls._id,
          },
        },
        { upsert: true, new: true }
      );

      assignments.push({ classId: cls._id, subjectId: off.subject._id, teacherId: teacher._id });
    }
  }

  return assignments;
}

async function ensureStudentsAndEnrollments({ school, classes, academicYearName, studentsPerClass }) {
  const studentsByClass = new Map();

  for (let c = 0; c < classes.length; c += 1) {
    const cls = classes[c];
    const students = [];

    for (let i = 0; i < studentsPerClass; i += 1) {
      const student = await ensureStudent({
        school,
        cls,
        academicYearName,
        index: c * studentsPerClass + i,
        admissionYear: academicYearName.split('/')[0],
      });
      students.push(student);
    }

    const offerings = await ClassSubject.find({ school: school._id, class: cls._id })
      .populate('subject')
      .lean();

    for (const student of students) {
      const studentTrack = student.track || 'General';
      const baseSubjects = offerings
        .filter((off) => off.subject)
        .filter((off) => off.offeringType !== 'ELECTIVE')
        .filter((off) => subjectAllowedForTrack(off.subject, studentTrack))
        .map((off) => off.subject);

      const electives = offerings
        .filter((off) => off.subject)
        .filter((off) => off.offeringType === 'ELECTIVE')
        .map((off) => off.subject);

      for (const subject of baseSubjects) {
        await StudentSubject.findOneAndUpdate(
          { school: school._id, student: student._id, subject: subject._id, session: academicYearName },
          {
            $setOnInsert: {
              school: school._id,
              student: student._id,
              subject: subject._id,
              session: academicYearName,
              type: 'base',
            },
          },
          { upsert: true, new: true }
        );
      }

      if (cls.level === 'SSS' && electives.length) {
        const elective = electives[(String(student._id).charCodeAt(0) + electives.length) % electives.length];
        await StudentSubject.findOneAndUpdate(
          { school: school._id, student: student._id, subject: elective._id, session: academicYearName },
          {
            $setOnInsert: {
              school: school._id,
              student: student._id,
              subject: elective._id,
              session: academicYearName,
              type: 'borrowed',
            },
          },
          { upsert: true, new: true }
        );
      }
    }

    studentsByClass.set(String(cls._id), students);
  }

  return studentsByClass;
}

async function seedScoresForTerm({ school, cls, students, academicYearName, termName }) {
  const enrollments = await StudentSubject.find({
    school: school._id,
    session: academicYearName,
    student: { $in: students.map((s) => s._id) },
  })
    .populate('subject')
    .lean();

  const docs = [];
  for (const enr of enrollments) {
    if (!enr.subject) continue;
    const studentId = String(enr.student);
    const subjectId = String(enr.subject._id || enr.subject);
    const offset = (studentId.charCodeAt(studentId.length - 1) + subjectId.charCodeAt(subjectId.length - 1) + termName.length) % 8;
    const ca1 = randInt(8, 18) + offset % 3;
    const ca2 = randInt(7, 18) + offset % 2;
    const test1 = randInt(5, 10);
    const test2 = randInt(5, 10);
    const exam = randInt(30, 55) + offset;
    const total = Math.min(100, ca1 + ca2 + test1 + test2 + exam);

    docs.push({
      school: school._id,
      student: enr.student,
      class: cls._id,
      subject: enr.subject._id,
      section: null,
      academicYear: academicYearName,
      term: termName,
      ca1,
      ca2,
      test1,
      test2,
      exam,
      total,
      grade: gradeFromTotal(total),
    });
  }

  if (!docs.length) return 0;

  await Score.deleteMany({
    school: school._id,
    class: cls._id,
    academicYear: academicYearName,
    term: termName,
    student: { $in: students.map((s) => s._id) },
  });

  await Score.insertMany(docs, { ordered: false });
  return docs.length;
}

async function freezeAndPublish({ school, classes, studentsByClass, academicYearName, publisherAccountId }) {
  for (const termName of TERMS) {
    for (const cls of classes) {
      const students = studentsByClass.get(String(cls._id)) || [];
      if (!students.length) continue;

      await computeAndFreezeClassTermResults({
        schoolId: school._id,
        classId: cls._id,
        academicYear: academicYearName,
        term: termName,
        reqScopePhase: null,
      });

      const formTeacher = await FormTeacherAssignment.findOne({
        school: school._id,
        class: cls._id,
        academicYear: academicYearName,
      }).lean();

      await submitClassResults({
        schoolId: school._id,
        academicYear: academicYearName,
        term: termName,
        classId: cls._id,
        teacherId: formTeacher?.teacher || null,
      });
    }

    await publishResults({
      schoolId: school._id,
      academicYear: academicYearName,
      term: termName,
      publisherAccountId,
      requireAllSubmitted: false,
    });
  }
}

async function main() {
  const mongoUri = process.env.MONGO_URI || process.env.MONGODB_URI;
  if (!mongoUri) throw new Error('Missing MONGO_URI (or MONGODB_URI) in .env');

  const schoolCode = getArg('schoolCode', process.env.SEED_SCHOOL_CODE || '');
  const schoolName = getArg('schoolName', process.env.SEED_SCHOOL_NAME || 'Demo International School');
  const createSchool = asBool(getArg('createSchool', process.env.SEED_CREATE_SCHOOL || 'true'), true);
  const sessionName = normalize(getArg('session', process.env.SEED_SESSION || '2026/2027'));
  const activeTermName = normalize(getArg('activeTerm', process.env.SEED_ACTIVE_TERM || 'Third Term')) || 'Third Term';
  const studentsPerClass = Math.max(1, parseInt(getArg('studentsPerClass', process.env.SEED_STUDENTS_PER_CLASS || '8'), 10));
  const teachersPerPhase = Math.max(3, parseInt(getArg('teachersPerPhase', process.env.SEED_TEACHERS_PER_PHASE || '6'), 10));
  const publish = asBool(getArg('publish', process.env.SEED_PUBLISH || 'true'), true);

  if (!/^\d{4}\/\d{4}$/.test(sessionName)) {
    throw new Error('Session must look like 2026/2027');
  }
  if (!TERMS.includes(activeTermName)) {
    throw new Error(`activeTerm must be one of: ${TERMS.join(', ')}`);
  }

  await mongoose.connect(mongoUri);

  const school = await ensureSchool({ schoolCode, schoolName, createIfMissing: createSchool });
  console.log(`✅ Using school: ${school.name} (${school.code})`);

  await ensureAcademicSession({ schoolId: school._id, sessionName, activeTermName });
  const classes = await ensureClasses(school);
  await ensureSubjectsAndOfferings(school, classes);

  const teachers = [];
  const phaseList = Array.isArray(school.phases) && school.phases.length ? school.phases : ['Primary', 'Secondary'];
  for (const phase of phaseList) {
    for (let i = 0; i < teachersPerPhase; i += 1) {
      const teacher = await ensureTeacher({
        school,
        phase,
        index: teachers.length + i,
        startYear: sessionName.split('/')[0],
      });
      teachers.push(teacher);
    }
  }

  await ensureAssignments({ school, classes, teachers, academicYearName: sessionName });
  const studentsByClass = await ensureStudentsAndEnrollments({
    school,
    classes,
    academicYearName: sessionName,
    studentsPerClass,
  });

  let totalScores = 0;
  for (const termName of TERMS) {
    for (const cls of classes) {
      const students = studentsByClass.get(String(cls._id)) || [];
      totalScores += await seedScoresForTerm({
        school,
        cls,
        students,
        academicYearName: sessionName,
        termName,
      });
    }
  }

  let publisherAccount = await Account.findOne({ school: school._id, role: 'admin' }).sort({ createdAt: 1 });
  if (!publisherAccount) {
    publisherAccount = await Account.create({
      school: school._id,
      role: 'admin',
      scopePhase: phaseList[0] || 'Secondary',
      email: `admin@${school.code}.local`,
      passwordHash: await bcrypt.hash('Admin12345', 10),
      mustChangePassword: false,
      isActive: true,
    });
  }

  if (publish) {
    await freezeAndPublish({
      school,
      classes,
      studentsByClass,
      academicYearName: sessionName,
      publisherAccountId: publisherAccount._id,
    });
  }

  const studentCount = await Student.countDocuments({ school: school._id });
  const teacherCount = await Teacher.countDocuments({ school: school._id });
  const subjectCount = await Subject.countDocuments({ school: school._id });

  console.log('\n🎉 Demo LMS seed completed');
  console.log('----------------------------------------');
  console.log('School          :', `${school.name} (${school.code})`);
  console.log('Session         :', sessionName);
  console.log('Active term     :', activeTermName);
  console.log('Classes         :', classes.length);
  console.log('Teachers        :', teacherCount);
  console.log('Students        :', studentCount);
  console.log('Subjects        :', subjectCount);
  console.log('Scores inserted :', totalScores);
  console.log('Published terms :', publish ? TERMS.join(', ') : 'No');
  console.log('Default password:', DEFAULT_PASSWORD);
  console.log('Primary admin   :', `primaryadmin@${school.code}.local / Admin12345`);
  console.log('Secondary admin :', `secondaryadmin@${school.code}.local / Admin12345`);
  console.log('\nExamples');
  const sampleTeacher = await Teacher.findOne({ school: school._id }).sort({ createdAt: 1 }).select('fullName username');
  const sampleStudent = await Student.findOne({ school: school._id }).sort({ createdAt: 1 }).select('name username');
  if (sampleTeacher) console.log('Teacher login   :', `${sampleTeacher.username} / ${DEFAULT_PASSWORD} (${sampleTeacher.fullName})`);
  if (sampleStudent) console.log('Student login   :', `${sampleStudent.username} / ${DEFAULT_PASSWORD} (${sampleStudent.name})`);

  await mongoose.disconnect();
}

main().catch(async (err) => {
  console.error('❌ Demo seed failed:', err);
  try {
    await mongoose.disconnect();
  } catch (_) {}
  process.exit(1);
});
