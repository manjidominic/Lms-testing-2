const mongoose = require('mongoose');

const backupScheduleSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, unique: true, index: true },
    enabled: { type: Boolean, default: false },
    frequency: {
      type: String,
      enum: ['hourly', 'every_6_hours', 'every_12_hours', 'daily', 'weekly', 'monthly'],
      default: 'daily',
    },
    timeOfDay: { type: String, default: '02:00' },
    dayOfWeek: { type: Number, min: 0, max: 6, default: 0 },
    dayOfMonth: { type: Number, min: 1, max: 28, default: 1 },
    retentionCount: { type: Number, min: 1, max: 50, default: 10 },
    lastRunAt: { type: Date, default: null },
    lastSuccessAt: { type: Date, default: null },
    lastStatus: {
      type: String,
      enum: ['never', 'success', 'failed', 'running'],
      default: 'never',
    },
    lastError: { type: String, default: '' },
    lastFileName: { type: String, default: '' },
    nextRunAt: { type: Date, default: null },
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Account', default: null },
  },
  { timestamps: true }
);

module.exports = mongoose.model('BackupSchedule', backupScheduleSchema);
