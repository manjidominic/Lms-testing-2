const mongoose = require("mongoose");

const schema = new mongoose.Schema({
  school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
  academicYear: { type: String, required: true, index: true, trim: true },
  term: { type: String, required: true, index: true, trim: true },
  class: { type: mongoose.Schema.Types.ObjectId, ref: 'Class', required: true, index: true },
  student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true, index: true },
  attendanceTotal: { type: Number, default: 0 },
  cleanlinessRating: { type: String, enum: ['A','B','C','D',''], default: '' },
  latenessCount: { type: Number, default: 0 },
  teacherComment: { type: String, default: '' },
  recordedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Teacher', default: null },
}, { timestamps: true });

schema.index({ school:1, academicYear:1, term:1, class:1, student:1 }, { unique: true });
module.exports = mongoose.model('FormTeacherAttendance', schema);
