const mongoose = require('mongoose');

const publishStatusSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    academicYear: { type: String, required: true, index: true },
    term: { type: String, required: true, index: true },

    published: { type: Boolean, default: false, index: true },
    publishedAt: { type: Date },
    publishedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Account' },
  },
  { timestamps: true }
);

publishStatusSchema.index(
  { school: 1, academicYear: 1, term: 1 },
  { unique: true }
);

module.exports = mongoose.model('PublishStatus', publishStatusSchema);
