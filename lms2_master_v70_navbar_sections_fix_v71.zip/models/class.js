const mongoose = require('mongoose');

const classSchema = new mongoose.Schema(
  {
    // 🔐 multi-school boundary
    school: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'School',
      required: true,
      index: true,
    },
    phase: {
      type: String,
      enum: ['Primary', 'Secondary'],
      required: true,
      index: true,
    },

    // Display name: "Primary 1", "JSS 2", "SSS 1"
    name: {
      type: String,
      required: true,
      trim: true,
    },

    // For subject rules / track rules
    level: {
      type: String,
      enum: ['Primary', 'JSS', 'SSS'],
      required: true,
      index: true,
    },

    // Promotion order within each level
    // Example Primary 1 = 1, Primary 2 = 2, ... Primary 6 = 6
    order: {
      type: Number,
      required: true,
      min: 1,
      index: true,
    },

    // Mark final class in that level (e.g. Primary 6, JSS 3, SSS 3)
    isFinal: {
      type: Boolean,
      default: false,
    },

    // Optional: track availability (useful later)
    // Primary/JSS typically false, SSS true
    allowTracks: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true }
);

// Prevent duplicates like "Primary 1" twice inside same school
classSchema.index({ school: 1, name: 1 }, { unique: true });

// Useful for promotion lookups
classSchema.index({ school: 1, level: 1, order: 1 }, { unique: true });

module.exports = mongoose.model('Class', classSchema);