const mongoose = require('mongoose');
const section = require('./section');

const scoreSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true },

    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
    class: { type: mongoose.Schema.Types.ObjectId, ref: 'Class', required: true },
    subject: { type: mongoose.Schema.Types.ObjectId, ref: 'Subject', required: true },
    section: { type: mongoose.Schema.Types.ObjectId, ref: 'Section', default: null, index: true },
    academicYear: { type: String, required: true, trim: true, index: true }, // for now string
     // e.g "2025/2026"
    term: { type: String, required: true, trim: true, index: true },         // e.g "1st", "2nd", "3rd"

    // assessment scores (optional so we can update gradually)
    ca1: { type: Number, default: null },
    ca2: { type: Number, default: null },
    test1: { type: Number, default: null },
    test2: { type: Number, default: null },
    exam: { type: Number, default: null },

    // calculated later (optional)
    total: { type: Number, default: null },
    grade: { type: String, default: null },
  },
  { timestamps: true }
);

// ✅ This prevents duplicates for same student+subject+term+year+class within a school
scoreSchema.index(
  { school: 1, student: 1, class: 1, subject: 1, academicYear: 1, term: 1 },
  { unique: true }
);


scoreSchema.index({ school: 1, class: 1, academicYear: 1, term: 1, section: 1, subject: 1 });
scoreSchema.index({ school: 1, class: 1, academicYear: 1, term: 1, student: 1 });

module.exports = mongoose.model('Score', scoreSchema);