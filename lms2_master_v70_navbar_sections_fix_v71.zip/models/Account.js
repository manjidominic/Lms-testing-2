const mongoose = require('mongoose');

const accountSchema = new mongoose.Schema(
  {
    school: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'School',
      required: function () {
        return String(this.role).toLowerCase() !== 'owner';
      },
    },

    role: {
      type: String,
      enum: ['owner', 'admin', 'form_teacher', 'teacher', 'staff', 'student', 'parent'],
      required: true,
    },

    scopePhase: {
      type: String,
      enum: ['Primary', 'Secondary'],
      required: function () {
        return !['owner', 'parent'].includes(this.role);
      },
    },

    email: {
      type: String,
      lowercase: true,
      trim: true,
      required: true,
    },

    username: {
      type: String,
      lowercase: true,
      trim: true,
      set: function (value) {
        if (value === null || value === undefined) return undefined;
        const cleaned = String(value).trim().toLowerCase();
        return cleaned || undefined;
      },
      default: undefined,
    },

    student: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Student',
    },

    teacher: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Teacher',
    },

    parent: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Parent',
    },

    passwordHash: {
      type: String,
      required: true,
    },

    mustChangePassword: {
      type: Boolean,
      default: true,
    },

    isActive: {
      type: Boolean,
      default: true,
    },

    lastLoginAt: Date,

    useCustomPermissions: {
      type: Boolean,
      default: false,
    },

    permissions: {
      type: [String],
      default: [],
    },
  },
  { timestamps: true }
);

accountSchema.index(
  { school: 1, email: 1 },
  { unique: true, sparse: true }
);

accountSchema.index(
  { school: 1, username: 1 },
  {
    unique: true,
    partialFilterExpression: {
      username: { $exists: true, $type: 'string' },
    },
  }
);

accountSchema.index(
  { role: 1, email: 1 },
  {
    unique: true,
    partialFilterExpression: { role: 'owner' },
  }
);

module.exports = mongoose.model('Account', accountSchema);
