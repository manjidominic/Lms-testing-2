const mongoose = require('mongoose');

const subjectSchema = new mongoose.Schema(
  {
    school: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'School',
      required: true,
      index: true,
    },

    name: {
      type: String,
      required: true,
      trim: true,
    },

    // Optional short code e.g. "MTH"
    code: {
      type: String,
      trim: true,
      default: '',
    },

    status: {
      type: String,
      enum: ['Active', 'Inactive'],
      default: 'Active',
    },

    // Primary/JSS/SSS
    level: {
      type: String,
      enum: ['Primary', 'JSS', 'SSS'],
      required: true,
      index: true,
    },

    // ✅ Subject category used for enrollment rules
    // - GENERAL: compulsory for all students in a class that offers the subject
    // - TRACK_CORE: compulsory for a particular SSS track (Science/Art/Commercial)
    // - ELECTIVE: optional (admin enrolls per-student)
    type: {
      type: String,
      enum: ['GENERAL', 'CORE', 'TRACK_CORE', 'ELECTIVE'],
      default: 'GENERAL',
      required: true,
      index: true,
    },

    // Only meaningful when level = SSS and type = TRACK_CORE
    tracks: {
      type: [String],
      default: [],
      enum: ['Science', 'Art', 'Commercial', 'General', 'Other'],
    },

    // Backward-compat: older code used a single "track" field.
    // Keep optional so old data doesn't break.
    track: {
      type: String,
      enum: ['Science', 'Art', 'Commercial', 'General', 'Other'],
      default: null,
    },
  },
  { timestamps: true }
);

// ✅ Validation rules
// NOTE: In some Mongoose versions/call-sites, validate middleware may receive
// (next, options) OR (options, next). We normalize to avoid "next is not a function".
subjectSchema.pre('validate', function (arg1, arg2) {
  const next = (typeof arg1 === 'function') ? arg1 : (typeof arg2 === 'function' ? arg2 : function () {});
  try {
    // Per your rule: Primary subjects are always compulsory/general.
    if (this.level === 'Primary') {
      this.type = 'GENERAL';
      this.tracks = [];
      this.track = null;
      return next();
    }

    // JSS: no track and no track-core
    if (this.level === 'JSS') {
      if (this.type === 'TRACK_CORE') this.type = 'GENERAL';
      this.tracks = [];
      this.track = null;
      return next();
    }

    if (this.type === 'CORE') this.type = 'GENERAL';

    // SSS: normalize legacy "track" into tracks[] when TRACK_CORE
    if (this.level === 'SSS' && this.type === 'TRACK_CORE') {
      if (this.track && (!Array.isArray(this.tracks) || this.tracks.length === 0)) {
        this.tracks = [this.track];
      }
      // Track core must have tracks
      if (!Array.isArray(this.tracks) || this.tracks.length === 0) {
        return next(new Error('TRACK_CORE subjects must specify at least one track.'));
      }
    } else {
      // Non track-core SSS subjects should not carry tracks
      this.tracks = [];
      this.track = null;
    }

    return next();
  } catch (e) {
    return next(e);
  }
});

// ✅ Make subject name unique per school per level
subjectSchema.index({ school: 1, name: 1, level: 1 }, { unique: true });

module.exports = mongoose.model('Subject', subjectSchema);
