const mongoose = require('mongoose');

const teacherSchema = new mongoose.Schema(
  {
    school: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'School',
      required: true,
      index: true,
    },
    phase: {
      type: String,
      enum: ['Primary', 'Secondary'],
      required: true,
      index: true,
    },

    // Link teacher profile to the login account
    account: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Account',
      required: true,
      index: true,
    },

    surname: {
      type: String,
      required: true,
      trim: true,
    },
    middleName: {
      type: String,
      trim: true,
      default: undefined,
    },
    firstName: {
      type: String,
      required: true,
      trim: true,
    },
    fullName: {
      type: String,
      required: true,
      trim: true,
    },
    email: {
      type: String,
      required: true,
      lowercase: true,
    },

    username: {
      type: String,
      trim: true,
      lowercase: true,
      default: undefined,
    },

    phone: {
      type: String,
      trim: true,
      default: undefined,
      match: [/^$|^0\d{10}$/, 'Phone number must be an 11-digit Nigerian phone number starting with 0'],
    },

    // Used for generated email uniqueness + staff records
    startYear: {
      type: String,
      trim: true,
      default: undefined,
      match: [/^$|^\d{4}$/, 'Start year must be a valid 4-digit year'],
    },

    status: {
      type: String,
      enum: ['Active', 'Inactive'],
      default: 'Active',
    },
  },
  { timestamps: true }
);

// ✅ 1 teacher profile per school per account
teacherSchema.index(
  { school: 1, account: 1 },
  { unique: true }
);

teacherSchema.index({ email: 1 }, { unique: true });
teacherSchema.index({ school: 1, username: 1 }, { unique: true, sparse: true });

module.exports = mongoose.model('Teacher', teacherSchema);