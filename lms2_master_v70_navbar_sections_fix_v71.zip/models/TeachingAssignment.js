const mongoose = require('mongoose');

const teachingAssignmentSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    teacher: { type: mongoose.Schema.Types.ObjectId, ref: 'Teacher', required: true, index: true }, // role Teacher
    class: { type: mongoose.Schema.Types.ObjectId, ref: 'Class', required: true, index: true },
    subject: { type: mongoose.Schema.Types.ObjectId, ref: 'Subject', required: true, index: true },
    section: { type: mongoose.Schema.Types.ObjectId, ref: 'Section', default: null }, 
    academicYear: { type: String, required: true, trim: true, index: true },
  },
  { timestamps: true }
);

// prevent duplicates (same teacher teaching same subject in same class twice)
teachingAssignmentSchema.index({ school: 1, teacher: 1, class: 1, section: 1, subject: 1, academicYear: 1 }, { unique: true });

module.exports = mongoose.model('TeachingAssignment', teachingAssignmentSchema);