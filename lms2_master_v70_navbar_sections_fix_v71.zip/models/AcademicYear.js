const mongoose = require('mongoose');

const academicYearSchema = new mongoose.Schema(
  {
    school: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'School',
      required: true,
      index: true,
    },

    name: {
      type: String, // e.g. "2025/2026"
      required: true,
      trim: true,
    },

    isActive: {
      type: Boolean,
      default: false,
      index: true,
    },
  },
  { timestamps: true }
);

// prevent duplicates per school
academicYearSchema.index({ school: 1, name: 1 }, { unique: true });

module.exports = mongoose.model('AcademicYear', academicYearSchema);