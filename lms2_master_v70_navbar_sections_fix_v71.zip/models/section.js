const mongoose = require('mongoose');

const sectionSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true },
    phase: {
      type: String,
      enum: ['Primary', 'Secondary'],
      required: true,
      index: true,
    },
    class: { type: mongoose.Schema.Types.ObjectId, ref: 'Class', required: true },
    name: { type: String, required: true, trim: true }, // e.g. A, B, C, D
  },
  { timestamps: true }
);

// Prevent duplicates like "A" twice for same school + same class
sectionSchema.index({ school: 1, phase: 1, class: 1, name: 1 }, { unique: true });

module.exports = mongoose.model('Section', sectionSchema);