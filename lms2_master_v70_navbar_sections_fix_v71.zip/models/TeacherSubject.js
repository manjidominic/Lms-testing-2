const mongoose = require('mongoose');

const teacherSubjectSchema = new mongoose.Schema(
  {
    school: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'School',
      required: true,
      index: true,
    },

    teacher: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Teacher',
      required: true,
      index: true,
    },

    subject: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Subject',
      required: true,
      index: true,
    },

    // which class the teacher teaches that subject in
    class: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Class',
      required: true,
      index: true,
    },

    status: {
      type: String,
      enum: ['Active', 'Inactive'],
      default: 'Active',
    },
  },
  { timestamps: true }
);

// ✅ prevent duplicate assignment
teacherSubjectSchema.index(
  { school: 1, teacher: 1, subject: 1, class: 1 },
  { unique: true }
);

module.exports = mongoose.model('TeacherSubject', teacherSubjectSchema);