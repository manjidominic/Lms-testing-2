const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema(
  {
    // 🔐 Multi-school isolation
    school: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'School',
      required: true,
      index: true,
    },
    phase: {
      type: String,
      enum: ['Primary', 'Secondary'],
      required: true,
      index: true,
    },

    // 👤 Basic identity
    surname: {
      type: String,
      required: true,
      trim: true,
    },

    middleName: {
      type: String,
      trim: true,
      default: undefined,
    },

    firstName: {
      type: String,
      required: true,
      trim: true,
    },

    name: {
      type: String,
      required: true,
      trim: true,
    },

    parent: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Parent',
      default: null,
    },

    parentName: {
      type: String,
      trim: true,
      default: undefined,
    },

    parentEmail: {
      type: String,
      trim: true,
      lowercase: true,
      default: undefined,
    },

    parentPhone: {
      type: String,
      trim: true,
      default: undefined,
    },

    // 📧 Generated school email (login username)
    email: {
      type: String,
      required: true,
      lowercase: true,
    },

    username: {
      type: String,
      trim: true,
      lowercase: true,
      default: undefined,
    },

    // 🎓 Academic placement
    level: {
      type: String,
      enum: ['Primary', 'JSS', 'SSS'],
      required: true,
    },

    class: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Class',
      required: true,
    },

    section: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Section',
      default: null,
    },

    // 🧭 SSS track (only applies to SSS)
    track: {
      type: String,
      enum: ['Science', 'Art', 'Commercial', 'General', 'Other'],
      default: 'General',
    },

    // 📅 Academic lifecycle
    admissionYear: {
      type: String,
      required: true,
      match: [/^\d{4}$/, 'Admission year must be a valid 4-digit year'],
    },

    currentSession: {
      type: String,
      default: undefined,
    },

    status: {
      type: String,
      enum: ['Active', 'Graduated', 'Withdrawn', 'Completed'],
      default: 'Active',
    },

    statusAcademicYear: {
      type: String,
      default: undefined,
      trim: true,
    },

    portalAccess: {
      type: String,
      enum: ['parent_only', 'student_and_parent'],
      default: function () {
        return this.phase === 'Primary' ? 'parent_only' : 'student_and_parent';
      },
    },
  },
  {
    timestamps: true,
  }
);

// 🔎 Prevent duplicate student emails within the system

// 🔎 Fast school + class queries
studentSchema.index({ school: 1, phase: 1, class: 1 });
studentSchema.index({ school: 1, phase: 1, email: 1 });
studentSchema.index({ school: 1, phase: 1, username: 1 });

studentSchema.index({ school: 1, class: 1, status: 1, currentSession: 1, section: 1 });
studentSchema.index({ school: 1, class: 1, status: 1, currentSession: 1 });

module.exports = mongoose.model('Student', studentSchema);