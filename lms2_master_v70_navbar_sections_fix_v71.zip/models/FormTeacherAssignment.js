const mongoose = require('mongoose');

/**
 * One form teacher per class/section per academicYear.
 * Form teacher has access to all students/records in that class or section and can promote them.
 */
const formTeacherAssignmentSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    teacher: { type: mongoose.Schema.Types.ObjectId, ref: 'Teacher', required: true, index: true },
    class: { type: mongoose.Schema.Types.ObjectId, ref: 'Class', required: true, index: true },
    section: { type: mongoose.Schema.Types.ObjectId, ref: 'Section', default: null, index: true },
    academicYear: { type: String, required: true, trim: true, index: true },
  },
  { timestamps: true }
);

// one form teacher per class/section per year
formTeacherAssignmentSchema.index({ school: 1, class: 1, section: 1, academicYear: 1 }, { unique: true });

// prevent same teacher duplicated on same class/section per year
formTeacherAssignmentSchema.index({ school: 1, teacher: 1, class: 1, section: 1, academicYear: 1 }, { unique: true });

module.exports = mongoose.model('FormTeacherAssignment', formTeacherAssignmentSchema);
