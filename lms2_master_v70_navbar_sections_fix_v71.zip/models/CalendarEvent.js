const mongoose = require('mongoose');
const schema = new mongoose.Schema({
  school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
  title: { type: String, required: true, trim: true },
  description: { type: String, default: '' },
  startDate: { type: Date, required: true, index: true },
  endDate: { type: Date, required: true },
  type: { type: String, enum: ['Academic', 'Exam', 'Deadline', 'Event', 'Holiday'], default: 'Event' },
  audience: { type: String, enum: ['all', 'students', 'teachers', 'admin'], default: 'all' },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Account', default: null },
}, { timestamps: true });
schema.index({ school: 1, startDate: 1, audience: 1 });
module.exports = mongoose.model('CalendarEvent', schema);
