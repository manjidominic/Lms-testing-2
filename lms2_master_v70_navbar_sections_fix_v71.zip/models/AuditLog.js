const mongoose = require('mongoose');

const auditLogSchema = new mongoose.Schema({
  school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', default: null },
  actorAccount: { type: mongoose.Schema.Types.ObjectId, ref: 'Account', default: null },
  actorRole: { type: String, trim: true, default: '' },
  action: { type: String, required: true, trim: true },
  category: { type: String, trim: true, default: 'general' },
  targetType: { type: String, trim: true, default: '' },
  targetId: { type: String, trim: true, default: '' },
  message: { type: String, trim: true, default: '' },
  metadata: { type: mongoose.Schema.Types.Mixed, default: {} },
  ipAddress: { type: String, trim: true, default: '' },
  userAgent: { type: String, trim: true, default: '' },
}, { timestamps: true });

auditLogSchema.index({ school: 1, createdAt: -1 });
auditLogSchema.index({ actorAccount: 1, createdAt: -1 });
auditLogSchema.index({ action: 1, createdAt: -1 });

module.exports = mongoose.model('AuditLog', auditLogSchema);
