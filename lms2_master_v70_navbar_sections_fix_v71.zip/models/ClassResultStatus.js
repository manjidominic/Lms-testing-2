const mongoose = require('mongoose');

const classResultStatusSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    academicYear: { type: String, required: true, index: true },
    term: { type: String, required: true, index: true },
    class: { type: mongoose.Schema.Types.ObjectId, ref: 'Class', required: true, index: true },

    status: {
      type: String,
      enum: ['Draft', 'Submitted', 'Approved'],
      default: 'Draft',
      index: true,
    },

    submittedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Teacher' },
    submittedAt: { type: Date },
    approvedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Account' },
    approvedAt: { type: Date },
  },
  { timestamps: true }
);

classResultStatusSchema.index(
  { school: 1, academicYear: 1, term: 1, class: 1 },
  { unique: true }
);

classResultStatusSchema.index({ school: 1, academicYear: 1, term: 1, status: 1 });

module.exports = mongoose.model('ClassResultStatus', classResultStatusSchema);
