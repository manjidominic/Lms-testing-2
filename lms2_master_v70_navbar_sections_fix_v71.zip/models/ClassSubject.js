const mongoose = require('mongoose');

const classSubjectSchema = new mongoose.Schema(
  {
    school: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'School',
      required: true,
      index: true,
    },
    class: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Class',
      required: true,
      index: true,
    },
    subject: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Subject',
      required: true,
      index: true,
    },
    // Keep an offeringType so schools can offer a subject as elective even if globally marked elective.
    // By default we will use subject.type.
    offeringType: {
      type: String,
      enum: ['GENERAL', 'CORE', 'TRACK_CORE', 'ELECTIVE'],
      required: true,
      default: 'GENERAL',
      index: true,
    },
  },
  { timestamps: true }
);

classSubjectSchema.index({ school: 1, class: 1, subject: 1 }, { unique: true });

module.exports = mongoose.model('ClassSubject', classSubjectSchema);
