const mongoose = require('mongoose');

const schoolSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },

    // Platform owner can deactivate a school if needed
    isActive: { type: Boolean, default: true },

    phases: {
  type: [String],                 // array
  enum: ['Primary', 'Secondary'],  // allowed values
  required: true,                 // owner must choose
  validate: {
    validator: (arr) => Array.isArray(arr) && arr.length > 0,
    message: 'School must have at least one phase (Primary or Secondary).',
  },
},

    // You said: primary / secondary / both
    //type: { type: String, enum: ['primary', 'secondary', 'both'], required: true },

    // IMPORTANT for student email generation later:
    // sl => manji012025@sl.lms.com
    code: { type: String, required: true, lowercase: true, trim: true, unique: true },

    // SaaS subscription record (trial/active/expired)
    subscription: { type: mongoose.Schema.Types.ObjectId, ref: 'Subscription' },

    

    resultTemplateSettings: {
      Primary: { type: String, default: 'primary_plus_traits', trim: true },
      Secondary: { type: String, default: 'secondary_standard', trim: true },
    },

    resultTemplateConfigs: {
      Primary: {
        templateKey: { type: String, default: 'primary_plus_traits', trim: true },
        enabledSections: { type: [String], default: ['academic', 'attendance', 'affective', 'psychomotor', 'summary', 'comments'] },
        affectiveTraitKeys: { type: [String], default: ['punctuality', 'cleanliness', 'communication', 'attentiveness', 'honesty', 'cooperation'] },
        psychomotorTraitKeys: { type: [String], default: ['handwriting', 'sports', 'drawing', 'craft'] },
        ratingScale: { type: String, default: 'A-D', trim: true },
        showPosition: { type: Boolean, default: true },
        showAverage: { type: Boolean, default: true },
        showAttendance: { type: Boolean, default: true },
        showComments: { type: Boolean, default: true },
      },
      Secondary: {
        templateKey: { type: String, default: 'secondary_standard', trim: true },
        enabledSections: { type: [String], default: ['academic', 'attendance', 'summary', 'comments'] },
        affectiveTraitKeys: { type: [String], default: [] },
        psychomotorTraitKeys: { type: [String], default: [] },
        ratingScale: { type: String, default: 'A-D', trim: true },
        showPosition: { type: Boolean, default: true },
        showAverage: { type: Boolean, default: true },
        showAttendance: { type: Boolean, default: true },
        showComments: { type: Boolean, default: true },
      },
    },

    reportCardSettings: {
      logoUrl: { type: String, default: '', trim: true },
      faviconUrl: { type: String, default: '', trim: true },
      address: { type: String, default: '', trim: true },
      phone: { type: String, default: '', trim: true },
      email: { type: String, default: '', trim: true },
      principalName: { type: String, default: '', trim: true },
      principalTitle: { type: String, default: '', trim: true },
      classTeacherTitle: { type: String, default: '', trim: true },
      nextTermBegins: { type: String, default: '', trim: true },
      showLogo: { type: Boolean, default: true },
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('School', schoolSchema);