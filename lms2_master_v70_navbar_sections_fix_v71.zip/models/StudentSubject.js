const mongoose = require('mongoose');

const studentSubjectSchema = new mongoose.Schema(
  {
    // 🔐 multi-school boundary (important for safety + fast queries)
    school: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'School',
      required: true,
      index: true,
    },

    student: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Student',
      required: true,
      index: true,
    },

    subject: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Subject',
      required: true,
      index: true,
    },

    // "base" = assigned automatically for that level/track
    // "borrowed" = extra chosen by the student/school (SSS only)
    type: {
      type: String,
      enum: ['base', 'borrowed'],
      required: true,
      index: true,
    },

    session: {
      type: String, // "2025/2026"
      required: true,
      index: true,
    },
  },
  { timestamps: true }
);

// Prevent duplicate enrollment for same subject in same session
studentSubjectSchema.index(
  { school: 1, student: 1, subject: 1, session: 1 },
  { unique: true }
);


studentSubjectSchema.index({ school: 1, session: 1, student: 1, subject: 1 });
studentSubjectSchema.index({ school: 1, session: 1, subject: 1 });

module.exports = mongoose.model('StudentSubject', studentSubjectSchema);