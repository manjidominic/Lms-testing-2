const mongoose = require('mongoose');

const publishedSubjectSchema = new mongoose.Schema(
  {
    subject: { type: mongoose.Schema.Types.ObjectId, ref: 'Subject', required: true },
    name: { type: String, default: '' },
    code: { type: String, default: '' },
    ca1: { type: Number, default: 0 },
    ca2: { type: Number, default: 0 },
    exam: { type: Number, default: 0 },
    total: { type: Number, default: 0 },
    grade: { type: String, default: '' },
    remark: { type: String, default: '' },
  },
  { _id: false }
);

const publishedStudentResultSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    schoolName: { type: String, default: '', trim: true },
    schoolCode: { type: String, default: '', trim: true },
    academicYear: { type: String, required: true, trim: true, index: true },
    term: { type: String, required: true, trim: true, index: true },

    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true, index: true },
    studentName: { type: String, default: '', trim: true },
    studentEmail: { type: String, default: '', trim: true, lowercase: true, index: true },
    studentUsername: { type: String, default: '', trim: true, lowercase: true, index: true },
    class: { type: mongoose.Schema.Types.ObjectId, ref: 'Class', required: true, index: true },
    section: { type: mongoose.Schema.Types.ObjectId, ref: 'Section', default: null },

    phase: { type: String, enum: ['Primary', 'Secondary'], required: true },
    level: { type: String, enum: ['Primary', 'JSS', 'SSS'], required: true },
    track: { type: String, default: '' },

    subjects: { type: [publishedSubjectSchema], default: [] },
    summary: {
      total: { type: Number, default: 0 },
      average: { type: Number, default: 0 },
      position: { type: Number, default: null },
      subjectCount: { type: Number, default: 0 },
    },

    attendance: {
      attendanceTotal: { type: Number, default: 0 },
      cleanlinessRating: { type: String, default: '' },
      latenessCount: { type: Number, default: 0 },
      teacherComment: { type: String, default: '' },
    },

    overallRemark: { type: String, default: '', trim: true },
    principalComment: { type: String, default: '', trim: true },
    promotionDecision: { type: String, default: '', trim: true },

    template: {
      phase: { type: String, default: '', trim: true },
      key: { type: String, default: '', trim: true },
      title: { type: String, default: '', trim: true },
      sections: { type: [String], default: [] },
      ratingScale: { type: String, default: 'A-D', trim: true },
      displayOptions: {
        showPosition: { type: Boolean, default: true },
        showAverage: { type: Boolean, default: true },
        showAttendance: { type: Boolean, default: true },
        showComments: { type: Boolean, default: true },
      },
      affectiveTraits: { type: [{ key: String, label: String, value: String }], default: [] },
      psychomotorTraits: { type: [{ key: String, label: String, value: String }], default: [] },
    },

    reportCard: {
      logoUrl: { type: String, default: '', trim: true },
      faviconUrl: { type: String, default: '', trim: true },
      address: { type: String, default: '', trim: true },
      phone: { type: String, default: '', trim: true },
      email: { type: String, default: '', trim: true },
      principalName: { type: String, default: '', trim: true },
      principalTitle: { type: String, default: '', trim: true },
      classTeacherTitle: { type: String, default: 'Class Teacher', trim: true },
      nextTermBegins: { type: String, default: '', trim: true },
      showLogo: { type: Boolean, default: true },
    },

    sourceSnapshotId: { type: mongoose.Schema.Types.ObjectId, ref: 'ResultSnapshot', default: null },
    publishedAt: { type: Date, default: Date.now, index: true },
    publishedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Account', default: null },
  },
  { timestamps: true }
);

publishedStudentResultSchema.index(
  { school: 1, academicYear: 1, term: 1, student: 1 },
  { unique: true }
);

publishedStudentResultSchema.index({ school: 1, student: 1, publishedAt: -1 });
publishedStudentResultSchema.index({ school: 1, studentEmail: 1, publishedAt: -1 });
publishedStudentResultSchema.index({ school: 1, studentUsername: 1, publishedAt: -1 });
publishedStudentResultSchema.index({ school: 1, academicYear: 1, term: 1, class: 1 });

module.exports = mongoose.model('PublishedStudentResult', publishedStudentResultSchema);
