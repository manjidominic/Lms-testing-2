const mongoose = require('mongoose');

const subjectSnapshotSchema = new mongoose.Schema(
  {
    subject: { type: mongoose.Schema.Types.ObjectId, ref: 'Subject', required: true },
    name: { type: String },
    code: { type: String },

    ca1: { type: Number, default: 0 },
    ca2: { type: Number, default: 0 },
    exam: { type: Number, default: 0 },
    total: { type: Number, default: 0 },

    grade: { type: String },
    remark: { type: String },
  },
  { _id: false }
);

const resultSnapshotSchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    academicYear: { type: String, required: true, index: true },
    term: { type: String, required: true, index: true },

    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true, index: true },
    class: { type: mongoose.Schema.Types.ObjectId, ref: 'Class', required: true, index: true },
    section: { type: mongoose.Schema.Types.ObjectId, ref: 'Section' },

    phase: { type: String, enum: ['Primary', 'Secondary'], required: true },
    level: { type: String, enum: ['Primary', 'JSS', 'SSS'], required: true },
    track: { type: String },

    subjects: { type: [subjectSnapshotSchema], default: [] },

    summary: {
      total: { type: Number, default: 0 },
      average: { type: Number, default: 0 },
      position: { type: Number, default: null },
      subjectCount: { type: Number, default: 0 },
    },

    published: { type: Boolean, default: false, index: true },
    publishedAt: { type: Date, default: null },
    publishedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Account', default: null },

    computedAt: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

resultSnapshotSchema.index(
  { school: 1, academicYear: 1, term: 1, student: 1 },
  { unique: true }
);


resultSnapshotSchema.index({ school: 1, academicYear: 1, class: 1, section: 1, student: 1 });
resultSnapshotSchema.index({ school: 1, academicYear: 1, term: 1, class: 1, section: 1 });

module.exports = mongoose.model('ResultSnapshot', resultSnapshotSchema);
