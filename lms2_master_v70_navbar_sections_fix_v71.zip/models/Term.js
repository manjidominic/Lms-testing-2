const mongoose = require('mongoose');

const termSchema = new mongoose.Schema(
  {
    school: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'School',
      required: true,
      index: true,
    },

    academicYear: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'AcademicYear',
      required: true,
      index: true,
    },

    name: {
      type: String,
      enum: ['First Term', 'Second Term', 'Third Term'],
      required: true,
    },

    isActive: {
      type: Boolean,
      default: false,
      index: true,
    },

    isResultOpen: {
      type: Boolean,
      default: true,
    },
  },
  { timestamps: true }
);

// Prevent duplicates: same term name in same academic year (per school)
termSchema.index(
  { school: 1, academicYear: 1, name: 1 },
  { unique: true }
);

module.exports = mongoose.model('Term', termSchema);