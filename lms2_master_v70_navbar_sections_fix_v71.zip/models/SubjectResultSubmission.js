const mongoose = require("mongoose");

const schema = new mongoose.Schema({
  school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
  academicYear: { type: String, required: true, index: true, trim: true },
  term: { type: String, required: true, index: true, trim: true },
  class: { type: mongoose.Schema.Types.ObjectId, ref: 'Class', required: true, index: true },
  subject: { type: mongoose.Schema.Types.ObjectId, ref: 'Subject', required: true, index: true },
  section: { type: mongoose.Schema.Types.ObjectId, ref: 'Section', default: null, index: true },
  teacher: { type: mongoose.Schema.Types.ObjectId, ref: 'Teacher', required: true, index: true },
  status: { type: String, enum: ['Draft','Submitted'], default: 'Draft', index: true },
  computedAt: { type: Date },
  submittedAt: { type: Date },
  hasIncompleteScores: { type: Boolean, default: false },
  incompleteStudentCount: { type: Number, default: 0 },
  incompleteStudents: [{
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student' },
    name: { type: String, trim: true },
    missingComponents: [{ type: String, trim: true }],
  }],
}, { timestamps: true });

schema.index({ school:1, academicYear:1, term:1, class:1, subject:1, section:1 }, { unique: true });
module.exports = mongoose.model('SubjectResultSubmission', schema);
