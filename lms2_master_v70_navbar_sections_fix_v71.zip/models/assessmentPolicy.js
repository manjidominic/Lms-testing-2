const mongoose = require('mongoose');

const assessmentPolicySchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },

    // Primary / JSS / SSS
    level: { type: String, enum: ['Primary', 'JSS', 'SSS'], required: true, index: true },

    // "2025/2026"
    academicYear: { type: String, required: true, trim: true, index: true },

    max: {
      ca1:  { type: Number, required: true, min: 0 },
      ca2:  { type: Number, required: true, min: 0 },
      test1:{ type: Number, required: true, min: 0 },
      test2:{ type: Number, required: true, min: 0 },
      exam: { type: Number, required: true, min: 0 },
    },
  },
  { timestamps: true }
);

// Only ONE policy per school + year + level
assessmentPolicySchema.index(
  { school: 1, academicYear: 1, level: 1 },
  { unique: true }
);

module.exports = mongoose.model('AssessmentPolicy', assessmentPolicySchema);