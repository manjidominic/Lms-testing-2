const mongoose = require('mongoose');

const parentSchema = new mongoose.Schema({
  school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
  fullName: { type: String, required: true, trim: true },
  email: { type: String, trim: true, lowercase: true, default: undefined },
  phone: { type: String, trim: true, default: undefined },
  username: { type: String, trim: true, lowercase: true, default: undefined },
  isActive: { type: Boolean, default: true },
}, { timestamps: true });

parentSchema.index({ school: 1, email: 1 }, { unique: true, sparse: true });
parentSchema.index({ school: 1, phone: 1 }, { unique: true, sparse: true });
parentSchema.index({ school: 1, username: 1 }, { unique: true, sparse: true });

module.exports = mongoose.model('Parent', parentSchema);
