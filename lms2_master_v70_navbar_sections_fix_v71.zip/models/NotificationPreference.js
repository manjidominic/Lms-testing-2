const mongoose = require('mongoose');

const notificationPreferenceSchema = new mongoose.Schema(
  {
    school: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'School',
      required: true,
      index: true,
    },
    account: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Account',
      required: true,
      unique: true,
      index: true,
    },
    workflow: {
      type: Boolean,
      default: true,
    },
    publication: {
      type: Boolean,
      default: true,
    },
    announcement: {
      type: Boolean,
      default: true,
    },
    promotion: {
      type: Boolean,
      default: true,
    },
    general: {
      type: Boolean,
      default: true,
    },
  },
  { timestamps: true }
);

notificationPreferenceSchema.index({ school: 1, account: 1 }, { unique: true });

module.exports = mongoose.model('NotificationPreference', notificationPreferenceSchema);
