const mongoose = require('mongoose');

const promotionHistorySchema = new mongoose.Schema(
  {
    school: { type: mongoose.Schema.Types.ObjectId, ref: 'School', required: true, index: true },
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true, index: true },

    fromClass: { type: mongoose.Schema.Types.ObjectId, ref: 'Class', required: true },
    toClass: { type: mongoose.Schema.Types.ObjectId, ref: 'Class', default: null },

    action: {
      type: String,
      enum: ['PROMOTE', 'REPEAT', 'GRADUATE', 'COMPLETE_PRIMARY', 'WITHDRAW'],
      required: true,
      index: true,
    },

    academicYearFrom: { type: String, required: true, index: true },
    academicYearTo: { type: String, default: null, index: true },
    term: { type: String, required: true, index: true },

    performedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Account', default: null },
    note: { type: String, trim: true, default: '' },
  },
  { timestamps: true }
);

promotionHistorySchema.index({ school: 1, student: 1, academicYearFrom: 1 }, { unique: true });

module.exports = mongoose.model('PromotionHistory', promotionHistorySchema);
