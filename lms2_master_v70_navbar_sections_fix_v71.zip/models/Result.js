
const mongoose = require('mongoose');
const { getGradeAndRemark } = require('../utils/grading');


const resultSchema = new mongoose.Schema(
  {
    school: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'School',
      required: true,
      index: true,
    },

    student: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Student',
      required: true,
      index: true,
    },

    subject: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Subject',
      required: true,
      index: true,
    },

    class: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Class',
      required: true,
      index: true,
    },

    teacher: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Teacher',
      required: true,
      index: true,
    },

    academicYear: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'AcademicYear',
      required: true,
      index: true,
    },

    term: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Term',
      required: true,
      index: true,
    },

    // Scores (you can adjust max values later)
    assignment1: { type: Number, default: 0, min: 0, max: 10 },
    assignment2: { type: Number, default: 0, min: 0, max: 10 },
    test1: { type: Number, default: 0, min: 0, max: 10 },
    test2: { type: Number, default: 0, min: 0, max: 10 },
    exam: { type: Number, default: 0, min: 0, max: 60 },

    // computed/stored fields
    total: { type: Number, default: 0, min: 0, max: 100 },
    grade: { type: String, default: '' },   // e.g. A, B, C...
    remark: { type: String, default: '' },  // e.g. Excellent

    status: {
      type: String,
      enum: ['Draft', 'Submitted'],
      default: 'Draft',
      index: true,
    },
  },
  { timestamps: true }
);

// ✅ One result per student per subject per class per term per year (within a school)
resultSchema.index(
  { school: 1, student: 1, subject: 1, class: 1, academicYear: 1, term: 1 },
  { unique: true }
);

// Auto-calc total anytime scores change
resultSchema.pre('save', function (next) {
  const a1 = Number(this.assignment1 || 0);
  const a2 = Number(this.assignment2 || 0);
  const t1 = Number(this.test1 || 0);
  const t2 = Number(this.test2 || 0);
  const ex = Number(this.exam || 0);

  this.total = a1 + a2 + t1 + t2 + ex;

  const { grade, remark } = getGradeAndRemark(this.total);

  this.grade = grade;
  this.remark = remark;

  next();
});
module.exports = mongoose.model('Result', resultSchema);