const mongoose = require('mongoose');

const subscriptionSchema = new mongoose.Schema(
  {
    school: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'School',
      required: true,
      index: true,
      unique: true, // one subscription record per school (MVP)
    },

    // TRIAL: within trial window
    // ACTIVE: paid and within paid window
    // EXPIRED/CANCELLED: blocked for non-owner
    status: {
      type: String,
      enum: ['TRIAL', 'ACTIVE', 'EXPIRED', 'CANCELLED'],
      default: 'TRIAL',
      index: true,
    },

    trialStart: { type: Date },
    trialEnd: { type: Date },

    currentPeriodStart: { type: Date },
    currentPeriodEnd: { type: Date },

    lastRenewedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Account' },
    lastRenewedAt: { type: Date },
    lockedReason: { type: String, trim: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Subscription', subscriptionSchema);
