const express = require('express');
const router = express.Router();


const subjectsController = require('../controllers/subjects.controller');
const { requireAuth, requireRole } = require('../middlewares/auth.middleware');
const { attachSchool } = require('../middlewares/tenant.middleware');

// Admin only (server.js already protects, but keep consistent)
router.use(requireRole('owner', 'admin', 'staff'));

// List
router.get('/', subjectsController.listSubjects);

// Add form

router.get('/add', subjectsController.showAddForm);

// Create
router.post('/add', subjectsController.createSubject);

// View details
router.get('/:id/view', subjectsController.viewSubject);

// Edit form (optional)
router.get('/:id/edit', subjectsController.showEditForm);

// Assign classes offering the subject
router.get('/:id/classes', subjectsController.showAssignClasses);
router.post('/:id/classes', subjectsController.saveAssignClasses);

// Update (optional)
router.post('/:id/edit', subjectsController.updateSubject);

// Delete (optional)
router.post('/:id/delete', subjectsController.deleteSubject);

module.exports = router;