const express = require('express');
const router = express.Router();

router.use('/dashboard', require('./dashboard'));
router.use('/scoresheets', require('./scoresheets'));

module.exports = router;