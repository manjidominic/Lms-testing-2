const express = require('express');
const router = express.Router();

const teacherDashboardController = require('../../controllers/teacher/dashboard.controller');

router.get('/', teacherDashboardController.viewDashboard);
router.get('/class/:classId', teacherDashboardController.viewClassOverview);

module.exports = router;
