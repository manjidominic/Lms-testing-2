const express = require('express');
const router = express.Router();
const scoresheetsController = require('../../controllers/teacher/scoresheets.controller');



const { requireAuth, requireRole } = require('../../middlewares/auth.middleware');
const { attachSchool } = require('../../middlewares/tenant.middleware');

router.use(requireAuth, attachSchool, requireRole('teacher'));

// TEMP: just show something so route works
router.get('/', async (req, res) => {
  res.render('teachers/assignments/index', {
    title: 'My Assignments',
  });
});

module.exports = router;