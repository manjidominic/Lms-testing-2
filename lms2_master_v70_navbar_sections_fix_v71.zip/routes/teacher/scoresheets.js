const express = require('express');
const router = express.Router();
const scoresheetsController = require('../../controllers/teacher/scoresheets.controller');
const requireTermOpenForScores = require('../../middlewares/termLock.middleware');


router.get('/', scoresheetsController.list);
router.get('/:assignmentId', scoresheetsController.showEntry);
// Term lock: prevent score modifications when the active term is closed
router.post('/:assignmentId', requireTermOpenForScores, scoresheetsController.saveEntry);
router.post('/:assignmentId/compute', requireTermOpenForScores, scoresheetsController.computeSubject);
router.post('/:assignmentId/submit', requireTermOpenForScores, scoresheetsController.submitSubject);

module.exports = router;
