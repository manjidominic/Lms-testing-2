const express = require('express');
const router = express.Router();

const studentsController = require('../controllers/students.controller');
const promotionController = require('../controllers/promotion.controller');
const studentsService = require('../services/students/students.service');
const { limiters } = require('../middlewares/rateLimit.middleware');
const { auditAction } = require('../middlewares/auditAction.middleware');
const { validateBody, validateParams } = require('../middlewares/joiValidation.middleware');
const { createStudentSchema, studentStatusSchema } = require('../validators/student.schemas');
const { Joi, objectId } = require('../validators/common.schemas');

const classIdParamsSchema = Joi.object({
  classId: objectId.required().messages({
    'any.required': 'Class id is required.',
    'string.length': 'Please select a valid class.',
  }),
});

const studentIdParamsSchema = Joi.object({
  id: objectId.required().messages({
    'any.required': 'Student id is required.',
    'string.length': 'Student id is invalid.',
  }),
});

const studentSnapshotParamsSchema = Joi.object({
  id: objectId.required().messages({
    'any.required': 'Student id is required.',
    'string.length': 'Student id is invalid.',
  }),
  snapshotId: objectId.required().messages({
    'any.required': 'Result snapshot id is required.',
    'string.length': 'Result snapshot id is invalid.',
  }),
});

async function renderCreateStudentValidationError({ req, res, statusCode, message }) {
  const data = await studentsService.getAddStudentFormData({
    schoolId: req.schoolId,
    reqScopePhase: req.scopePhase,
  });

  return res.status(statusCode).render('students/add', {
    title: 'Register Student',
    classes: Array.isArray(data?.classes) ? data.classes : [],
    formError: message,
    formValues: { ...req.body },
  });
}

router.get('/', studentsController.listStudents);
router.get('/graduated', studentsController.listGraduatedStudents);
router.get('/add', studentsController.showAddForm);
router.post('/add', limiters.sensitiveWrite, validateBody(createStudentSchema, { onError: renderCreateStudentValidationError }), auditAction('STUDENT_CREATED'), studentsController.createStudent);
router.get('/classes/:classId/sections', validateParams(classIdParamsSchema), studentsController.getSectionsForClass);
router.get('/classes/:classId/enroll-electives', validateParams(classIdParamsSchema), studentsController.showBulkEnrollElectives);
router.post('/classes/:classId/enroll-electives', limiters.sensitiveWrite, validateParams(classIdParamsSchema), auditAction('STUDENT_ELECTIVES_BULK_ENROLLED', (req) => ({ classId: req.params.classId })), studentsController.bulkEnrollElectives);
router.post('/:id/status', limiters.sensitiveWrite, validateParams(studentIdParamsSchema), validateBody(studentStatusSchema), auditAction('STUDENT_STATUS_UPDATED', (req) => ({ studentId: req.params.id })), studentsController.updateStudentStatus);
router.get('/:id/results/print', validateParams(studentIdParamsSchema), studentsController.printStudentResultHistory);
router.get('/:id/results/pdf', validateParams(studentIdParamsSchema), studentsController.downloadStudentResultHistoryPdf);
router.get('/:id/results/:snapshotId/print', validateParams(studentSnapshotParamsSchema), studentsController.printStudentSingleResult);
router.get('/:id/results/:snapshotId/pdf', validateParams(studentSnapshotParamsSchema), studentsController.downloadStudentSingleResultPdf);
router.get('/:id/enrollment', validateParams(studentIdParamsSchema), studentsController.showEnrollmentPage);
router.post('/:id/enrollment', limiters.sensitiveWrite, validateParams(studentIdParamsSchema), auditAction('STUDENT_ENROLLMENT_SAVED', (req) => ({ studentId: req.params.id })), studentsController.saveEnrollment);
router.get('/:id', validateParams(studentIdParamsSchema), studentsController.viewStudentProfile);

module.exports = router;
