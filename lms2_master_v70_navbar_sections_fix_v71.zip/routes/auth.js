const express = require('express');
const router = express.Router();

const authController = require('../controllers/auth.controller');
const { buildRateLimiter, limiters } = require('../middlewares/rateLimit.middleware');
const { auditAction } = require('../middlewares/auditAction.middleware');
const { validateBody } = require('../middlewares/joiValidation.middleware');
const { setupOwnerSchema, loginSchema, changePasswordSchema } = require('../validators/auth.schemas');

const loginLimiter = buildRateLimiter({
  windowMs: 15 * 60 * 1000,
  max: 10,
  keyFn: (req) => `${req.ip}:login:${String(req.body?.schoolCode || '').trim().toLowerCase()}:${String(req.body?.identifier || req.body?.email || '').trim().toLowerCase()}`,
  message: 'Too many login attempts. Please wait and try again later.',
});

function renderSetupOwnerValidationError({ req, res, statusCode, message }) {
  return res.status(statusCode).render('auth/setup-owner', {
    title: 'Set Up Owner Account',
    error: message,
    form: { email: String(req.body?.email || '').trim().toLowerCase() },
  });
}

function renderLoginValidationError({ req, res, statusCode, message }) {
  return res.status(statusCode).render('auth/login', {
    title: 'Login',
    error: message,
    form: {
      schoolCode: String(req.body?.schoolCode || '').trim(),
      identifier: String(req.body?.identifier || '').trim(),
    },
  });
}

function renderChangePasswordValidationError({ req, res, statusCode, message }) {
  return res.status(statusCode).render('auth/change-password', {
    title: 'Change Password',
    user: req.session?.account || null,
    error: message,
  });
}

router.get('/setup-owner', authController.showSetupOwner);
router.post('/setup-owner', limiters.auth, validateBody(setupOwnerSchema, { onError: renderSetupOwnerValidationError }), auditAction('OWNER_SETUP_COMPLETED'), authController.setupOwner);

router.get('/login', authController.showLogin);
router.post('/login', loginLimiter, validateBody(loginSchema, { onError: renderLoginValidationError }), auditAction('LOGIN_ATTEMPT'), authController.login);
router.post('/logout', auditAction('LOGOUT'), authController.logout);
router.get('/change-password', authController.showChangePassword);
router.post('/change-password', limiters.auth, validateBody(changePasswordSchema, { onError: renderChangePasswordValidationError }), auditAction('PASSWORD_CHANGED'), authController.changePassword);

module.exports = router;
