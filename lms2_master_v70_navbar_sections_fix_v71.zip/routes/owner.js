const express = require('express');
const router = express.Router();

const ownerController = require('../controllers/owner.controller');
const { requireRole } = require('../middlewares/auth.middleware');
const { limiters } = require('../middlewares/rateLimit.middleware');
const { auditAction } = require('../middlewares/auditAction.middleware');
const { validateBody, validateParams } = require('../middlewares/joiValidation.middleware');
const { ownerSchoolIdParamsSchema, renewSubscriptionSchema } = require('../validators/owner.schemas');

// server.js applies requireAuth
router.use(requireRole('owner'));

router.get('/schools', ownerController.listSchools);
router.post('/schools/:schoolId/select', limiters.sensitiveWrite, validateParams(ownerSchoolIdParamsSchema), auditAction('OWNER_SELECTED_SCHOOL', (req) => ({ schoolId: req.params.schoolId })), ownerController.selectSchool);
router.post('/schools/:schoolId/renew', limiters.sensitiveWrite, validateParams(ownerSchoolIdParamsSchema), validateBody(renewSubscriptionSchema), auditAction('SCHOOL_SUBSCRIPTION_RENEWED', (req) => ({ schoolId: req.params.schoolId })), ownerController.renewSchoolSubscription);
router.post('/clear-school', limiters.sensitiveWrite, auditAction('OWNER_CLEARED_SELECTED_SCHOOL'), ownerController.clearSchool);

module.exports = router;
