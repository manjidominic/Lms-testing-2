const express = require('express');
const router = express.Router();

const sectionsController = require('../controllers/sections.controller');

router.get('/', sectionsController.listClassesPage);
router.post('/setup', sectionsController.saveSchoolClassSetup);

// Page: manage sections for a class
router.get('/class/:classId', sectionsController.manageSectionsPage);

// Add a new section to a class
router.post('/class/:classId', sectionsController.createSection);

// Delete a section
router.post('/:sectionId/delete', sectionsController.deleteSection);

module.exports = router;