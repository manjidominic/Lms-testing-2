const express = require('express');
const router = express.Router();
const promotionController = require('../controllers/promotion.controller')
const { requireFormTeacherForClass } = require('../middlewares/formTeacher.middleware');

router.get('/class/:classId', requireFormTeacherForClass, promotionController.showClassPromotionPage);
router.post('/class/:classId/preview', requireFormTeacherForClass, promotionController.previewClassPromotion);
router.post('/class/:classId/promote', requireFormTeacherForClass, promotionController.promoteStudentInClass);
router.post('/class/:classId/section', requireFormTeacherForClass, promotionController.createSectionForClass);
router.post('/class/:classId/assign-section', requireFormTeacherForClass, promotionController.assignSectionToStudents);

module.exports = router;