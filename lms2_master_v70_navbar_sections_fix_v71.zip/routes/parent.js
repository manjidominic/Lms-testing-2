const express = require('express');
const router = express.Router();
const controller = require('../controllers/parent.controller');

router.get('/dashboard', controller.viewDashboard);
router.get('/children', controller.listChildren);
router.get('/children/:studentId/results', controller.viewChildResult);
router.get('/children/:studentId/results/pdf', controller.downloadChildCurrentResultPdf);
router.get('/children/:studentId/profile', controller.viewChildProfile);
router.get('/children/:studentId/results/pdf-all', controller.downloadChildResultHistoryPdf);

module.exports = router;
