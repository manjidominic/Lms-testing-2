const router = require('express').Router();
const controller = require('../controllers/calendar.controller');
const { requireRole, requirePermission } = require('../middlewares/auth.middleware');
router.get('/', controller.index);
router.post('/', requireRole('admin', 'staff'), requirePermission('CAN_MANAGE_CALENDAR'), controller.create);
module.exports = router;
