const express = require('express');
const router = express.Router();

const schoolController = require('../controllers/school.controller');
const { validateBody } = require('../middlewares/joiValidation.middleware');
const { registerSchoolSchema } = require('../validators/school.schemas');

function renderRegisterSchoolValidationError({ req, res, statusCode, message }) {
  return res.status(statusCode).render('schools/register', {
    title: 'Register School',
    error: message,
    form: { ...req.body },
  });
}

router.get('/register', schoolController.showRegisterForm);
router.post('/register', validateBody(registerSchoolSchema, { onError: renderRegisterSchoolValidationError }), schoolController.registerSchool);

module.exports = router;
