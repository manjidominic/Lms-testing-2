const express = require('express');
const router = express.Router();

const studentDashboardController = require('../../controllers/student/dashboard.controller');

router.get('/', studentDashboardController.viewDashboard);
router.get('/profile', studentDashboardController.viewProfile);
router.get('/subjects', studentDashboardController.viewSubjects);

module.exports = router;
