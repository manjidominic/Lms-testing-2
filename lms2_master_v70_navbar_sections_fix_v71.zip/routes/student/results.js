const express = require('express');
const router = express.Router();

const { requireRole } = require('../../middlewares/auth.middleware');
const resultsController = require('../../controllers/student/results.controller');

router.use(requireRole('student'));

router.get('/', resultsController.viewMyResult);
router.get('/history', resultsController.viewMyResultHistory);
router.get('/print-all', resultsController.printMyAllResults);
router.get('/pdf-all', resultsController.downloadMyAllResultsPdf);
router.get('/print/:snapshotId', resultsController.printMySingleResult);
router.get('/pdf/:snapshotId', resultsController.downloadMySingleResultPdf);

module.exports = router;
