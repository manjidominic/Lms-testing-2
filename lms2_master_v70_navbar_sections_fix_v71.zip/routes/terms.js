const express = require('express');
const router = express.Router();

const termController = require('../controllers/academic/term.controller');
const { requireRole } = require('../middlewares/auth.middleware');

// server.js already does: requireAuth + attachSchool
router.use(requireRole('owner', 'admin'));

// list terms + form
router.get('/', termController.listTerms);

// create term
router.post('/add', termController.createTerm);

// set active term
router.post('/:id/activate', termController.activateTerm);

// open/close result entry for a term
router.post('/:id/toggle-results', termController.toggleResultOpen);

module.exports = router;