const express = require('express');
const router = express.Router();

const assignmentsController = require('../controllers/assignments.controller');
const { requireAuth, requireRole } = require('../middlewares/auth.middleware');
const { attachSchool } = require('../middlewares/tenant.middleware');

// Admin only
// server.js already applies requireAuth + attachSchool + attachScopePhase
router.use(requireRole('owner', 'admin'));

// Page: show assignment form + current assignments
router.get('/', assignmentsController.viewAssignmentsPage);

// Action: create assignment
router.post('/add', assignmentsController.createAssignment);

// Action: delete assignment
router.post('/:id/delete', assignmentsController.deleteAssignment);

module.exports = router;