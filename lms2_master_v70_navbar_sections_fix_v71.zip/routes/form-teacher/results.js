const express = require('express');
const router = express.Router();

const { requireRole } = require('../../middlewares/auth.middleware');
const { requireFormTeacherForClass } = require('../../middlewares/formTeacher.middleware');
const resultsController = require('../../controllers/formTeacher/results.controller');

// server.js already does: requireAuth + attachSchool + attachScopePhase + attachAcademicContext
// In this LMS a "form teacher" is still a teacher account, but with a special assignment.
// Allow both roles so assigned teachers can access the form-teacher pages.
router.use(requireRole('teacher', 'form_teacher'));

router.get('/', resultsController.index);
router.get('/class/:classId', requireFormTeacherForClass, resultsController.classView);
router.post('/submit/:classId', requireFormTeacherForClass, resultsController.submit);
router.post('/attendance/:classId', requireFormTeacherForClass, resultsController.saveAttendance);

module.exports = router;
