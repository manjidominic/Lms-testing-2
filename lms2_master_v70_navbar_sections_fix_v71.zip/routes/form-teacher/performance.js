const express = require('express');
const router = express.Router();

const { requireRole } = require('../../middlewares/auth.middleware');
const { requireFormTeacherForClass } = require('../../middlewares/formTeacher.middleware');
const performanceController = require('../../controllers/formTeacher/performance.controller');

// Allow teacher/form_teacher (assignment middleware enforces form-teacher status per class)
router.use(requireRole('teacher', 'form_teacher'));

router.get('/:classId', requireFormTeacherForClass, performanceController.viewClassPerformance);
router.post('/:classId/move', requireFormTeacherForClass, performanceController.moveStudents);

module.exports = router;
