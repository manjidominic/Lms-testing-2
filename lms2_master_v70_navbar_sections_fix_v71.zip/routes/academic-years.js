const express = require('express');
const router = express.Router();

const academicYearsController = require('../controllers/academicYears.controller');
const { requireRole } = require('../middlewares/auth.middleware');

// server.js already applies: requireAuth + attachSchool
router.use(requireRole('owner', 'admin'));

// List page
router.get('/', academicYearsController.listAcademicYears);

// Create
router.post('/add', academicYearsController.createAcademicYear);

// Set active
router.post('/:id/activate', academicYearsController.activateAcademicYear);

module.exports = router;