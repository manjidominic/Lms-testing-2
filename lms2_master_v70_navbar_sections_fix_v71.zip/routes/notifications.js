const { requireRole, requirePermission } = require('../middlewares/auth.middleware');
const router = require('express').Router();
const controller = require('../controllers/notifications.controller');

router.get('/', controller.index);
router.post('/read-all', controller.markAllRead);
router.post('/preferences', controller.updatePreferences);
router.post('/announcements', requireRole('admin', 'staff'), requirePermission('CAN_SEND_ANNOUNCEMENTS'), controller.createAnnouncement);
router.post('/:id/read', controller.markRead);

module.exports = router;
