const express = require('express');
const router = express.Router();
const controller = require('../../controllers/admin/imports.controller');
const { requirePermission } = require('../../middlewares/auth.middleware');
const { limiters } = require('../../middlewares/rateLimit.middleware');
const { auditAction } = require('../../middlewares/auditAction.middleware');
const { PERMISSIONS } = require('../../utils/permissions');

router.use(requirePermission(PERMISSIONS.MANAGE_STUDENTS, PERMISSIONS.MANAGE_TEACHERS));

router.get('/', controller.showImportCenter);
router.post('/preview', limiters.imports, auditAction('IMPORT_PREVIEW_CREATED'), controller.previewImport);
router.post('/commit', limiters.imports, auditAction('IMPORT_COMMITTED'), controller.commitImport);
router.post('/clear', limiters.imports, auditAction('IMPORT_PREVIEW_CLEARED'), controller.clearPreview);

module.exports = router;
