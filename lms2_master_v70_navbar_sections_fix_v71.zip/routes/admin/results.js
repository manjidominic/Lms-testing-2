const express = require('express');
const router = express.Router();

const resultsController = require('../../controllers/admin/results.controller');
const analyticsController = require('../../controllers/admin/analytics.controller');
const { requireRole, requirePermission } = require('../../middlewares/auth.middleware');
const { limiters } = require('../../middlewares/rateLimit.middleware');
const { auditAction } = require('../../middlewares/auditAction.middleware');

router.use(requireRole('owner', 'admin'));

router.get('/', resultsController.index);
router.get('/analytics', requirePermission('CAN_VIEW_ANALYTICS'), analyticsController.index);
router.post('/publish', limiters.publishing, auditAction('RESULTS_PUBLISHED'), requirePermission('CAN_PUBLISH_RESULTS'), resultsController.publish);
router.post('/class/:classId/approve', limiters.publishing, auditAction('CLASS_RESULTS_APPROVED', (req) => ({ classId: req.params.classId })), requirePermission('CAN_APPROVE_RESULTS'), resultsController.approveClass);
router.get('/class/:classId', resultsController.classBroadsheet);
router.get('/class/:classId/annual', resultsController.classAnnualBroadsheet);
router.get('/class/:classId/annual/print', resultsController.classAnnualBroadsheetPrint);
router.get('/class/:classId/annual/csv', resultsController.classAnnualBroadsheetCsv);
router.post('/class/:classId/annual/move', limiters.publishing, auditAction('ANNUAL_CLASS_MOVE', (req) => ({ classId: req.params.classId })), requirePermission('CAN_MANAGE_PROMOTION'), resultsController.annualMove);
router.get('/class/:classId/print', resultsController.classBroadsheetPrint);
router.get('/class/:classId/csv', resultsController.classBroadsheetCsv);
router.post('/compute/:classId', limiters.publishing, auditAction('CLASS_RESULTS_COMPUTED', (req) => ({ classId: req.params.classId })), resultsController.computeFreeze);
router.get('/student/:studentId', resultsController.studentResult);

module.exports = router;
