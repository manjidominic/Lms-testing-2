const express = require('express');
const router = express.Router();

const controller = require('../../controllers/admin/formTeachers.controller');

// server.js already applies requireAuth + attachSchool + attachScopePhase + role checks

router.get('/', controller.showPage);
router.post('/add', controller.assign);
router.post('/save-json', controller.assignAjax);
router.post('/:id/delete', controller.remove);
router.post('/:id/delete-json', controller.removeAjax);

module.exports = router;
