const express = require('express');
const router = express.Router();
const controller = require('../../controllers/admin/setup.controller');
const { requireRole, requirePermission } = require('../../middlewares/auth.middleware');
const { limiters } = require('../../middlewares/rateLimit.middleware');
const { auditAction } = require('../../middlewares/auditAction.middleware');
const { PERMISSIONS } = require('../../utils/permissions');
const {
  validate,
  bodyString,
  bodyUrl,
  bodyEmail,
  bodyEnum,
  bodyObjectId,
  paramObjectId,
} = require('../../middlewares/validation.middleware');

router.use(requireRole('owner', 'admin'));
router.get('/', controller.viewSetupWizard);
router.post('/skip', controller.skipSetupWizard);
router.post('/finish', controller.finishSetupWizard);
router.get('/result-templates', requirePermission(PERMISSIONS.MANAGE_RESULT_TEMPLATES), controller.viewResultTemplates);
router.post('/result-templates', requirePermission(PERMISSIONS.MANAGE_RESULT_TEMPLATES), controller.saveResultTemplates);
router.get('/report-card', requirePermission(PERMISSIONS.MANAGE_REPORT_CARD_SETTINGS), controller.viewReportCardSettings);
router.post(
  '/report-card',
  limiters.sensitiveWrite,
  auditAction('REPORT_CARD_SETTINGS_UPDATED'),
  validate([
    bodyUrl('logoUrl', 'Logo URL', { max: 255, imageOnly: true }),
    bodyUrl('faviconUrl', 'Favicon URL', { max: 255, imageOnly: true }),
    bodyString('address', 'Address', { max: 255 }),
    bodyString('phone', 'Phone', { max: 40 }),
    bodyEmail('email', 'Email', { required: false, max: 120 }),
    bodyString('principalName', 'Principal name', { max: 120 }),
    bodyString('principalTitle', 'Principal title', { max: 120 }),
    bodyString('classTeacherTitle', 'Class teacher title', { max: 120 }),
    bodyString('nextTermBegins', 'Next term begins', { max: 120 }),
  ]),
  requirePermission(PERMISSIONS.MANAGE_REPORT_CARD_SETTINGS),
  controller.saveReportCardSettings,
);
router.get('/security-audit', requirePermission(PERMISSIONS.VIEW_SECURITY_AUDIT), controller.viewSecurityAudit);
router.get('/password-resets', requirePermission(PERMISSIONS.RESET_PASSWORDS), controller.viewPasswordResets);
router.get('/permissions', requirePermission(PERMISSIONS.MANAGE_PERMISSIONS), controller.viewPermissionsManager);
router.post(
  '/permissions/:accountId',
  limiters.sensitiveWrite,
  auditAction('PERMISSIONS_UPDATED', (req) => ({ targetAccountId: req.params.accountId })),
  validate([paramObjectId('accountId', 'Account id')]),
  requirePermission(PERMISSIONS.MANAGE_PERMISSIONS),
  controller.savePermissionsManager,
);
router.get('/exports', requirePermission(PERMISSIONS.MANAGE_BACKUPS), controller.viewExportCenter);
router.get('/exports/students.csv', requirePermission(PERMISSIONS.MANAGE_BACKUPS), controller.downloadStudentsCsv);
router.get('/exports/parents.csv', requirePermission(PERMISSIONS.MANAGE_BACKUPS), controller.downloadParentsCsv);
router.get('/exports/published-results.csv', requirePermission(PERMISSIONS.MANAGE_BACKUPS), controller.downloadPublishedResultsCsv);
router.get('/exports/promotions.csv', requirePermission(PERMISSIONS.MANAGE_BACKUPS), controller.downloadPromotionsCsv);
router.get('/exports/security-audit.csv', requirePermission(PERMISSIONS.MANAGE_BACKUPS), controller.downloadSecurityAuditCsv);
router.get('/exports/calendar.csv', requirePermission(PERMISSIONS.MANAGE_BACKUPS), controller.downloadCalendarCsv);
router.get('/exports/full-backup.json', requirePermission(PERMISSIONS.MANAGE_BACKUPS), controller.downloadFullBackup);

router.post(
  '/exports/backup-schedule',
  limiters.backupRestore,
  auditAction('BACKUP_SCHEDULE_UPDATED'),
  validate([
    bodyEnum('frequency', 'Backup frequency', ['hourly', 'every_6_hours', 'every_12_hours', 'daily', 'weekly', 'monthly'], { required: true }),
    bodyString('timeOfDay', 'Backup time', { max: 5, pattern: /^\d{1,2}:\d{2}$/, patternMessage: 'Backup time must use HH:MM format.' }),
    bodyString('dayOfWeek', 'Backup week day', { max: 1, pattern: /^[0-6]$/, patternMessage: 'Backup week day must be between 0 and 6.' }),
    bodyString('dayOfMonth', 'Backup month day', { max: 2, pattern: /^(?:[1-9]|1\d|2[0-8])$/, patternMessage: 'Backup month day must be between 1 and 28.' }),
    bodyString('retentionCount', 'Retention count', { max: 2, pattern: /^(?:[1-9]|[1-4]\d|50)$/, patternMessage: 'Retention count must be between 1 and 50.' }),
  ]),
  requirePermission(PERMISSIONS.MANAGE_BACKUPS),
  controller.saveBackupSchedule,
);
router.post('/exports/run-backup-now', limiters.backupRestore, auditAction('BACKUP_RUN_NOW'), requirePermission(PERMISSIONS.MANAGE_BACKUPS), controller.runBackupNow);
router.get('/exports/archives/:fileName', requirePermission(PERMISSIONS.MANAGE_BACKUPS), controller.downloadBackupArchive);
router.post('/exports/archives/:fileName/delete', limiters.backupRestore, auditAction('BACKUP_ARCHIVE_DELETED', (req) => ({ fileName: req.params.fileName })), requirePermission(PERMISSIONS.MANAGE_BACKUPS), controller.deleteBackupArchive);
router.post('/restore', limiters.backupRestore, auditAction('BACKUP_RESTORE_REQUESTED'), requirePermission(PERMISSIONS.MANAGE_BACKUPS), controller.restoreFromBackup);
router.post(
  '/password-resets/:accountId/reset',
  limiters.sensitiveWrite,
  auditAction('ACCOUNT_PASSWORD_RESET', (req) => ({ targetAccountId: req.params.accountId })),
  validate([
    paramObjectId('accountId', 'Account id'),
    bodyString('temporaryPassword', 'Temporary password', { max: 120 }),
    bodyString('role', 'Role filter', { max: 40 }),
    bodyString('q', 'Search term', { max: 120 }),
  ]),
  requirePermission(PERMISSIONS.RESET_PASSWORDS),
  controller.resetAccountPassword,
);

module.exports = router;
