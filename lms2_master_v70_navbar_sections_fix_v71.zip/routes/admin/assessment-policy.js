const express = require('express');
const router = express.Router();

const assessmentPolicyController = require('../../controllers/admin/assessmentPolicy.controller');
const { requireRole } = require('../../middlewares/auth.middleware');

// server.js already applies requireAuth + attachSchool
router.use(requireRole('owner', 'admin'));

// view page (select year + level, edit policy)
router.get('/', assessmentPolicyController.showForm);

// save policy (upsert)
router.post('/', assessmentPolicyController.save);

module.exports = router;