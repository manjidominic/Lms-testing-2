const router = require('express').Router();
const controller = require('../../controllers/admin/parent.controller');
router.get('/', controller.listParents);
router.get('/:parentId', controller.showParent);
router.get('/:parentId/link', controller.showLinkForm);
router.post('/:parentId/link', controller.linkStudents);
router.post('/:parentId/unlink/:studentId', controller.unlinkStudent);
module.exports = router;
