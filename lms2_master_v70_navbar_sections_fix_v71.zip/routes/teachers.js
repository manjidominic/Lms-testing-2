const express = require('express');
const router = express.Router();

const teachersController = require('../controllers/teachers.controller');
const { requireAuth, requireRole } = require('../middlewares/auth.middleware');
const { attachSchool } = require('../middlewares/tenant.middleware');
const { requireTeachingAssignment } = require('../middlewares/teacher.middleware');
const { validateBody, validateParams } = require('../middlewares/joiValidation.middleware');
const { createTeacherSchema, teacherStatusSchema } = require('../validators/teacher.schemas');
const { Joi, objectId } = require('../validators/common.schemas');
// Admin only for now


// server.js already applies requireAuth + attachSchool + attachScopePhase
router.use(requireRole('owner', 'admin'));

// List teachers
router.get('/', teachersController.listTeachers);

// Add teacher form
router.get('/add', teachersController.showAddForm);

// Create teacher
router.post('/add', validateBody(createTeacherSchema), teachersController.createTeacher);

// Update teacher status (Active/Inactive)
router.post('/:id/status', validateParams(Joi.object({ id: objectId.required().messages({ 'any.required': 'Teacher id is required.', 'string.length': 'Teacher id is invalid.' }) })), validateBody(teacherStatusSchema), teachersController.updateTeacherStatus);

// Teacher profile (shows assignments)
router.get('/:id', validateParams(Joi.object({ id: objectId.required().messages({ 'any.required': 'Teacher id is required.', 'string.length': 'Teacher id is invalid.' }) })), teachersController.viewTeacher);

// Assign subject+class to teacher
router.post('/:id/assign-subject', teachersController.assignSubjectToTeacher);

// Remove assignment (optional)
router.post('/:id/assignments/:assignmentId/delete', teachersController.removeAssignment);


router.use(requireAuth, attachSchool, requireRole('Teacher'));

// list assignments (my classes + subjects)
router.get('/subjects', teachersController.listMySubjects);

// example: open subject page for a class
router.get('/class/:classId/subject/:subjectId',
  requireTeachingAssignment,
  teachersController.viewClassSubject
);

module.exports = router;