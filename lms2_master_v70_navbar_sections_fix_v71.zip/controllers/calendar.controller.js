const asyncHandler = require('../middlewares/asyncHandler');
const calendarService = require('../services/calendar/calendar.service');

exports.index = asyncHandler(async (req,res) => {
  const events = await calendarService.listEvents({ schoolId: req.schoolId, role: req.session.account.role });
  res.render('calendar/index', { title: 'Calendar', user: req.session.account, events });
});

exports.create = asyncHandler(async (req,res) => {
  if (!['owner','admin','staff'].includes(req.session.account.role)) {
    return res.status(403).render('error', { title:'Forbidden', status:403, message:'Only administration can create events.'});
  }
  await calendarService.createEvent({ schoolId: req.schoolId, actorAccountId: req.session.account.id, role: req.session.account.role, payload: {
    title: req.body.title,
    description: req.body.description,
    startDate: new Date(req.body.startDate),
    endDate: new Date(req.body.endDate || req.body.startDate),
    type: req.body.type,
    audience: req.body.audience,
  }});
  res.redirect('/calendar');
});
