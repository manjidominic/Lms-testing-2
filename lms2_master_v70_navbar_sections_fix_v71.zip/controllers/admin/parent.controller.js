const { recordAudit } = require('../../services/security/audit.service');
const asyncHandler = require('../../middlewares/asyncHandler');
const parentService = require('../../services/parents/parent.service');

exports.listParents = asyncHandler(async (req, res) => {
  const data = await parentService.listParentsWithChildren({ schoolId: req.schoolId });
  res.render('admin/parents/index', { title: 'Parents', user: req.session.account, ...data });
});

exports.showParent = asyncHandler(async (req, res) => {
  const data = await parentService.getParentAdminView({ schoolId: req.schoolId, parentId: req.params.parentId });
  res.render('admin/parents/show', { title: data.parent.fullName, user: req.session.account, ...data });
});

exports.showLinkForm = asyncHandler(async (req, res) => {
  const data = await parentService.getLinkFormData({ schoolId: req.schoolId, parentId: req.params.parentId, q: req.query.q || '' });
  res.render('admin/parents/link', { title: 'Link Children', user: req.session.account, ...data });
});

exports.linkStudents = asyncHandler(async (req, res) => {
  const ids = Array.isArray(req.body.studentIds) ? req.body.studentIds : (req.body.studentIds ? [req.body.studentIds] : []);
  const modifiedCount = await parentService.linkStudentsToParent({ schoolId: req.schoolId, parentId: req.params.parentId, studentIds: ids });
  await recordAudit({
    school: req.schoolId,
    actorAccount: req.session.account?.id || null,
    actorRole: req.session.account?.role || '',
    action: 'PARENT_CHILD_LINKED',
    category: 'parent',
    targetType: 'Parent',
    targetId: req.params.parentId,
    message: 'Students were linked to a parent.',
    metadata: { parentId: req.params.parentId, studentIds: ids, modifiedCount: modifiedCount || 0 },
    ipAddress: req.ip,
    userAgent: req.get('user-agent') || '',
  });
  res.redirect(`/admin/parents/${req.params.parentId}`);
});

exports.unlinkStudent = asyncHandler(async (req, res) => {
  await parentService.unlinkStudentFromParent({ schoolId: req.schoolId, parentId: req.params.parentId, studentId: req.params.studentId });
  await recordAudit({
    school: req.schoolId,
    actorAccount: req.session.account?.id || null,
    actorRole: req.session.account?.role || '',
    action: 'PARENT_CHILD_UNLINKED',
    category: 'parent',
    targetType: 'Parent',
    targetId: req.params.parentId,
    message: 'A student was unlinked from a parent.',
    metadata: { parentId: req.params.parentId, studentId: req.params.studentId },
    ipAddress: req.ip,
    userAgent: req.get('user-agent') || '',
  });
  res.redirect(`/admin/parents/${req.params.parentId}`);
});
