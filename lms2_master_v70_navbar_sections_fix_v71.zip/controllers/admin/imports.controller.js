const asyncHandler = require('../../middlewares/asyncHandler');
const importService = require('../../services/admin/import.service');
const { recordAudit } = require('../../services/security/audit.service');
const { hasPermission } = require('../../utils/permissions');
const { PERMISSIONS } = require('../../utils/permissions');

function getImportPermission(type) {
  return type === 'teachers' ? PERMISSIONS.MANAGE_TEACHERS : PERMISSIONS.MANAGE_STUDENTS;
}

function getPreviewSession(req) {
  return req.session.bulkImportPreview || null;
}

exports.showImportCenter = asyncHandler(async (req, res) => {
  const preview = getPreviewSession(req);
  const canImportStudents = hasPermission(req.session.account || {}, PERMISSIONS.MANAGE_STUDENTS);
  const canImportTeachers = hasPermission(req.session.account || {}, PERMISSIONS.MANAGE_TEACHERS);
  res.render('admin/imports/index', {
    title: 'Bulk Import Center',
    preview,
    canImportStudents,
    canImportTeachers,
    importResult: req.session.bulkImportResult || null,
  });
  delete req.session.bulkImportResult;
});

exports.previewImport = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const reqScopePhase = req.scopePhase;
  const academicYear = req.session.currentAcademicYear;
  const type = String(req.body.type || '').trim().toLowerCase();
  const csvText = String(req.body.csvText || '').trim();
  if (!['students', 'teachers'].includes(type)) {
    const err = new Error('Invalid import type');
    err.statusCode = 400;
    throw err;
  }
  const permission = getImportPermission(type);
  if (!hasPermission(req.session.account || {}, permission)) {
    const err = new Error('You do not have permission for that import.');
    err.statusCode = 403;
    throw err;
  }
  const rows = type === 'students'
    ? await importService.previewStudents({ schoolId, reqScopePhase, csvText, academicYear })
    : await importService.previewTeachers({ schoolId, reqScopePhase, csvText });
  req.session.bulkImportPreview = {
    type,
    rows,
    createdAt: Date.now(),
    schoolId: String(schoolId),
    scopePhase: reqScopePhase || null,
  };
  res.redirect('/admin/imports');
});

exports.commitImport = asyncHandler(async (req, res) => {
  const preview = getPreviewSession(req);
  if (!preview) {
    const err = new Error('No import preview found. Preview a CSV first.');
    err.statusCode = 400;
    throw err;
  }
  if (preview.schoolId !== String(req.schoolId)) {
    const err = new Error('Import preview does not belong to this school.');
    err.statusCode = 400;
    throw err;
  }
  const permission = getImportPermission(preview.type);
  if (!hasPermission(req.session.account || {}, permission)) {
    const err = new Error('You do not have permission for that import.');
    err.statusCode = 403;
    throw err;
  }
  const validRows = (preview.rows || []).filter((row) => !row.errors?.length);
  let results = [];
  if (preview.type === 'students') {
    results = await importService.importStudents({
      schoolId: req.schoolId,
      reqScopePhase: req.scopePhase,
      academicYear: req.session.currentAcademicYear,
      rows: validRows,
    });
  } else {
    results = await importService.importTeachers({
      schoolId: req.schoolId,
      reqScopePhase: req.scopePhase,
      rows: validRows,
    });
  }
  const successCount = results.filter((item) => item.success).length;
  const failedCount = results.length - successCount;
  req.session.bulkImportResult = { type: preview.type, successCount, failedCount, results };
  await recordAudit({
    school: req.schoolId,
    actorAccount: req.session.account.id,
    actorRole: req.session.account.role,
    action: `IMPORT_${String(preview.type || '').toUpperCase()}_CSV`,
    category: 'import',
    targetType: preview.type,
    metadata: { successCount, failedCount, totalAttempted: results.length },
    ipAddress: req.ip,
    userAgent: req.get('user-agent') || '',
  });
  delete req.session.bulkImportPreview;
  res.redirect('/admin/imports');
});

exports.clearPreview = asyncHandler(async (req, res) => {
  delete req.session.bulkImportPreview;
  res.redirect('/admin/imports');
});
