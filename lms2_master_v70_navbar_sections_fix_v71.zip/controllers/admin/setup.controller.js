const School = require('../../models/School');
const asyncHandler = require('../../middlewares/asyncHandler');
const { getSetupWizardData, markWizardSeen } = require('../../services/admin/setupWizard.service');
const {
  getTemplatesForPhase,
  getSchoolResultTemplateSettings,
  getTemplateCustomizationOptions,
  buildPhaseConfigFromRequest,
} = require('../../services/results/template.service');
const AuditLog = require('../../models/AuditLog');
const Account = require('../../models/Account');
const { recordAudit } = require('../../services/security/audit.service');
const { PERMISSION_GROUPS, PERMISSION_LABELS, normalizePermissions, getDefaultPermissionsForRole, getEffectivePermissions } = require('../../utils/permissions');
const { listSchoolAccounts, adminResetAccountPassword } = require('../../services/security/passwordReset.service');
const { getExportSummary, exportStudentsCsv, exportParentsCsv, exportPublishedResultsCsv, exportPromotionHistoryCsv, exportSecurityAuditCsv, exportCalendarCsv, buildFullBackup, restoreFullBackup } = require('../../services/admin/export.service');
const { getScheduleForSchool, saveSchedule, runBackupNow: executeBackupNow, listBackupArchives, getArchivePath, deleteArchive } = require('../../services/admin/backupAutomation.service');

function saveSession(req) {
  return new Promise((resolve, reject) => {
    req.session.save((err) => (err ? reject(err) : resolve()));
  });
}

exports.viewSetupWizard = asyncHandler(async (req, res) => {
  const data = await getSetupWizardData({
    schoolId: req.schoolId,
    scopePhase: req.scopePhase,
  });

  res.render('admin/setup-wizard', {
    title: 'School Setup Wizard',
    user: req.session.account,
    currentAcademicYear: req.session.currentAcademicYear || null,
    currentTerm: req.session.currentTerm || null,
    ...data,
  });
});

exports.skipSetupWizard = asyncHandler(async (req, res) => {
  const data = await getSetupWizardData({ schoolId: req.schoolId, scopePhase: req.scopePhase });
  markWizardSeen(req, data.setupKey, true);
  await saveSession(req);
  res.redirect('/dashboard');
});

exports.finishSetupWizard = asyncHandler(async (req, res) => {
  const data = await getSetupWizardData({ schoolId: req.schoolId, scopePhase: req.scopePhase });
  markWizardSeen(req, data.setupKey, false);
  await saveSession(req);
  res.redirect('/dashboard');
});



exports.viewResultTemplates = asyncHandler(async (req, res) => {
  const { school, selected, resolved } = await getSchoolResultTemplateSettings(req.schoolId);
  const primaryTemplates = getTemplatesForPhase('Primary');
  const secondaryTemplates = getTemplatesForPhase('Secondary');

  res.render('admin/result-templates', {
    title: 'Result Templates',
    user: req.session.account,
    currentAcademicYear: req.session.currentAcademicYear || null,
    currentTerm: req.session.currentTerm || null,
    school,
    selected,
    resolved,
    primaryTemplates,
    secondaryTemplates,
    primaryOptions: getTemplateCustomizationOptions(resolved.Primary),
    secondaryOptions: getTemplateCustomizationOptions(resolved.Secondary),
    saved: req.query.saved === '1',
  });
});

exports.saveResultTemplates = asyncHandler(async (req, res) => {
  const primaryTemplate = String(req.body.primaryTemplate || 'primary_plus_traits').trim();
  const secondaryTemplate = String(req.body.secondaryTemplate || 'secondary_standard').trim();

  const primaryConfig = buildPhaseConfigFromRequest({ body: req.body, phase: 'Primary', templateKey: primaryTemplate });
  const secondaryConfig = buildPhaseConfigFromRequest({ body: req.body, phase: 'Secondary', templateKey: secondaryTemplate });

  await School.findByIdAndUpdate(req.schoolId, {
    $set: {
      resultTemplateSettings: {
        Primary: primaryTemplate,
        Secondary: secondaryTemplate,
      },
      resultTemplateConfigs: {
        Primary: primaryConfig,
        Secondary: secondaryConfig,
      },
    },
  });

  await recordAudit({
    school: req.schoolId,
    actorAccount: req.session.account?.id || null,
    actorRole: req.session.account?.role || '',
    action: 'SETTINGS_RESULT_TEMPLATES_UPDATED',
    category: 'settings',
    targetType: 'School',
    targetId: req.schoolId,
    message: 'Result template settings were updated.',
    metadata: { primaryTemplate, secondaryTemplate },
    ipAddress: req.ip,
    userAgent: req.get('user-agent') || '',
  });

  res.redirect('/admin/setup/result-templates?saved=1');
});
exports.viewReportCardSettings = asyncHandler(async (req, res) => {
  const school = await School.findById(req.schoolId).lean();
  res.render('admin/report-card-settings', {
    title: 'Report Card Settings',
    user: req.session.account,
    currentAcademicYear: req.session.currentAcademicYear || null,
    currentTerm: req.session.currentTerm || null,
    school,
    settings: school?.reportCardSettings || {},
    query: req.query || {},
  });
});

exports.saveReportCardSettings = asyncHandler(async (req, res) => {
  const payload = {
    'reportCardSettings.logoUrl': String(req.body.logoUrl || '').trim(),
    'reportCardSettings.faviconUrl': String(req.body.faviconUrl || '').trim(),
    'reportCardSettings.address': String(req.body.address || '').trim(),
    'reportCardSettings.phone': String(req.body.phone || '').trim(),
    'reportCardSettings.email': String(req.body.email || '').trim(),
    'reportCardSettings.principalName': String(req.body.principalName || '').trim(),
    'reportCardSettings.principalTitle': String(req.body.principalTitle || '').trim(),
    'reportCardSettings.classTeacherTitle': String(req.body.classTeacherTitle || '').trim(),
    'reportCardSettings.nextTermBegins': String(req.body.nextTermBegins || '').trim(),
    'reportCardSettings.showLogo': req.body.showLogo === 'on',
  };

  await School.findByIdAndUpdate(req.schoolId, { $set: payload });
  await recordAudit({
    school: req.schoolId,
    actorAccount: req.session.account?.id || null,
    actorRole: req.session.account?.role || '',
    action: 'SETTINGS_REPORT_CARD_UPDATED',
    category: 'settings',
    targetType: 'School',
    targetId: req.schoolId,
    message: 'Report card settings were updated.',
    metadata: payload,
    ipAddress: req.ip,
    userAgent: req.get('user-agent') || '',
  });
  res.redirect('/admin/setup/report-card?saved=1');
});

exports.viewSecurityAudit = asyncHandler(async (req, res) => {
  const logs = await AuditLog.find({ school: req.schoolId }).sort({ createdAt: -1 }).limit(100).lean();
  res.render('admin/security-audit', {
    title: 'Security Audit',
    user: req.session.account,
    currentAcademicYear: req.session.currentAcademicYear || null,
    currentTerm: req.session.currentTerm || null,
    logs,
  });
});



exports.viewPermissionsManager = asyncHandler(async (req, res) => {
  const roleFilter = String(req.query.role || '').trim().toLowerCase();
  const allowedRoles = ['admin', 'staff'];
  const query = { school: req.schoolId, role: { $in: allowedRoles } };
  if (allowedRoles.includes(roleFilter)) query.role = roleFilter;

  const accounts = await Account.find(query)
    .sort({ role: 1, email: 1, username: 1 })
    .lean();

  const rows = accounts.map((account) => ({
    ...account,
    defaultPermissions: getDefaultPermissionsForRole(account.role),
    effectivePermissions: getEffectivePermissions(account),
  }));

  res.render('admin/permissions-manager', {
    title: 'Permissions Manager',
    user: req.session.account,
    currentAcademicYear: req.session.currentAcademicYear || null,
    currentTerm: req.session.currentTerm || null,
    accounts: rows,
    groups: PERMISSION_GROUPS,
    labels: PERMISSION_LABELS,
    roleFilter,
    query: req.query || {},
    saved: req.query.saved === '1',
  });
});

exports.savePermissionsManager = asyncHandler(async (req, res) => {
  const account = await Account.findOne({
    _id: req.params.accountId,
    school: req.schoolId,
    role: { $in: ['admin', 'staff'] },
  });

  if (!account) {
    return res.status(404).render('error', { title: 'Not Found', status: 404, message: 'Account not found.' });
  }

  const useCustomPermissions = req.body.useCustomPermissions === 'on';
  const selectedPermissions = normalizePermissions(req.body.permissions);

  account.useCustomPermissions = useCustomPermissions;
  account.permissions = useCustomPermissions ? selectedPermissions : [];
  await account.save();

  if (String(req.session?.account?.id || '') === String(account._id)) {
    req.session.account.useCustomPermissions = !!account.useCustomPermissions;
    req.session.account.rawPermissions = account.permissions;
    req.session.account.permissions = getEffectivePermissions(account);
    await saveSession(req);
  }

  await recordAudit({
    school: req.schoolId,
    actorAccount: req.session.account?.id || null,
    actorRole: req.session.account?.role || '',
    action: 'SETTINGS_PERMISSIONS_UPDATED',
    category: 'settings',
    targetType: 'Account',
    targetId: account._id,
    message: `Permissions updated for ${account.role} account.`,
    metadata: {
      useCustomPermissions: account.useCustomPermissions,
      permissions: getEffectivePermissions(account),
    },
    ipAddress: req.ip,
    userAgent: req.get('user-agent') || '',
  });

  return res.redirect(`/admin/setup/permissions?saved=1&role=${encodeURIComponent(String(req.query.role || account.role))}`);
});

exports.viewPasswordResets = asyncHandler(async (req, res) => {
  const role = String(req.query.role || '').trim();
  const q = String(req.query.q || '').trim();
  const accounts = await listSchoolAccounts({ schoolId: req.schoolId, role, q });

  const resetNotice = req.session.passwordResetNotice || null;
  if (req.session.passwordResetNotice) {
    delete req.session.passwordResetNotice;
    await saveSession(req);
  }

  res.render('admin/password-resets', {
    title: 'Account Recovery',
    user: req.session.account,
    currentAcademicYear: req.session.currentAcademicYear || null,
    currentTerm: req.session.currentTerm || null,
    query: { role, q },
    accounts,
    resetNotice,
  });
});

exports.resetAccountPassword = asyncHandler(async (req, res) => {
  const accountId = String(req.params.accountId || '');
  const temporaryPassword = String(req.body.temporaryPassword || '');
  const mustChangePassword = req.body.mustChangePassword === 'on';

  const result = await adminResetAccountPassword({
    schoolId: req.schoolId,
    accountId,
    temporaryPassword,
    mustChangePassword,
  });

  req.session.passwordResetNotice = {
    accountId: String(result.account._id),
    email: result.account.email,
    username: result.account.username || '',
    role: result.account.role,
    temporaryPassword: result.temporaryPassword,
    mustChangePassword: !!result.account.mustChangePassword,
  };
  await saveSession(req);

  await recordAudit({
    school: req.schoolId,
    actorAccount: req.session.account?.id || null,
    actorRole: req.session.account?.role || '',
    action: 'AUTH_PASSWORD_RESET_BY_ADMIN',
    category: 'auth',
    targetType: 'Account',
    targetId: result.account._id,
    message: 'Admin reset an account password.',
    metadata: {
      role: result.account.role,
      email: result.account.email,
      username: result.account.username || '',
      mustChangePassword: !!result.account.mustChangePassword,
    },
    ipAddress: req.ip,
    userAgent: req.get('user-agent') || '',
  });

  const params = new URLSearchParams();
  if (req.body.role) params.set('role', String(req.body.role));
  if (req.body.q) params.set('q', String(req.body.q));
  const suffix = params.toString() ? `?${params.toString()}` : '';
  res.redirect(`/admin/setup/password-resets${suffix}`);
});


exports.viewExportCenter = asyncHandler(async (req, res) => {
  const summary = await getExportSummary({ schoolId: req.schoolId });
  const backupSchedule = await getScheduleForSchool(req.schoolId);
  const backupArchives = await listBackupArchives({ schoolId: req.schoolId, limit: 20 });
  const backupScheduleNotice = req.session.backupScheduleNotice || null;
  if (req.session.backupScheduleNotice) {
    delete req.session.backupScheduleNotice;
    await saveSession(req);
  }
  res.render('admin/export-center', {
    title: 'Backup & Export Center',
    user: req.session.account,
    currentAcademicYear: req.session.currentAcademicYear || null,
    currentTerm: req.session.currentTerm || null,
    summary,
    backupSchedule,
    backupArchives,
    backupScheduleNotice,
    restoreSuccess: req.query.restoreSuccess === '1',
    restoreError: req.query.restoreError ? String(req.query.restoreError) : '',
    restoreTempPassword: req.query.restoreTempPassword ? String(req.query.restoreTempPassword) : '',
    restoreGeneratedAt: req.query.restoreGeneratedAt ? String(req.query.restoreGeneratedAt) : '',
  });
});

async function writeExportAudit(req, action, message, metadata = {}) {
  await recordAudit({
    school: req.schoolId,
    actorAccount: req.session.account?.id || null,
    actorRole: req.session.account?.role || '',
    action,
    category: 'export',
    targetType: 'School',
    targetId: req.schoolId,
    message,
    metadata,
    ipAddress: req.ip,
    userAgent: req.get('user-agent') || '',
  });
}

exports.downloadStudentsCsv = asyncHandler(async (req, res) => {
  const csv = await exportStudentsCsv({ schoolId: req.schoolId });
  await writeExportAudit(req, 'EXPORT_STUDENTS_CSV', 'Students CSV export downloaded.');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="students-${Date.now()}.csv"`);
  res.send(csv);
});

exports.downloadParentsCsv = asyncHandler(async (req, res) => {
  const csv = await exportParentsCsv({ schoolId: req.schoolId });
  await writeExportAudit(req, 'EXPORT_PARENTS_CSV', 'Parents CSV export downloaded.');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="parents-${Date.now()}.csv"`);
  res.send(csv);
});

exports.downloadPublishedResultsCsv = asyncHandler(async (req, res) => {
  const csv = await exportPublishedResultsCsv({ schoolId: req.schoolId });
  await writeExportAudit(req, 'EXPORT_PUBLISHED_RESULTS_CSV', 'Published results CSV export downloaded.');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="published-results-${Date.now()}.csv"`);
  res.send(csv);
});

exports.downloadPromotionsCsv = asyncHandler(async (req, res) => {
  const csv = await exportPromotionHistoryCsv({ schoolId: req.schoolId });
  await writeExportAudit(req, 'EXPORT_PROMOTIONS_CSV', 'Promotion history CSV export downloaded.');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="promotion-history-${Date.now()}.csv"`);
  res.send(csv);
});

exports.downloadSecurityAuditCsv = asyncHandler(async (req, res) => {
  const csv = await exportSecurityAuditCsv({ schoolId: req.schoolId });
  await writeExportAudit(req, 'EXPORT_SECURITY_AUDIT_CSV', 'Security audit CSV export downloaded.');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="security-audit-${Date.now()}.csv"`);
  res.send(csv);
});

exports.downloadCalendarCsv = asyncHandler(async (req, res) => {
  const csv = await exportCalendarCsv({ schoolId: req.schoolId });
  await writeExportAudit(req, 'EXPORT_CALENDAR_CSV', 'Calendar CSV export downloaded.');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="calendar-events-${Date.now()}.csv"`);
  res.send(csv);
});

exports.downloadFullBackup = asyncHandler(async (req, res) => {
  const backup = await buildFullBackup({ schoolId: req.schoolId });
  await writeExportAudit(req, 'EXPORT_FULL_BACKUP_JSON', 'Full school JSON backup downloaded.', {
    counts: backup.counts,
  });
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="school-backup-${Date.now()}.json"`);
  res.send(JSON.stringify(backup, null, 2));
});


exports.restoreFromBackup = asyncHandler(async (req, res) => {
  const backupJson = String(req.body.backupJson || '');
  const confirmSchoolCode = String(req.body.confirmSchoolCode || '').trim();

  try {
    const result = await restoreFullBackup({
      schoolId: req.schoolId,
      backupText: backupJson,
      expectedSchoolCode: confirmSchoolCode,
      actorAccountId: req.session.account?.id || null,
    });

    await writeExportAudit(req, 'RESTORE_FULL_BACKUP_JSON', 'Full school JSON backup restored.', {
      restoredCounts: result.restoredCounts,
      generatedAt: result.generatedAt,
    });

    const params = new URLSearchParams({
      restoreSuccess: '1',
      restoreTempPassword: result.temporaryPassword,
    });
    if (result.generatedAt) params.set('restoreGeneratedAt', result.generatedAt);
    return res.redirect(`/admin/setup/exports?${params.toString()}`);
  } catch (err) {
    const params = new URLSearchParams({
      restoreError: err.message || 'Restore failed.',
    });
    return res.redirect(`/admin/setup/exports?${params.toString()}`);
  }
});


exports.saveBackupSchedule = asyncHandler(async (req, res) => {
  const enabled = req.body.enabled === 'on';
  const schedule = await saveSchedule({
    schoolId: req.schoolId,
    actorAccountId: req.session.account?.id || null,
    enabled,
    frequency: String(req.body.frequency || 'daily'),
    timeOfDay: String(req.body.timeOfDay || '02:00'),
    dayOfWeek: Number(req.body.dayOfWeek || 0),
    dayOfMonth: Number(req.body.dayOfMonth || 1),
    retentionCount: Number(req.body.retentionCount || 10),
  });

  await recordAudit({
    school: req.schoolId,
    actorAccount: req.session.account?.id || null,
    actorRole: req.session.account?.role || '',
    action: 'BACKUP_SCHEDULE_UPDATED',
    category: 'backup',
    targetType: 'BackupSchedule',
    targetId: schedule._id || null,
    message: 'Automated backup schedule was updated.',
    metadata: {
      enabled: schedule.enabled,
      frequency: schedule.frequency,
      timeOfDay: schedule.timeOfDay,
      dayOfWeek: schedule.dayOfWeek,
      dayOfMonth: schedule.dayOfMonth,
      retentionCount: schedule.retentionCount,
      nextRunAt: schedule.nextRunAt,
    },
    ipAddress: req.ip,
    userAgent: req.get('user-agent') || '',
  });

  req.session.backupScheduleNotice = {
    type: 'success',
    message: schedule.enabled ? 'Automated backup schedule saved successfully.' : 'Automated backup schedule disabled.',
  };
  await saveSession(req);
  res.redirect('/admin/setup/exports');
});

exports.runBackupNow = asyncHandler(async (req, res) => {
  const result = await executeBackupNow({
    schoolId: req.schoolId,
    actorAccountId: req.session.account?.id || null,
    actorRole: req.session.account?.role || '',
    trigger: 'manual',
  });
  req.session.backupScheduleNotice = {
    type: 'success',
    message: `Backup created successfully as ${result.fileName}.`,
  };
  await saveSession(req);
  res.redirect('/admin/setup/exports');
});

exports.downloadBackupArchive = asyncHandler(async (req, res) => {
  const fileName = String(req.params.fileName || '');
  const filePath = await getArchivePath({ schoolId: req.schoolId, fileName });
  await writeExportAudit(req, 'EXPORT_AUTOMATED_BACKUP_DOWNLOAD', 'Stored backup archive downloaded.', { fileName });
  res.download(filePath, fileName);
});

exports.deleteBackupArchive = asyncHandler(async (req, res) => {
  const fileName = String(req.params.fileName || '');
  await deleteArchive({ schoolId: req.schoolId, fileName });
  await recordAudit({
    school: req.schoolId,
    actorAccount: req.session.account?.id || null,
    actorRole: req.session.account?.role || '',
    action: 'BACKUP_ARCHIVE_DELETED',
    category: 'backup',
    targetType: 'BackupArchive',
    targetId: fileName,
    message: 'A stored automated backup archive was deleted.',
    metadata: { fileName },
    ipAddress: req.ip,
    userAgent: req.get('user-agent') || '',
  });
  req.session.backupScheduleNotice = { type: 'success', message: `Backup archive ${fileName} deleted.` };
  await saveSession(req);
  res.redirect('/admin/setup/exports');
});
