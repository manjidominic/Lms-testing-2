const asyncHandler = require('../../middlewares/asyncHandler');
const analyticsService = require('../../services/admin/analytics.service');

exports.index = asyncHandler(async (req, res) => {
  const payload = await analyticsService.getAnalyticsPageData({
    schoolId: req.schoolId,
    academicYear: req.session.currentAcademicYear,
    term: req.session.currentTerm,
    reqScopePhase: req.scopePhase,
  });

  res.render('admin/analytics/index', payload);
});
