const asyncHandler = require('../../middlewares/asyncHandler');
const AssessmentPolicy = require('../../models/assessmentPolicy');
const AcademicYear = require('../../models/AcademicYear');
const School = require('../../models/School');

const ALL_LEVELS = ['Primary', 'JSS', 'SSS'];
const PRIMARY_LEVELS = ['Primary'];
const SECONDARY_LEVELS = ['JSS', 'SSS'];

function normalizeScopePhase(value) {
  const v = String(value || '').trim().toLowerCase();
  if (v === 'primary') return 'Primary';
  if (v === 'secondary') return 'Secondary';
  return null;
}

function getAllowedLevels(scopePhase) {
  const phase = normalizeScopePhase(scopePhase);
  if (phase === 'Primary') return PRIMARY_LEVELS;
  if (phase === 'Secondary') return SECONDARY_LEVELS;
  return ALL_LEVELS;
}

async function getActiveAcademicYearName(schoolId) {
  const active = await AcademicYear.findOne({ school: schoolId, isActive: true }).select('name');
  return active?.name || null;
}

async function getSchoolPhases(schoolId) {
  const school = await School.findById(schoolId).select('phases').lean();
  return Array.isArray(school?.phases) ? school.phases.map(normalizeScopePhase).filter(Boolean) : [];
}

function resolveEffectivePhase({ requestedPhase, accountScopePhase, schoolPhases, level }) {
  const requestPhase = normalizeScopePhase(requestedPhase);
  const scoped = normalizeScopePhase(accountScopePhase);
  if (scoped) return scoped;
  if (requestPhase && schoolPhases.includes(requestPhase)) return requestPhase;

  const normalizedLevel = String(level || '').trim();
  if (normalizedLevel === 'Primary' && schoolPhases.includes('Primary')) return 'Primary';
  if (['JSS', 'SSS'].includes(normalizedLevel) && schoolPhases.includes('Secondary')) return 'Secondary';

  if (schoolPhases.length === 1) return schoolPhases[0];
  return schoolPhases[0] || null;
}

exports.showForm = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  let academicYear = String(req.query.academicYear || '').trim();
  if (!academicYear) academicYear = await getActiveAcademicYearName(schoolId);

  const schoolPhases = await getSchoolPhases(schoolId);
  const effectivePhase = resolveEffectivePhase({
    requestedPhase: req.query.phase,
    accountScopePhase: req.scopePhase,
    schoolPhases,
    level: req.query.level,
  });

  const allowedLevels = getAllowedLevels(effectivePhase);
  const defaultLevel = allowedLevels[0] || 'Primary';
  let level = String(req.query.level || defaultLevel).trim();
  if (!allowedLevels.includes(level)) level = defaultLevel;

  const policy = academicYear
    ? await AssessmentPolicy.findOne({ school: schoolId, academicYear, level })
    : null;

  const years = await AcademicYear.find({ school: schoolId })
    .sort({ createdAt: -1 })
    .select('name isActive');

  return res.render('admin/assessment-policy', {
    academicYear,
    level,
    levels: allowedLevels,
    years,
    policy,
    phase: effectivePhase,
    availablePhases: schoolPhases,
  });
});

exports.save = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;

  const academicYear = String(req.body.academicYear || '').trim();
  const phase = normalizeScopePhase(req.body.phase || req.scopePhase);
  const level = String(req.body.level || '').trim();

  if (!academicYear) {
    const err = new Error('Academic year is required');
    err.statusCode = 400;
    throw err;
  }

  const schoolPhases = await getSchoolPhases(schoolId);
  const effectivePhase = resolveEffectivePhase({
    requestedPhase: phase,
    accountScopePhase: req.scopePhase,
    schoolPhases,
    level,
  });
  const allowedLevels = getAllowedLevels(effectivePhase);
  if (!allowedLevels.includes(level)) {
    const err = new Error('Invalid level for the selected phase');
    err.statusCode = 400;
    throw err;
  }

  const max = {
    ca1: Number(req.body.ca1),
    ca2: Number(req.body.ca2),
    test1: Number(req.body.test1),
    test2: Number(req.body.test2),
    exam: Number(req.body.exam),
  };

  for (const [k, v] of Object.entries(max)) {
    if (!Number.isFinite(v) || v < 0) {
      const err = new Error(`Invalid max for ${k}`);
      err.statusCode = 400;
      throw err;
    }
  }

  await AssessmentPolicy.findOneAndUpdate(
    { school: schoolId, academicYear, level },
    { $set: { max } },
    { upsert: true, new: true, runValidators: true }
  );

  const params = new URLSearchParams({ academicYear, level });
  if (effectivePhase) params.set('phase', effectivePhase);
  return res.redirect(`/admin/assessment-policy?${params.toString()}`);
});
