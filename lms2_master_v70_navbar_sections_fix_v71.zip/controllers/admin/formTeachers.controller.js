const asyncHandler = require('../../middlewares/asyncHandler');
const formTeachersService = require('../../services/formTeachers/formTeachers.service');

exports.showPage = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const reqScopePhase = req.scopePhase;
  const academicYear = req.session.currentAcademicYear;

  const data = await formTeachersService.getPageData({ schoolId, reqScopePhase, academicYear });
  return res.render('admin/form-teachers', {
    title: 'Form Teacher Assignment',
    user: req.session?.account,
    schoolId,
    ...data,
  });
});

exports.assign = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const reqScopePhase = req.scopePhase;
  const academicYear = req.session.currentAcademicYear;
  const { teacherId, classId, sectionId } = req.body;

  await formTeachersService.assignFormTeacher({ schoolId, reqScopePhase, academicYear, teacherId, classId, sectionId });
  return res.redirect('/admin/form-teachers');
});

exports.remove = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const { id } = req.params;

  await formTeachersService.removeAssignment({ schoolId, assignmentId: id });
  return res.redirect('/admin/form-teachers');
});

exports.assignAjax = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const reqScopePhase = req.scopePhase;
  const academicYear = req.session.currentAcademicYear;
  const { teacherId, classId, sectionId } = req.body;

  await formTeachersService.assignFormTeacher({ schoolId, reqScopePhase, academicYear, teacherId, classId, sectionId });
  res.json({ success: true });
});

exports.removeAjax = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const { id } = req.params;
  await formTeachersService.removeAssignment({ schoolId, assignmentId: id });
  res.json({ success: true });
});
