const { recordAudit } = require('../../services/security/audit.service');
const asyncHandler = require('../../middlewares/asyncHandler');
const workflow = require('../../services/admin/resultsWorkflow.service');
const notificationService = require('../../services/notifications/notification.service');

function sendCsv(res, { csv, filename }) {
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  return res.send(csv);
}

exports.index = asyncHandler(async (req, res) => {
  const payload = await workflow.listClassesWithResultStatus(req);
  res.render('admin/results/index', payload);
});

exports.computeFreeze = asyncHandler(async (req, res) => {
  const { redirectTo } = await workflow.computeFreezeForClass(req);
  res.redirect(redirectTo);
});

exports.publish = asyncHandler(async (req, res) => {
  const { redirectTo } = await workflow.publishComputedResults(req);
  await notificationService.notifyResultsPublished({
    schoolId: req.schoolId,
    actorAccountId: req.session.account?.id,
    academicYear: req.session.currentAcademicYear,
    term: req.session.currentTerm,
  });
  await recordAudit({
    school: req.schoolId,
    actorAccount: req.session.account?.id || null,
    actorRole: req.session.account?.role || '',
    action: 'RESULTS_PUBLISHED',
    category: 'results',
    targetType: 'AcademicSession',
    targetId: `${req.session.currentAcademicYear || ''}:${req.session.currentTerm || ''}`,
    message: 'Results were published to student and parent portals.',
    metadata: { academicYear: req.session.currentAcademicYear || null, term: req.session.currentTerm || null },
    ipAddress: req.ip,
    userAgent: req.get('user-agent') || '',
  });
  res.redirect(redirectTo);
});

exports.approveClass = asyncHandler(async (req, res) => {
  const { redirectTo } = await workflow.approveClassForAdmin(req);
  await notificationService.notifyClassApproved({
    schoolId: req.schoolId,
    actorAccountId: req.session.account?.id,
    classId: req.params.classId,
  });
  await recordAudit({
    school: req.schoolId,
    actorAccount: req.session.account?.id || null,
    actorRole: req.session.account?.role || '',
    action: 'RESULTS_CLASS_APPROVED',
    category: 'results',
    targetType: 'Class',
    targetId: req.params.classId,
    message: 'A class result set was approved.',
    metadata: { classId: req.params.classId, academicYear: req.session.currentAcademicYear || null, term: req.session.currentTerm || null },
    ipAddress: req.ip,
    userAgent: req.get('user-agent') || '',
  });
  res.redirect(redirectTo);
});

exports.classBroadsheet = asyncHandler(async (req, res) => {
  const { view, payload } = await workflow.getClassBroadsheetPageData(req);
  res.render(view, payload);
});

exports.classAnnualBroadsheet = asyncHandler(async (req, res) => {
  const { view, payload } = await workflow.getAnnualBroadsheetPageData(req);
  res.render(view, payload);
});

exports.classAnnualBroadsheetPrint = asyncHandler(async (req, res) => {
  const { view, payload } = await workflow.getAnnualPrintData(req);
  res.render(view, payload);
});

exports.classAnnualBroadsheetCsv = asyncHandler(async (req, res) => {
  const file = await workflow.getAnnualCsvDownload(req);
  sendCsv(res, file);
});

exports.annualMove = asyncHandler(async (req, res) => {
  const { redirectTo } = await workflow.moveStudentsFromAnnualBroadsheet(req);
  res.redirect(redirectTo);
});

exports.studentResult = asyncHandler(async (req, res) => {
  const { view, payload } = await workflow.getStudentResultPageData(req);
  res.render(view, payload);
});

exports.classBroadsheetPrint = asyncHandler(async (req, res) => {
  const { view, payload } = await workflow.getClassPrintData(req);
  res.render(view, payload);
});

exports.classBroadsheetCsv = asyncHandler(async (req, res) => {
  const file = await workflow.getClassCsvDownload(req);
  sendCsv(res, file);
});
