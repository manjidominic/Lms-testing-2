const crypto = require('crypto');
const bcrypt = require('bcrypt');
const asyncHandler = require('../middlewares/asyncHandler');
const registerOwnerService = require('../services/auth/registerOwner.service');
const loginService = require('../services/auth/login.service');
const { resolveStudentIdentity } = require('../services/students/resolveStudentIdentity.service');
const { recordAudit } = require('../services/security/audit.service');
const Account = require('../models/Account');
const { getEffectivePermissions } = require('../utils/permissions');

async function getExistingOwner() {
  return Account.findOne({ role: 'owner' }).lean();
}

async function saveSession(req) {
  await new Promise((resolve, reject) => {
    req.session.save((err) => (err ? reject(err) : resolve()));
  });
}

function getRoleHomePath(role) {
  if (role === 'owner') return '/owner/schools';
  if (role === 'student') return '/student/dashboard';
  if (role === 'parent') return '/parent/dashboard';
  if (role === 'teacher' || role === 'form_teacher') return '/teacher/dashboard';
  return '/dashboard';
}

exports.showRegisterOwner = (req, res) => {
  res.render('auth/register-owner', { title: 'Create Owner Account' });
};

exports.registerOwner = asyncHandler(async (req, res) => {
  const { schoolCode, email, password } = req.body;
  await registerOwnerService({ schoolCode, email, password });
  res.redirect('/auth/login');
});

exports.showSetupOwner = asyncHandler(async (req, res) => {
  const owner = await getExistingOwner();
  if (owner) {
    return res.redirect('/auth/login');
  }

  return res.render('auth/setup-owner', {
    title: 'Set Up Owner Account',
    error: null,
    form: { email: '' },
  });
});

exports.setupOwner = asyncHandler(async (req, res) => {
  const existingOwner = await getExistingOwner();
  if (existingOwner) {
    return res.redirect('/auth/login');
  }

  const email = String(req.body.email || '').toLowerCase().trim();
  const password = String(req.body.password || '');
  const confirmPassword = String(req.body.confirmPassword || '');

  if (!email) {
    return res.status(400).render('auth/setup-owner', {
      title: 'Set Up Owner Account',
      error: 'Email is required.',
      form: { email },
    });
  }

  if (!password || password.length < 8) {
    return res.status(400).render('auth/setup-owner', {
      title: 'Set Up Owner Account',
      error: 'Password must be at least 8 characters.',
      form: { email },
    });
  }

  if (password !== confirmPassword) {
    return res.status(400).render('auth/setup-owner', {
      title: 'Set Up Owner Account',
      error: 'Password and confirm password do not match.',
      form: { email },
    });
  }

  const passwordHash = await bcrypt.hash(password, 10);

  await Account.create({
    role: 'owner',
    email,
    passwordHash,
    isActive: true,
    mustChangePassword: false,
  });

  return res.redirect('/auth/login');
});

exports.showLogin = asyncHandler(async (req, res) => {
  if (req.session?.account) {
    if (req.session.account.mustChangePassword) {
      return res.redirect('/auth/change-password');
    }
    return res.redirect(getRoleHomePath(req.session.account.role));
  }

  const owner = await getExistingOwner();
  if (!owner) {
    return res.redirect('/auth/setup-owner');
  }

  return res.render('auth/login', {
    title: 'Login',
    error: null,
    form: { schoolCode: '', identifier: '' },
  });
});

exports.login = asyncHandler(async (req, res) => {
  const schoolCode = String(req.body.schoolCode || '').trim();
  const identifier = String(req.body.identifier || req.body.email || '').trim();
  const password = String(req.body.password || '');

  try {
    const account = await loginService({ schoolCode, identifier, password });

    await new Promise((resolve, reject) => req.session.regenerate((err) => (err ? reject(err) : resolve())));
    req.session.csrfToken = crypto.randomBytes(24).toString('hex');
    req.session.account = {
      id: account._id,
      role: account.role,
      email: account.email,
      username: account.username || account.email,
      school: account.school,
      student: account.student || null,
      teacher: account.teacher || null,
      parent: account.parent || null,
      scopePhase: account.scopePhase || null,
      mustChangePassword: account.mustChangePassword,
      useCustomPermissions: !!account.useCustomPermissions,
      permissions: getEffectivePermissions(account),
      rawPermissions: Array.isArray(account.permissions) ? account.permissions : [],
    };

    if (account.role === 'student') {
      try {
        const student = await resolveStudentIdentity({ schoolId: account.school, sessionAccount: req.session.account });
        req.session.account.student = student._id;
        if (String(student.phase || '') === 'Primary' || String(student.portalAccess || '') === 'parent_only') {
          await recordAudit({
            school: account.school || null,
            actorAccount: account._id,
            actorRole: account.role,
            action: 'AUTH_PRIMARY_STUDENT_LOGIN_BLOCKED',
            category: 'auth',
            targetType: 'Account',
            targetId: account._id,
            message: 'Primary pupil login was blocked and redirected to parent portal.',
            metadata: { schoolCode: schoolCode || null },
            ipAddress: req.ip,
            userAgent: req.get('user-agent') || '',
          });
          await new Promise((resolve) => req.session.destroy(() => resolve()));
          res.clearCookie('connect.sid');
          return res.status(403).render('auth/login', {
            title: 'Login',
            error: 'Primary pupils use the parent portal. Please log in with the parent account for this child.',
            form: { schoolCode, identifier },
          });
        }
      } catch (linkErr) {
        // keep login working; student pages will show a proper error if the link truly does not exist
      }
    }

    if (!['owner', 'parent'].includes(account.role) && !account.scopePhase) {
      throw new Error('Account phase not configured');
    }

    await recordAudit({
      school: account.school || null,
      actorAccount: account._id,
      actorRole: account.role,
      action: 'AUTH_LOGIN_SUCCESS',
      category: 'auth',
      targetType: 'Account',
      targetId: account._id,
      message: 'User logged in successfully.',
      metadata: { schoolCode: schoolCode || null },
      ipAddress: req.ip,
      userAgent: req.get('user-agent') || '',
    });

    await saveSession(req);

    if (account.mustChangePassword) {
      return res.redirect('/auth/change-password');
    }

    return res.redirect(getRoleHomePath(account.role));
  } catch (err) {
    await recordAudit({
      school: null,
      actorAccount: null,
      actorRole: 'anonymous',
      action: 'AUTH_LOGIN_FAILED',
      category: 'auth',
      targetType: 'Account',
      message: 'Failed login attempt.',
      metadata: { schoolCode: schoolCode || null, identifier },
      ipAddress: req.ip,
      userAgent: req.get('user-agent') || '',
    });

    if (err.statusCode === 401 || err.statusCode === 400) {
      return res.status(err.statusCode).render('auth/login', {
        title: 'Login',
        error: err.statusCode === 400 ? err.message : 'Invalid school code, username/email, or password',
        form: { schoolCode, identifier },
      });
    }

    throw err;
  }
});

exports.logout = asyncHandler(async (req, res) => {
  const account = req.session?.account || null;
  if (account?.id) {
    await recordAudit({
      school: account.school || null,
      actorAccount: account.id,
      actorRole: account.role,
      action: 'AUTH_LOGOUT',
      category: 'auth',
      targetType: 'Account',
      targetId: account.id,
      message: 'User logged out.',
      ipAddress: req.ip,
      userAgent: req.get('user-agent') || '',
    });
  }

  await new Promise((resolve) => req.session.destroy(() => resolve()));
  res.clearCookie('connect.sid');
  return res.redirect('/auth/login');
});

exports.showChangePassword = (req, res) => {
  if (!req.session?.account) {
    return res.redirect('/auth/login');
  }

  return res.render('auth/change-password', {
    title: 'Change Password',
    user: req.session.account,
    error: null,
  });
};

exports.changePassword = asyncHandler(async (req, res) => {
  if (!req.session?.account?.id) {
    return res.redirect('/auth/login');
  }

  const accountId = req.session.account.id;
  const { password, confirmPassword } = req.body;

  if (!password || password.length < 8) {
    return res.status(400).render('auth/change-password', {
      title: 'Change Password',
      user: req.session.account,
      error: 'Password must be at least 8 characters',
    });
  }

  if (confirmPassword != null && String(password) !== String(confirmPassword)) {
    return res.status(400).render('auth/change-password', {
      title: 'Change Password',
      user: req.session.account,
      error: 'Password and confirm password do not match',
    });
  }

  const passwordHash = await bcrypt.hash(password, 10);

  await Account.findByIdAndUpdate(accountId, {
    passwordHash,
    mustChangePassword: false,
  });

  req.session.account.mustChangePassword = false;

  await recordAudit({
    school: req.session.account.school || null,
    actorAccount: accountId,
    actorRole: req.session.account.role,
    action: 'AUTH_PASSWORD_CHANGED',
    category: 'auth',
    targetType: 'Account',
    targetId: accountId,
    message: 'User changed password.',
    ipAddress: req.ip,
    userAgent: req.get('user-agent') || '',
  });

  await saveSession(req);

  return res.redirect(getRoleHomePath(req.session.account.role));
});
