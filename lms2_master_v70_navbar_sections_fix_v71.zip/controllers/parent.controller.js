const asyncHandler = require('../middlewares/asyncHandler');
const parentService = require('../services/parents/parent.service');
const { streamResultPdf } = require('../services/results/pdf.service');

exports.viewDashboard = asyncHandler(async (req, res) => {
  const data = await parentService.getDashboardData({
    schoolId: req.schoolId,
    parentId: req.session.account.parent,
    currentAcademicYear: req.session.currentAcademicYear,
    currentTerm: req.session.currentTerm,
  });

  res.render('parents/dashboard', {
    title: 'Parent Dashboard',
    user: req.session.account,
    ...data,
  });
});

exports.listChildren = asyncHandler(async (req, res) => {
  const data = await parentService.getDashboardData({
    schoolId: req.schoolId,
    parentId: req.session.account.parent,
    currentAcademicYear: req.session.currentAcademicYear,
    currentTerm: req.session.currentTerm,
  });

  res.render('parents/children', {
    title: 'My Children',
    user: req.session.account,
    ...data,
  });
});

exports.viewChildResult = asyncHandler(async (req, res) => {
  const data = await parentService.getChildResultData({
    schoolId: req.schoolId,
    parentId: req.session.account.parent,
    studentId: req.params.studentId,
    academicYear: req.session.currentAcademicYear,
    term: req.session.currentTerm,
  });

  res.render('parents/result', {
    title: `${data.child.name} Result`,
    user: req.session.account,
    ...data,
  });
});

exports.viewChildProfile = asyncHandler(async (req, res) => {
  const data = await parentService.getChildProfileData({
    schoolId: req.schoolId,
    parentId: req.session.account.parent,
    studentId: req.params.studentId,
  });

  res.render('parents/profile', {
    title: `${data.child.name} Profile`,
    user: req.session.account,
    ...data,
  });
});


exports.downloadChildCurrentResultPdf = asyncHandler(async (req, res) => {
  const data = await parentService.getChildResultData({
    schoolId: req.schoolId,
    parentId: req.session.account.parent,
    studentId: req.params.studentId,
    academicYear: req.session.currentAcademicYear,
    term: req.session.currentTerm,
  });

  streamResultPdf(res, {
    title: `${data.child.name} Result PDF`,
    snapshots: data.snapshot ? [data.snapshot] : [],
    downloadName: `${data.child.name || 'child'}_current_result`,
  });
});

exports.downloadChildResultHistoryPdf = asyncHandler(async (req, res) => {
  const data = await parentService.getChildProfileData({
    schoolId: req.schoolId,
    parentId: req.session.account.parent,
    studentId: req.params.studentId,
  });

  streamResultPdf(res, {
    title: `${data.child.name} Result History PDF`,
    snapshots: data.resultSnapshots || [],
    downloadName: `${data.child.name || 'child'}_published_results`,
  });
});
