const asyncHandler = require('../middlewares/asyncHandler');
const registerSchoolService = require('../services/school/registerSchool.service');

exports.showRegisterForm = (req, res) => {
  res.render('schools/register', { title: 'Register School' });
};

exports.registerSchool = asyncHandler(async (req, res) => {
  await registerSchoolService(req.body);

  res.render('schools/register', {
    title: 'Register School',
    success: 'School created successfully ✅',
  });
});