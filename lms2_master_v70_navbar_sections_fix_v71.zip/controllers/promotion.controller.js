const { recordAudit } = require('../services/security/audit.service');
const asyncHandler = require('../middlewares/asyncHandler');
const promotionService = require('../services/promotion/promotion.service');
const PromotionHistory = require('../models/PromotionHistory');


function normalizeSelectionArray(value) {
  if (!value) return [];
  return Array.isArray(value) ? value.filter(Boolean) : [value].filter(Boolean);
}

function extractPromotionSelection(body = {}) {
  const promoteIds = [];
  const repeatIds = [];
  const withdrawIds = [];
  const graduateIds = [];
  const completeIds = [];
  const trackByStudentId = {};
  const noteByStudentId = {};

  Object.keys(body || {}).forEach((k) => {
    if (k.startsWith('decision_')) {
      const sid = k.replace('decision_', '').trim();
      const decision = String(body[k] || '').trim().toUpperCase();
      if (decision === 'PROMOTE') promoteIds.push(sid);
      if (decision === 'REPEAT') repeatIds.push(sid);
      if (decision === 'WITHDRAW') withdrawIds.push(sid);
      if (decision === 'GRADUATE') graduateIds.push(sid);
      if (decision === 'COMPLETE_PRIMARY') completeIds.push(sid);
    }
    if (k.startsWith('track_')) {
      const sid = k.replace('track_', '').trim();
      trackByStudentId[sid] = body[k];
    }
    if (k.startsWith('note_')) {
      const sid = k.replace('note_', '').trim();
      noteByStudentId[sid] = String(body[k] || '').trim();
    }
  });

  if (!promoteIds.length && !repeatIds.length && !withdrawIds.length && !graduateIds.length && !completeIds.length && body.studentIds) {
    normalizeSelectionArray(body.studentIds).forEach((sid) => promoteIds.push(sid));
  }

  return { promoteIds, repeatIds, withdrawIds, graduateIds, completeIds, trackByStudentId, noteByStudentId };
}

// GET /promotion/class/:classId
exports.showClassPromotionPage = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const { classId } = req.params;
  const academicYear = req.session?.currentAcademicYear;
  const term = req.session?.currentTerm;

  const data = await promotionService.getPromotionPageData({
    schoolId,
    classId,
    status: 'Active',
    academicYear,
  });
  const targetAcademicYears = await promotionService.listPromotionTargetAcademicYears({
    schoolId,
    currentAcademicYearName: academicYear,
  });

  const recentHistory = await PromotionHistory.find({
    school: schoolId,
    fromClass: classId,
    academicYearFrom: academicYear,
  })
    .populate('student', 'name')
    .populate('toClass', 'name')
    .populate('performedBy', 'fullName username email role')
    .sort({ createdAt: -1 })
    .limit(30)
    .lean();

  return res.render('promotion/class', {
    title: `Promotion - ${data.currentClass.name}`,
    currentClass: data.currentClass,
    outcome: data.outcome,
    students: data.students,
    sections: data.sections,
    annualRows: data.annualRows,
    terms: data.terms,
    academicYear,
    term,
    recentHistory,
    targetAcademicYears,
    selectedTargetAcademicYearId: req.query?.targetAcademicYearId || '',
  });
});


// POST /promotion/class/:classId/preview
exports.previewClassPromotion = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const { classId } = req.params;
  const academicYear = req.session?.currentAcademicYear;
  const term = req.session?.currentTerm;

  const { promoteIds, repeatIds, withdrawIds, graduateIds, completeIds, trackByStudentId, noteByStudentId } = extractPromotionSelection(req.body || {});

  const data = await promotionService.getPromotionPageData({
    schoolId,
    classId,
    status: 'Active',
    academicYear,
  });
  const targetAcademicYears = await promotionService.listPromotionTargetAcademicYears({
    schoolId,
    currentAcademicYearName: academicYear,
  });

  const selectedTargetAcademicYearId = req.body.targetAcademicYearId || '';
  const targetAcademicYear = (targetAcademicYears || []).find((year) => String(year._id) === String(selectedTargetAcademicYearId || '')) || null;

  const selectedIds = Array.from(new Set([...(promoteIds || []), ...(repeatIds || []), ...(withdrawIds || []), ...(graduateIds || []), ...(completeIds || [])].map(String)));
  const annualMap = new Map((data.annualRows || []).map((row) => [String(row.student._id), row]));
  const selectedStudents = (data.students || [])
    .filter((student) => selectedIds.includes(String(student._id)))
    .map((student) => {
      const annual = annualMap.get(String(student._id)) || student.annual || null;
      const sid = String(student._id);
      const decision = promoteIds.map(String).includes(sid)
        ? 'PROMOTE'
        : repeatIds.map(String).includes(sid)
        ? 'REPEAT'
        : withdrawIds.map(String).includes(sid)
        ? 'WITHDRAW'
        : graduateIds.map(String).includes(sid)
        ? 'GRADUATE'
        : 'COMPLETE_PRIMARY';
      const selectedTrack = trackByStudentId[sid] || '';
      return {
        ...student,
        annual,
        decision,
        selectedTrack,
        note: noteByStudentId[sid] || '',
        hasMissingTerms: !!(annual && Array.isArray(annual.missingTerms) && annual.missingTerms.length),
      };
    });

  const warnings = [];
  if (!selectedStudents.length) warnings.push('No students were selected.');
  if (term !== 'Third Term') warnings.push('Movement can only be executed in Third Term.');
  const needsTargetSession = selectedStudents.some((student) => ['PROMOTE', 'REPEAT'].includes(student.decision));
  if (needsTargetSession && !selectedTargetAcademicYearId) warnings.push('Select a target academic session before final confirmation.');
  const missingTermCount = selectedStudents.filter((student) => student.hasMissingTerms).length;
  if (missingTermCount) warnings.push(`${missingTermCount} selected student(s) have one or more missing term averages.`);
  if (data.outcome?.requiresTrack) {
    const missingTracks = selectedStudents.filter((student) => student.decision === 'PROMOTE' && !student.selectedTrack);
    if (missingTracks.length) warnings.push('Some promoted students still need an SSS track selection.');
  }

  const summary = {
    selectedCount: selectedStudents.length,
    promoteCount: selectedStudents.filter((student) => student.decision === 'PROMOTE').length,
    repeatCount: selectedStudents.filter((student) => student.decision === 'REPEAT').length,
    withdrawCount: selectedStudents.filter((student) => student.decision === 'WITHDRAW').length,
    graduateCount: selectedStudents.filter((student) => ['GRADUATE', 'COMPLETE_PRIMARY'].includes(student.decision)).length,
    missingTermCount,
    canExecute: selectedStudents.length > 0 && term === 'Third Term' && (!needsTargetSession || !!selectedTargetAcademicYearId),
  };

  return res.render('promotion/confirm', {
    title: `Confirm Promotion - ${data.currentClass.name}`,
    currentClass: data.currentClass,
    outcome: data.outcome,
    academicYear,
    term,
    targetAcademicYear,
    selectedTargetAcademicYearId,
    activateTargetSession: String(req.body.activateTargetSession || '').toLowerCase() === 'on',
    selectedStudents,
    summary,
    warnings,
  });
});

// POST /promotion/class/:classId/promote
exports.promoteStudentInClass = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const { classId } = req.params;

  const { promoteIds, repeatIds, withdrawIds, graduateIds, completeIds, trackByStudentId, noteByStudentId } = extractPromotionSelection(req.body || {});

  await promotionService.moveStudentsWithSelection({
    schoolId,
    classId,
    promoteIds,
    repeatIds,
    academicYear: req.session?.currentAcademicYear,
    term: req.session?.currentTerm,
    actorAccountId: req.session?.account?.id,
    trackByStudentId,
    noteByStudentId,
    targetAcademicYearId: req.body.targetAcademicYearId || null,
    activateTargetSession: String(req.body.activateTargetSession || '').toLowerCase() === 'on',
  });

  await recordAudit({
    school: schoolId,
    actorAccount: req.session?.account?.id || null,
    actorRole: req.session?.account?.role || '',
    action: 'PROMOTION_EXECUTED',
    category: 'promotion',
    targetType: 'Class',
    targetId: classId,
    message: 'Promotion or movement decisions were executed for a class.',
    metadata: {
      classId,
      academicYear: req.session?.currentAcademicYear || null,
      term: req.session?.currentTerm || null,
      promoteCount: promoteIds.length,
      repeatCount: repeatIds.length,
      withdrawCount: withdrawIds.length,
      graduateCount: graduateIds.length + completeIds.length,
      targetAcademicYearId: req.body.targetAcademicYearId || null,
    },
    ipAddress: req.ip,
    userAgent: req.get('user-agent') || '',
  });

  const params = new URLSearchParams();
  if (req.body.targetAcademicYearId) params.set('targetAcademicYearId', req.body.targetAcademicYearId);
  if (String(req.body.activateTargetSession || '').toLowerCase() === 'on') params.set('activated', '1');
  params.set('moved', '1');
  const q = params.toString() ? `?${params.toString()}` : '';
  return res.redirect(`/promotion/class/${classId}${q}`);
});

// POST /promotion/class/:classId/section
exports.createSectionForClass = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const { classId } = req.params;
  const { name } = req.body;

  await promotionService.createSectionForClass({
    schoolId,
    classId,
    name,
  });

  return res.redirect(`/promotion/class/${classId}`);
});

// POST /promotion/class/:classId/assign-section
exports.assignSectionToStudents = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const { classId } = req.params;

  const { studentId, sectionId } = req.body;

  await promotionService.assignSectionToStudent({
    schoolId,
    studentId,
    sectionId,
  });

  return res.redirect(`/promotion/class/${classId}`);
});
