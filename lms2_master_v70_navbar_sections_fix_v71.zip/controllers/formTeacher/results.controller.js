const asyncHandler = require('../../middlewares/asyncHandler');
const notificationService = require('../../services/notifications/notification.service');
const FormTeacherAssignment = require('../../models/FormTeacherAssignment');
const ClassModel = require('../../models/class');

const {
  computeClassTermBroadsheet,
  getClassResultStatus,
  submitClassResults,
} = require('../../services/results');
const TeachingAssignment = require('../../models/TeachingAssignment');
const SubjectResultSubmission = require('../../models/SubjectResultSubmission');
const FormTeacherAttendance = require('../../models/FormTeacherAttendance');

// GET /form-teacher/results
exports.index = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const teacherId = req.session.account?.teacher;
  const academicYear = req.session.currentAcademicYear;
  const term = req.session.currentTerm;

  const assignments = await FormTeacherAssignment.find({
    school: schoolId,
    teacher: teacherId,
    academicYear: String(academicYear).trim(),
  }).populate('class', 'name phase level').populate('section', 'name').lean();

  const out = [];
  for (const a of assignments) {
    const c = a.class;
    const sectionFilter = a.section ? { $or: [{ section: a.section._id }, { section: null }, { section: { $exists: false } }] } : {};
    const [st, assignmentCount, submittedCount, submittedSubjects, allAssignments] = await Promise.all([
      getClassResultStatus({ schoolId, academicYear, term, classId: c._id }),
      TeachingAssignment.countDocuments({ school: schoolId, class: c._id, academicYear: String(academicYear).trim(), ...(a.section ? sectionFilter : {}) }),
      SubjectResultSubmission.countDocuments({ school: schoolId, class: c._id, academicYear: String(academicYear).trim(), term: String(term).trim(), status: 'Submitted', ...(a.section ? sectionFilter : {}) }),
      SubjectResultSubmission.find({ school: schoolId, class: c._id, academicYear: String(academicYear).trim(), term: String(term).trim(), status: 'Submitted', ...(a.section ? sectionFilter : {}) }).populate('subject', 'name code').select('subject').lean(),
      TeachingAssignment.find({ school: schoolId, class: c._id, academicYear: String(academicYear).trim(), ...(a.section ? sectionFilter : {}) }).populate('subject', 'name code').select('subject').lean(),
    ]);
    const submittedIds = new Set(submittedSubjects.map((x) => String(x.subject?._id || '')));
    const pendingSubjects = allAssignments.map((x) => x.subject).filter(Boolean).filter((sub) => !submittedIds.has(String(sub._id)));
    out.push({
      ...c,
      section: a.section || null,
      resultStatus: st?.status || 'Draft',
      assignmentCount,
      submittedCount,
      allSubjectsSubmitted: assignmentCount > 0 && submittedCount >= assignmentCount,
      submittedSubjects: submittedSubjects.map((x) => x.subject).filter(Boolean),
      pendingSubjects,
    });
  }

  res.render('form-teacher/results/index', {
    title: 'Form Teacher Results',
    academicYear,
    term,
    classes: out,
  });
});

// GET /form-teacher/results/class/:classId
exports.classView = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const { classId } = req.params;
  const academicYear = req.session.currentAcademicYear;
  const term = req.session.currentTerm;
  const teacherId = req.session.account?.teacher;

  const ftAssignment = req.formTeacherAssignment;
  const ftSectionId = ftAssignment?.section?._id || ftAssignment?.section || null;
  const sectionFilter = ftSectionId ? { $or: [{ section: ftSectionId }, { section: null }, { section: { $exists: false } }] } : {};

  const data = await computeClassTermBroadsheet({
    schoolId,
    classId,
    academicYear,
    term,
    reqScopePhase: req.scopePhase,
    sectionId: ftSectionId,
    submittedOnly: true,
  });

  const status = await getClassResultStatus({ schoolId, academicYear, term, classId });
  const [assignmentCount, submittedCount, submittedSubjects, attendanceDocs, allAssignments] = await Promise.all([
    TeachingAssignment.countDocuments({ school: schoolId, class: classId, academicYear: String(academicYear).trim(), ...(ftSectionId ? sectionFilter : {}) }),
    SubjectResultSubmission.countDocuments({ school: schoolId, class: classId, academicYear: String(academicYear).trim(), term: String(term).trim(), status: 'Submitted', ...(ftSectionId ? sectionFilter : {}) }),
    SubjectResultSubmission.find({ school: schoolId, class: classId, academicYear: String(academicYear).trim(), term: String(term).trim(), status: 'Submitted', ...(ftSectionId ? sectionFilter : {}) }).populate('subject', 'name code').select('subject').lean(),
    FormTeacherAttendance.find({ school: schoolId, class: classId, academicYear: String(academicYear).trim(), term: String(term).trim(), student: { $in: data.rows.map(r=>r.studentId) } }).select('student attendanceTotal cleanlinessRating latenessCount teacherComment').lean(),
    TeachingAssignment.find({ school: schoolId, class: classId, academicYear: String(academicYear).trim(), ...(ftSectionId ? sectionFilter : {}) }).populate('subject', 'name code').select('subject').lean(),
  ]);
  const attendanceMap = new Map(attendanceDocs.map((doc) => [String(doc.student), doc]));
  data.rows = data.rows.map((row) => {
    const meta = attendanceMap.get(String(row.studentId)) || {};
    return {
      ...row,
      attendanceTotal: Number(meta.attendanceTotal || row.attendanceTotal || 0),
      cleanlinessRating: meta.cleanlinessRating || '',
      latenessCount: Number(meta.latenessCount || 0),
      teacherComment: meta.teacherComment || '',
    };
  });

  const submittedSubjectList = submittedSubjects.map((x) => x.subject).filter(Boolean);
  const submittedIds = new Set(submittedSubjectList.map((s) => String(s._id)));
  const pendingSubjects = allAssignments.map((x) => x.subject).filter(Boolean).filter((sub) => !submittedIds.has(String(sub._id)));

  const cls = data.class;
  const { class: _omit, ...rest } = data;

  res.render('form-teacher/results/class', {
    title: `Review Broadsheet - ${cls.name}${ftAssignment?.section?.name ? ' - ' + ftAssignment.section.name : ''}`,
    ...rest,
    klass: cls,
    formTeacherSection: ftAssignment?.section || null,
    resultStatus: status?.status || 'Draft',
    assignmentCount,
    submittedCount,
    allSubjectsSubmitted: assignmentCount > 0 && submittedCount >= assignmentCount,
    submittedSubjects: submittedSubjectList,
    pendingSubjects,
  });
});

// POST /form-teacher/results/submit/:classId
exports.submit = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const { classId } = req.params;
  const academicYear = req.session.currentAcademicYear;
  const term = req.session.currentTerm;
  const teacherId = req.session.account?.teacher;

  const assignmentCount = await TeachingAssignment.countDocuments({ school: schoolId, class: classId, academicYear: String(academicYear).trim() });
  const submittedCount = await SubjectResultSubmission.countDocuments({ school: schoolId, class: classId, academicYear: String(academicYear).trim(), term: String(term).trim(), status: 'Submitted' });
  if (!(assignmentCount > 0 && submittedCount >= assignmentCount)) {
    const err = new Error('All subject teachers must compute and submit their subject results first.');
    err.statusCode = 400;
    throw err;
  }

  await submitClassResults({ schoolId, academicYear, term, classId, teacherId });
  await notificationService.notifyClassSubmitted({
    schoolId,
    scopePhase: req.session.account?.scopePhase || req.scopePhase || null,
    actorAccountId: req.session.account?.id,
    classId,
  });
  res.redirect('/form-teacher/results');
});


exports.saveAttendance = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const { classId } = req.params;
  const academicYear = req.session.currentAcademicYear;
  const term = req.session.currentTerm;
  const teacherId = req.session.account?.teacher;
  const attendance = req.body.attendance || {};
  const cleanliness = req.body.cleanliness || {};
  const lateness = req.body.lateness || {};
  const comment = req.body.comment || {};

  const studentIds = new Set([...Object.keys(attendance), ...Object.keys(cleanliness), ...Object.keys(lateness), ...Object.keys(comment)]);
  const ops = [];
  for (const studentId of studentIds) {
    const attendanceTotal = Number(attendance[studentId] || 0);
    const latenessCount = Number(lateness[studentId] || 0);
    const cleanlinessRating = ['A','B','C','D'].includes(String(cleanliness[studentId] || '').trim().toUpperCase()) ? String(cleanliness[studentId]).trim().toUpperCase() : '';
    const teacherComment = String(comment[studentId] || '').trim();
    if (!Number.isFinite(attendanceTotal) && !Number.isFinite(latenessCount) && !cleanlinessRating && !teacherComment) continue;
    ops.push({
      updateOne: {
        filter: { school: schoolId, class: classId, student: studentId, academicYear: String(academicYear).trim(), term: String(term).trim() },
        update: { $set: { attendanceTotal: Number.isFinite(attendanceTotal) && attendanceTotal >= 0 ? attendanceTotal : 0, latenessCount: Number.isFinite(latenessCount) && latenessCount >= 0 ? latenessCount : 0, cleanlinessRating, teacherComment, recordedBy: teacherId } },
        upsert: true,
      }
    });
  }
  if (ops.length) await FormTeacherAttendance.bulkWrite(ops, { ordered: false });
  res.redirect(`/form-teacher/results/class/${classId}?attendanceSaved=1`);
});
