const asyncHandler = require('../../middlewares/asyncHandler');
const promotionService = require('../../services/promotion/promotion.service');
const ClassModel = require('../../models/class');

exports.viewClassPerformance = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const { classId } = req.params;
  const academicYear = req.session?.currentAcademicYear;
  const term = req.session?.currentTerm;

  const cls = await ClassModel.findOne({ _id: classId, school: schoolId });
  if (!cls) {
    const err = new Error('Class not found');
    err.statusCode = 404;
    throw err;
  }

  const perf = await promotionService.computeAnnualPerformance({ schoolId, classId, academicYear });
  const targetAcademicYears = await promotionService.listPromotionTargetAcademicYears({
    schoolId,
    currentAcademicYearName: academicYear,
  });

  return res.render('form-teacher/performance', {
    title: `Class Performance - ${cls.name}`,
    user: req.session?.account,
    cls,
    academicYear,
    term,
    terms: perf.terms,
    rows: perf.rows,
    targetAcademicYears,
    selectedTargetAcademicYearId: req.query?.targetAcademicYearId || '',
  });
});

exports.moveStudents = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const { classId } = req.params;

  let { promoteIds, repeatIds } = req.body;
  if (!promoteIds) promoteIds = [];
  if (!repeatIds) repeatIds = [];
  if (!Array.isArray(promoteIds)) promoteIds = [promoteIds];
  if (!Array.isArray(repeatIds)) repeatIds = [repeatIds];

  const trackByStudentId = {};
  Object.keys(req.body || {}).forEach((k) => {
    if (k.startsWith('track_')) {
      const sid = k.replace('track_', '').trim();
      trackByStudentId[sid] = req.body[k];
    }
  });

  await promotionService.moveStudentsWithSelection({
    schoolId,
    classId,
    promoteIds,
    repeatIds,
    academicYear: req.session?.currentAcademicYear,
    term: req.session?.currentTerm,
    actorAccountId: req.session?.account?._id,
    trackByStudentId,
    targetAcademicYearId: req.body.targetAcademicYearId || null,
    activateTargetSession: String(req.body.activateTargetSession || '').toLowerCase() === 'on',
  });

  const params = new URLSearchParams();
  if (req.body.targetAcademicYearId) params.set('targetAcademicYearId', req.body.targetAcademicYearId);
  if (String(req.body.activateTargetSession || '').toLowerCase() === 'on') params.set('activated', '1');
  const q = params.toString() ? `?${params.toString()}` : '';
  res.redirect(`/form-teacher/performance/${classId}${q}`);
});
