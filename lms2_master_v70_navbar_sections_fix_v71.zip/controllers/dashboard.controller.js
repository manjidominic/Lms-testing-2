const asyncHandler = require('../middlewares/asyncHandler');
const dashboardService = require('../services/dashboard/dashboard.service');
const { getSetupWizardData, shouldForceWizard } = require('../services/admin/setupWizard.service');
const notificationService = require('../services/notifications/notification.service');
const calendarService = require('../services/calendar/calendar.service');

// GET /dashboard
exports.viewDashboard = asyncHandler(async (req, res) => {
  
  const schoolId = req.schoolId;
  const role = req.session?.account?.role;

  if (role === 'admin') {
    const setup = await getSetupWizardData({ schoolId, scopePhase: req.scopePhase });
    if (shouldForceWizard(req, setup.setupKey)) {
      return res.redirect('/admin/setup');
    }
  }
  const { studentsCount, activeStudentsCount, graduatedCount, classesCount, teachersCount, subjectsCount, sectionsCount, policyCount, latestStudents, classes, activeYear, activeTerm } =
    await dashboardService.getDashboardData({
      schoolId,
      reqScopePhase: req.scopePhase,
    });

  if (role === 'teacher') return res.redirect('/teacher/dashboard');
  if (role === 'student') return res.redirect('/student/dashboard');
  const [notificationPanel, calendarPanel] = await Promise.all([
    notificationService.getDashboardPanelData({ schoolId, accountId: req.session.account.id, limit: 5 }),
    calendarService.listUpcomingForRole({ schoolId, role: req.session.account.role, limit: 5 }),
  ]);
  res.render('dashboard/index', {
    title: 'Dashboard',
    schoolId,
    user: req.session.account,
    studentsCount,
    activeStudentsCount,
    graduatedCount,
    classesCount,
    teachersCount,
    subjectsCount,
    sectionsCount,
    policyCount,
    latestStudents,
    classes,
    activeYear,
    activeTerm,
    currentAcademicYear: req.session.currentAcademicYear || null,
    currentTerm: req.session.currentTerm || null,
    account: req.session.account,
    notificationPanel,
    calendarPanel,
  });

});