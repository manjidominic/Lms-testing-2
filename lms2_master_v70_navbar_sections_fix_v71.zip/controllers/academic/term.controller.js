const asyncHandler = require('../../middlewares/asyncHandler');
const termService = require('../../services/academic/term.service');
const academicYearService = require('../../services/academicYears/academicYear.service');

exports.listTerms = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;

  // Optional filter by academicYear
  const academicYearId = req.query.academicYearId || '';

  // Terms list
  const terms = await termService.listTerms({ schoolId, academicYearId: academicYearId || null });

  // For dropdown: list all academic years
  const years = await academicYearService.listAcademicYears({ schoolId });

  res.render('terms/index', {
    title: 'Terms',
    user: req.session?.account,
    terms,
    years,
    academicYearId,
  });
});

exports.createTerm = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const { academicYearId, name, makeActive } = req.body;

  await termService.createTerm({
    schoolId,
    academicYearId,
    name,
    makeActive: makeActive === 'on',
  });

  res.redirect('/admin/terms');
});

exports.activateTerm = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const termId = req.params.id;

  await termService.activateTerm({ schoolId, termId });

  res.redirect('/admin/terms');
});

exports.toggleResultOpen = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const termId = req.params.id;

  await termService.toggleResultOpen({ schoolId, termId });

  res.redirect('/admin/terms');
});