const asyncHandler = require('../middlewares/asyncHandler');
const assignmentsService = require('../services/teachers/assignments.service');
exports.viewAssignmentsPage = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const reqScopePhase = req.scopePhase;
  
  const serviceData = await assignmentsService.getAssignmentsPageData({ schoolId, reqScopePhase });

  return res.render('admin/assignments', serviceData);
});

exports.createAssignment = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const reqScopePhase = req.scopePhase;
  const academicYear = req.session.currentAcademicYear;
  const { teacherId } = req.body;
  const subjectIds = Array.isArray(req.body.subjectIds) ? req.body.subjectIds : [req.body.subjectIds].filter(Boolean);
  const classIds = Array.isArray(req.body.classIds) ? req.body.classIds : [req.body.classIds].filter(Boolean);

  await assignmentsService.createAssignment({
    schoolId,
    reqScopePhase,
    academicYear,
    teacherId,
    subjectIds,
    classIds,
  });

  return res.redirect('/admin/assignments');
});

exports.deleteAssignment = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const { id } = req.params;

  await assignmentsService.deleteAssignment({ schoolId, assignmentId: id });

  return res.redirect('/admin/assignments');
});