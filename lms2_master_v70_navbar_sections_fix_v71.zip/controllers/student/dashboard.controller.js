const asyncHandler = require('../../middlewares/asyncHandler');
const studentDashboardService = require('../../services/students/dashboard.service');
const { resolveStudentIdentity } = require('../../services/students/resolveStudentIdentity.service');
const notificationService = require('../../services/notifications/notification.service');
const calendarService = require('../../services/calendar/calendar.service');

exports.viewDashboard = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const student = await resolveStudentIdentity({ schoolId, sessionAccount: req.session.account });
  const studentId = student._id;

  const data = await studentDashboardService.getDashboardData({
    schoolId,
    studentId,
    currentAcademicYear: req.session.currentAcademicYear,
    currentTerm: req.session.currentTerm,
  });

  const [notificationPanel, calendarPanel] = await Promise.all([
    notificationService.getDashboardPanelData({ schoolId, accountId: req.session.account.id, limit: 5 }),
    calendarService.listUpcomingForRole({ schoolId, role: 'student', limit: 5 }),
  ]);

  return res.render('students/dashboard/index', {
    title: 'Student Dashboard',
    user: req.session.account,
    data,
    notificationPanel,
    calendarPanel,
  });
});

exports.viewProfile = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const student = await resolveStudentIdentity({ schoolId, sessionAccount: req.session.account });
  const studentId = student._id;

  const data = await studentDashboardService.getProfileData({
    schoolId,
    studentId,
    currentAcademicYear: req.session.currentAcademicYear,
    currentTerm: req.session.currentTerm,
  });

  return res.render('students/dashboard/profile', {
    title: 'My Profile',
    user: req.session.account,
    ...data,
  });
});

exports.viewSubjects = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const student = await resolveStudentIdentity({ schoolId, sessionAccount: req.session.account });
  const studentId = student._id;

  const data = await studentDashboardService.getProfileData({
    schoolId,
    studentId,
    currentAcademicYear: req.session.currentAcademicYear,
    currentTerm: req.session.currentTerm,
  });

  return res.render('students/dashboard/subjects', {
    title: 'My Subjects',
    user: req.session.account,
    ...data,
  });
});
