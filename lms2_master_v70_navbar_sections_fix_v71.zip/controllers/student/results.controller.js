const asyncHandler = require('../../middlewares/asyncHandler');
const {
  getStudentPublishedResult,
  getStudentPublishedResultHistory,
} = require('../../services/results');
const { resolveStudentIdentity } = require('../../services/students/resolveStudentIdentity.service');
const { streamResultPdf } = require('../../services/results/pdf.service');

function findSnapshotOrThrow(history, snapshotId) {
  const snapshot = (history.snapshots || []).find((item) => String(item._id) === String(snapshotId));
  if (!snapshot) {
    const err = new Error('Published result not found for this student');
    err.statusCode = 404;
    throw err;
  }
  return snapshot;
}

// GET /student/results
exports.viewMyResult = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const student = await resolveStudentIdentity({ schoolId, sessionAccount: req.session.account });
  const studentId = student._id;
  const academicYear = req.session.currentAcademicYear;
  const term = req.session.currentTerm;

  let snapshot = null;
  let pageAcademicYear = academicYear || null;
  let pageTerm = term || null;
  let infoMessage = null;

  try {
    const data = await getStudentPublishedResult({
      schoolId,
      studentId,
      academicYear,
      term,
      studentEmail: student.email || req.session.account?.email || '',
      studentUsername: student.username || req.session.account?.username || '',
    });
    snapshot = data.snapshot;
  } catch (err) {
    if (err.statusCode !== 403 && err.statusCode !== 404) throw err;

    const history = await getStudentPublishedResultHistory({ schoolId, studentId, studentEmail: student.email || req.session.account?.email || '', studentUsername: student.username || req.session.account?.username || '' });
    if (history.snapshots?.length) {
      snapshot = history.snapshots[history.snapshots.length - 1];
      pageAcademicYear = snapshot.academicYear;
      pageTerm = snapshot.term;
      infoMessage = 'Current term result is not published yet. Showing the latest published result instead.';
    } else {
      infoMessage = 'No published result is available yet.';
    }
  }

  res.render('students/results/index', {
    title: 'My Result',
    academicYear: pageAcademicYear,
    term: pageTerm,
    snapshot,
    infoMessage,
  });
});

// GET /student/results/history
exports.viewMyResultHistory = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const student = await resolveStudentIdentity({ schoolId, sessionAccount: req.session.account });
  const studentId = student._id;

  const history = await getStudentPublishedResultHistory({ schoolId, studentId, studentEmail: student.email || req.session.account?.email || '', studentUsername: student.username || req.session.account?.username || '' });

  res.render('students/results/history', {
    title: 'My Result History',
    groups: history.grouped,
    snapshots: history.snapshots,
  });
});

// GET /student/results/print/:snapshotId
exports.printMySingleResult = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const student = await resolveStudentIdentity({ schoolId, sessionAccount: req.session.account });
  const studentId = student._id;
  const { snapshotId } = req.params;

  const history = await getStudentPublishedResultHistory({ schoolId, studentId, studentEmail: student.email || req.session.account?.email || '', studentUsername: student.username || req.session.account?.username || '' });
  const snapshot = findSnapshotOrThrow(history, snapshotId);

  res.render('students/results/print', {
    layout: false,
    title: 'Print Result',
    snapshot,
    mode: 'single',
    snapshots: [snapshot],
    student: snapshot.student || null,
  });
});

// GET /student/results/print-all
exports.printMyAllResults = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const student = await resolveStudentIdentity({ schoolId, sessionAccount: req.session.account });
  const studentId = student._id;

  const history = await getStudentPublishedResultHistory({ schoolId, studentId, studentEmail: student.email || req.session.account?.email || '', studentUsername: student.username || req.session.account?.username || '' });

  res.render('students/results/print', {
    layout: false,
    title: 'Print Result History',
    snapshot: history.snapshots[0] || null,
    mode: 'all',
    snapshots: history.snapshots,
    student: history.snapshots[0]?.student || null,
  });
});


// GET /student/results/pdf/:snapshotId
exports.downloadMySingleResultPdf = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const student = await resolveStudentIdentity({ schoolId, sessionAccount: req.session.account });
  const studentId = student._id;
  const { snapshotId } = req.params;

  const history = await getStudentPublishedResultHistory({ schoolId, studentId, studentEmail: student.email || req.session.account?.email || '', studentUsername: student.username || req.session.account?.username || '' });
  const snapshot = findSnapshotOrThrow(history, snapshotId);

  streamResultPdf(res, {
    title: 'Student Result PDF',
    snapshots: [snapshot],
    downloadName: `${student.name || 'student'}_${snapshot.term || 'term'}_${snapshot.academicYear || 'session'}_result`,
  });
});

// GET /student/results/pdf-all
exports.downloadMyAllResultsPdf = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const student = await resolveStudentIdentity({ schoolId, sessionAccount: req.session.account });
  const studentId = student._id;

  const history = await getStudentPublishedResultHistory({ schoolId, studentId, studentEmail: student.email || req.session.account?.email || '', studentUsername: student.username || req.session.account?.username || '' });

  streamResultPdf(res, {
    title: 'Student Result History PDF',
    snapshots: history.snapshots || [],
    downloadName: `${student.name || 'student'}_published_results`,
  });
});
