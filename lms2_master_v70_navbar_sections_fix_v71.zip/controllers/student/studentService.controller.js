const { getStudentsForTeacher } = require('../services/studentService');

async function listStudents(req, res) {
  const schoolId = req.schoolId;
  const account = req.session.account;
  const academicYear = req.session.currentAcademicYear;

  let students = [];

  if (account.role === 'teacher' || account.role === 'form_teacher') {
    students = await getStudentsForTeacher({
      schoolId,
      account,
      academicYear,
    });
  } else {
    // Admin logic here
  }

  res.render('students/index', { students });
}