const asyncHandler = require('../middlewares/asyncHandler');

const studentsService = require('../services/students/students.service');
const enrollmentService = require('../services/students/enrollment.service');
const { getStudentPublishedResultHistory } = require('../services/results');
const { streamResultPdf } = require('../services/results/pdf.service');
const { getStudentAcademicHistory } = require('../services/students/academicHistory.service');
const AppError = require('../utils/AppError');

exports.showAddForm = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;

  const data = await studentsService.getAddStudentFormData({
    schoolId,
    reqScopePhase: req.scopePhase,
  });

  const classes = Array.isArray(data?.classes) ? data.classes : [];

  res.render('students/add', {
    title: 'Register Student',
    classes,
    formError: null,
    formValues: {},
  });
});

exports.createStudent = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const reqScopePhase = req.scopePhase;

  const { surname, middleName, firstName, name, admissionYear, classId, sectionId, parentName, parentEmail, parentPhone } = req.body;
  const academicYear = req.session.currentAcademicYear;
  if (!academicYear) {
    throw new AppError('Please create or activate an academic session before registering students.', 400, { code: 'ACADEMIC_YEAR_REQUIRED' });
  }

  try {
    const created = await studentsService.registerStudent({
      schoolId,
      reqScopePhase,
      surname,
      middleName,
      firstName,
      name,
      admissionYear,
      classId,
      sectionId,
      academicYear,
      parentName,
      parentEmail,
      parentPhone,
    });

    const student = created.student || created;
    const parentAccess = created.parentAccess || null;
    const query = new URLSearchParams();
    if (parentAccess?.loginIdentifier) query.set('parentLogin', parentAccess.loginIdentifier);
    if (parentAccess?.parentUsername) query.set('parentUsername', parentAccess.parentUsername);
    if (parentAccess?.portalAccess) query.set('portalAccess', parentAccess.portalAccess);
    return res.redirect(`/students/${student._id}${query.toString() ? ('?' + query.toString()) : ''}`);
  } catch (err) {
    if (Number(err.statusCode || err.status) === 400) {
      const data = await studentsService.getAddStudentFormData({ schoolId, reqScopePhase });
      return res.status(400).render('students/add', {
        title: 'Register Student',
        classes: Array.isArray(data?.classes) ? data.classes : [],
        formError: err.userMessage || err.message || 'Please correct the highlighted information and try again.',
        formValues: {
          surname,
          middleName,
          firstName,
          name,
          admissionYear,
          classId,
          sectionId,
          parentName,
          parentEmail,
          parentPhone,
        },
      });
    }
    throw err;
  }
});

exports.getSectionsForClass = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const reqScopePhase = req.scopePhase;
  const { classId } = req.params;

  const sections = await studentsService.getSectionsForClass({
    schoolId,
    reqScopePhase,
    classId,
  });

  res.json({ success: true, sections });
});

exports.listStudents = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const account = req.session.account;
  const academicYear = req.session.currentAcademicYear;

  const status = String(req.query.status || 'active').trim().toLowerCase();

  // 👨‍🏫 TEACHER VIEW (secure, assignment-based)
  if (account.role === 'teacher') {
    const data = await studentsService.getStudentsForTeacher({
      schoolId,
      account,
      academicYear,
      status,
    });

    return res.render('students/index', {
      title: 'My Students',
      classId: null,
      status,
      students: data.students,
      selectedClass: null,
    });
  }

  // 🧑‍💼 ADMIN VIEW
  const classId = req.query.classId || null;

  const data = await studentsService.getStudentsByClass({
    schoolId,
    reqScopePhase: req.scopePhase,
    classId,
    status,
  });

  res.render('students/index', {
    title: 'Students',
    classId,
    status,
    students: data.students,
    selectedClass: data.selectedClass,
  });
});


exports.listGraduatedStudents = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const academicYear = String(req.query.year || 'all').trim();

  const data = await studentsService.getGraduatedStudentsByYear({
    schoolId,
    reqScopePhase: req.scopePhase,
    academicYear,
  });

  res.render('students/graduated', {
    title: 'Graduated Students',
    selectedYear: academicYear,
    years: data.years,
    students: data.students,
  });
});

exports.viewStudentProfile = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const reqScopePhase = req.scopePhase;
  const { id } = req.params;

  const student = await studentsService.getStudentProfile({
    schoolId,
    reqScopePhase,
    studentId: id,
  });

  const history = await getStudentPublishedResultHistory({ schoolId, studentId: id, studentEmail: student.email || '', studentUsername: student.username || '' });
  const academicHistory = await getStudentAcademicHistory({ schoolId, student, resultHistory: history.grouped });

  res.render('students/profile', {
    title: 'Student Profile',
    student,
    resultHistory: history.grouped,
    resultSnapshots: history.snapshots,
    academicArchive: academicHistory.archiveGroups,
    movementHistory: academicHistory.movementHistory,
    currentStanding: academicHistory.currentStanding,
    parentPortalNotice: (req.query.parentLogin || student.parent?.username) ? {
      loginIdentifier: req.query.parentLogin || student.parent?.email || student.parent?.phone || null,
      parentUsername: req.query.parentUsername || student.parent?.username || null,
      portalAccess: req.query.portalAccess || student.portalAccess || null,
    } : null,
  });
});

exports.updateStudentStatus = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const { id } = req.params;
  const { status } = req.body;

  await studentsService.updateStudentStatus({
    schoolId,
    reqScopePhase: req.scopePhase,
    studentId: id,
    status,
    currentAcademicYear: req.session.currentAcademicYear,
  });

  return res.redirect(`/students/${id}`);
});

// Legacy per-student enrollment page is replaced by class-level elective enrollment.
exports.showEnrollmentPage = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const student = await studentsService.getStudentProfile({
    schoolId,
    reqScopePhase: req.scopePhase,
    studentId: req.params.id,
  });

  res.redirect(`/students?classId=${student.class?._id || student.class}`);
});

exports.saveEnrollment = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const student = await studentsService.getStudentProfile({
    schoolId,
    reqScopePhase: req.scopePhase,
    studentId: req.params.id,
  });

  res.redirect(`/students?classId=${student.class?._id || student.class}`);
});

// ✅ Bulk enroll electives for a whole class (Admin/Owner)
exports.showBulkEnrollElectives = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const reqScopePhase = req.scopePhase; // null for owner
  const { classId } = req.params;
  const sessionName = req.session?.currentAcademicYear;

  if (!sessionName) {
    const err = new Error('No active academic year set. Please set an active academic year first.');
    err.statusCode = 400;
    throw err;
  }

  const data = await enrollmentService.getBulkEnrollElectivesPageData({
    schoolId,
    reqScopePhase,
    classId,
    session: sessionName,
  });

  res.render('students/bulk-enroll-electives', {
    title: 'Bulk Enroll Electives',
    user: req.session?.account,
    ...data,
  });
});

exports.bulkEnrollElectives = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const reqScopePhase = req.scopePhase; // null for owner
  const { classId } = req.params;
  const sessionName = req.session?.currentAcademicYear;

  if (!sessionName) {
    const err = new Error('No active academic year set. Please set an active academic year first.');
    err.statusCode = 400;
    throw err;
  }

  const raw = req.body?.electiveSubjectIds;
  const electiveSubjectIds = Array.isArray(raw) ? raw : raw ? [raw] : [];

  await enrollmentService.bulkEnrollClassElectives({
    schoolId,
    reqScopePhase,
    classId,
    session: sessionName,
    electiveSubjectIds,
  });

  res.redirect(`/students?classId=${classId}`);
});

exports.printStudentResultHistory = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const reqScopePhase = req.scopePhase;
  const { id } = req.params;

  const student = await studentsService.getStudentProfile({
    schoolId,
    reqScopePhase,
    studentId: id,
  });

  const history = await getStudentPublishedResultHistory({ schoolId, studentId: id, studentEmail: student.email || '', studentUsername: student.username || '' });

  res.render('students/results/print', {
    layout: false,
    title: 'Print Student Results',
    mode: 'all',
    snapshot: history.snapshots[0] || null,
    snapshots: history.snapshots,
    student,
  });
});

exports.printStudentSingleResult = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const reqScopePhase = req.scopePhase;
  const { id, snapshotId } = req.params;

  const student = await studentsService.getStudentProfile({
    schoolId,
    reqScopePhase,
    studentId: id,
  });

  const history = await getStudentPublishedResultHistory({ schoolId, studentId: id, studentEmail: student.email || '', studentUsername: student.username || '' });
  const snapshot = (history.snapshots || []).find((item) => String(item._id) === String(snapshotId));

  if (!snapshot) {
    const err = new Error('Published result not found for this student');
    err.statusCode = 404;
    throw err;
  }

  res.render('students/results/print', {
    layout: false,
    title: 'Print Student Result',
    mode: 'single',
    snapshot,
    snapshots: [snapshot],
    student,
  });
});


exports.downloadStudentResultHistoryPdf = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const reqScopePhase = req.scopePhase;
  const { id } = req.params;

  const student = await studentsService.getStudentProfile({ schoolId, reqScopePhase, studentId: id });
  const history = await getStudentPublishedResultHistory({ schoolId, studentId: id, studentEmail: student.email || '', studentUsername: student.username || '' });

  streamResultPdf(res, {
    title: 'Student Result History PDF',
    snapshots: history.snapshots || [],
    downloadName: `${student.name || 'student'}_published_results`,
  });
});

exports.downloadStudentSingleResultPdf = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const reqScopePhase = req.scopePhase;
  const { id, snapshotId } = req.params;

  const student = await studentsService.getStudentProfile({ schoolId, reqScopePhase, studentId: id });
  const history = await getStudentPublishedResultHistory({ schoolId, studentId: id, studentEmail: student.email || '', studentUsername: student.username || '' });
  const snapshot = (history.snapshots || []).find((item) => String(item._id) === String(snapshotId));
  if (!snapshot) {
    const err = new Error('Published result not found for this student');
    err.statusCode = 404;
    throw err;
  }

  streamResultPdf(res, {
    title: 'Student Result PDF',
    snapshots: [snapshot],
    downloadName: `${student.name || 'student'}_${snapshot.term || 'term'}_${snapshot.academicYear || 'session'}_result`,
  });
});
