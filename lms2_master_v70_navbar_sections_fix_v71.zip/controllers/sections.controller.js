const asyncHandler = require('../middlewares/asyncHandler');
const sectionsService = require('../services/sections/sections.service');

exports.listClassesPage = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const data = await sectionsService.listClassesForSections({ schoolId, scopePhase: req.scopePhase || null });

  res.render('sections/index', {
    title: 'Classes & Sections',
    ...data,
  });
});

exports.manageSectionsPage = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;          // from attachSchool middleware
  const { classId } = req.params;         // from URL /class/:classId

  const data = await sectionsService.getManageSectionsData({ schoolId, classId });

  res.render('sections/manage', {
    title: `Manage Sections - ${data.classObj.name}`,
    classObj: data.classObj,
    sections: data.sections,
  });
});

exports.createSection = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const { classId } = req.params;
  const { name } = req.body;

  await sectionsService.createSection({ schoolId, classId, name });

  res.redirect(`/sections/class/${classId}`);
});

exports.deleteSection = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const { sectionId } = req.params;

  const classId = await sectionsService.deleteSection({ schoolId, sectionId });

  res.redirect(`/sections/class/${classId}`);
});
exports.saveSchoolClassSetup = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  await sectionsService.saveSchoolClassSetup({ schoolId, primaryClasses: req.body.primaryClasses });
  res.redirect('/sections');
});
