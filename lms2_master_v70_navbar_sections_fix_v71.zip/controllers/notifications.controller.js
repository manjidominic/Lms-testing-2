const { recordAudit } = require('../services/security/audit.service');
const asyncHandler = require('../middlewares/asyncHandler');
const notificationService = require('../services/notifications/notification.service');

exports.index = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const accountId = req.session.account?.id;
  const role = req.session.account?.role;
  const [notifications, notificationPreferences] = await Promise.all([
    notificationService.listForAccount({ schoolId, accountId, limit: 50 }),
    notificationService.getPreferencesForAccount({ schoolId, accountId }),
  ]);
  const unreadCount = notifications.filter((item) => !item.isRead).length;
  const historyFilters = {
    audience: String(req.query.audience || '').trim(),
    q: String(req.query.q || '').trim(),
    startDate: String(req.query.startDate || '').trim(),
    endDate: String(req.query.endDate || '').trim(),
  };
  const sentAnnouncements = ['admin', 'staff'].includes(role)
    ? await notificationService.listSentAnnouncements({ schoolId, ...historyFilters, limit: 50 })
    : [];

  return res.render('notifications/index', {
    title: 'Notifications',
    notifications,
    unreadCount,
    announcementError: '',
    announcementSuccess: req.query.announcement === 'sent' ? `Announcement sent to ${Number(req.query.count) || 0} recipient(s).` : '',
    announcementDraft: { audience: 'all_school', title: '', message: '', link: '/notifications' },
    sentAnnouncements,
    historyFilters,
    notificationPreferences,
    preferencesSuccess: req.query.preferences === 'saved' ? 'Notification preferences updated.' : '',
  });
});

exports.markRead = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const accountId = req.session.account?.id;
  const notificationId = req.params.id;
  const updated = await notificationService.markOneRead({ schoolId, accountId, notificationId });
  const nextUrl = String(req.body.next || updated?.link || '/notifications').trim() || '/notifications';
  return res.redirect(nextUrl);
});

exports.markAllRead = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const accountId = req.session.account?.id;
  await notificationService.markAllRead({ schoolId, accountId });
  return res.redirect('/notifications');
});

exports.updatePreferences = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const accountId = req.session.account?.id;
  await notificationService.updatePreferencesForAccount({
    schoolId,
    accountId,
    preferences: {
      workflow: req.body.workflow === 'on',
      publication: req.body.publication === 'on',
      announcement: req.body.announcement === 'on',
      promotion: req.body.promotion === 'on',
      general: req.body.general === 'on',
    },
  });
  return res.redirect('/notifications?preferences=saved');
});

exports.createAnnouncement = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const actorAccountId = req.session.account?.id;
  const role = req.session.account?.role;
  if (!['admin', 'staff'].includes(role)) {
    return res.status(403).render('error', {
      title: 'Forbidden',
      status: 403,
      message: 'Only school administration can send announcements.',
    });
  }

  const audience = String(req.body.audience || 'all_school').trim();
  const title = String(req.body.title || '').trim();
  const message = String(req.body.message || '').trim();
  const link = String(req.body.link || '/notifications').trim() || '/notifications';

  if (!title || !message) {
    const [notifications, notificationPreferences, sentAnnouncements] = await Promise.all([
      notificationService.listForAccount({ schoolId, accountId: actorAccountId, limit: 50 }),
      notificationService.getPreferencesForAccount({ schoolId, accountId: actorAccountId }),
      notificationService.listSentAnnouncements({ schoolId, limit: 50 }),
    ]);
    const unreadCount = notifications.filter((item) => !item.isRead).length;
    return res.status(422).render('notifications/index', {
      title: 'Notifications',
      notifications,
      unreadCount,
      announcementError: 'Title and message are required for a school announcement.',
      announcementSuccess: '',
      announcementDraft: { audience, title, message, link },
      sentAnnouncements,
      historyFilters: { audience: '', q: '', startDate: '', endDate: '' },
      notificationPreferences,
      preferencesSuccess: '',
    });
  }

  const sentCount = await notificationService.createManualAnnouncement({
    schoolId,
    actorAccountId,
    audience,
    scopePhase: req.scopePhase || null,
    title,
    message,
    link,
  });

  await recordAudit({
    school: schoolId,
    actorAccount: actorAccountId || null,
    actorRole: role || '',
    action: 'ANNOUNCEMENT_SENT',
    category: 'notifications',
    targetType: 'Announcement',
    message: 'A manual school announcement was sent.',
    metadata: { audience, title, sentCount: sentCount || 0, link },
    ipAddress: req.ip,
    userAgent: req.get('user-agent') || '',
  });

  return res.redirect(`/notifications?announcement=sent&count=${encodeURIComponent(String(sentCount || 0))}`);
});
