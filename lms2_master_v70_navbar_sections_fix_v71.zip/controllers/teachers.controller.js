const asyncHandler = require('../middlewares/asyncHandler');
const teacherService = require('../services/teachers/teacher.service');




exports.listTeachers = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const status = req.query.status || 'Active';
  const teachers = await teacherService.listTeachers({schoolId, status, reqScopePhase: req.scopePhase, academicYear: req.session?.currentAcademicYear || null});
  
  res.render('teachers/index', {
    title: 'Teachers', 
    user: req.session?.account,
    teachers, 
    schoolId, status
  });
});


exports.showAddForm = asyncHandler(async (req, res) => {
  res.render('teachers/add', {
    title: 'Add teacher', 
    user: req.session?.account, 
    schoolId: req.schoolId,
  });
});


exports.createTeacher = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const { surname, middleName, firstName, name, startYear, phone } = req.body;

  // req.scopePhase comes from tenant middleware attachScopePhase
  const teacher = await teacherService.createTeacher({
    surname,
    middleName,
    firstName,
    name,
    schoolId,
    startYear,
    phone,
    reqScopePhase: req.scopePhase,
  });

  console.log('Teacher created:', teacher);
  res.redirect('/admin/teachers');
});

exports.viewTeacher = async (req, res) => {
  const schoolId = req.schoolId;
  const { id } = req.params;

  const teacher = await teacherService.getTeacherProfile({
    schoolId, 
    teacherId: id,
    academicYear: req.session?.currentAcademicYear || null,
  });
  res.render('teachers/profile', {
    title: 'teacher profile', 
    user: req.session?.account,
    schoolId,
    teacher, 
  })
}

exports.updateTeacherStatus = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const teacherId = req.params.id;
  const { status } = req.body;

  await teacherService.updateTeacherStatus({
    schoolId,
    reqScopePhase: req.scopePhase,
    teacherId,
    status,
  });

  return res.redirect('/admin/teachers');
});


exports.assignSubjectToTeacher = async (req, res) => res.send('assignSubjectToTeacher');
exports.removeAssignment = async (req, res) => res.send('removeAssignment');


exports.listMySubjects = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const teacherId = req.session.account.teacher;

  const data = await teacherService.getMySubjects({ schoolId, teacherId });

  res.render('teachers/subjects', {
    title: 'My Subjects',
    ...data,
  });
});

exports.viewClassSubject = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const teacherId = req.session.account.teacher;
  const { classId, subjectId } = req.params;

  const data = await teacherService.getClassSubjectPage({ schoolId, teacherId, classId, subjectId });

  res.render('teachers/class_subject', {
    title: 'Class Subject',
    ...data,
  });
});