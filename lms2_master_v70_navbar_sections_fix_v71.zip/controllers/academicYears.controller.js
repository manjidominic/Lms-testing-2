const asyncHandler = require('../middlewares/asyncHandler');
const academicYearService = require('../services/academicYears/academicYear.service');
const Term = require('../models/Term');

// 1) GET /admin/academic-years
exports.listAcademicYears = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;

  const years = await academicYearService.listAcademicYears({ schoolId });
  const yearIds = years.map((y) => y._id);
  const terms = await Term.find({ school: schoolId, academicYear: { $in: yearIds } })
    .sort({ createdAt: 1 })
    .lean();

  const termsByYear = {};
  for (const term of terms) {
    const key = String(term.academicYear);
    if (!termsByYear[key]) termsByYear[key] = [];
    termsByYear[key].push(term);
  }

  res.render('academicYears/index', {
    title: 'Academic Years',
    user: req.session?.account,
    years,
    termsByYear,
  });
});

// 2) POST /admin/academic-years/add
exports.createAcademicYear = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const { name, makeActive } = req.body;

  await academicYearService.createAcademicYear({
    schoolId,
    name,
    makeActive: makeActive === 'on',
  });

  res.redirect('/admin/academic-years');
});

// 3) POST /admin/academic-years/:id/activate
exports.activateAcademicYear = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const { id } = req.params;

  await academicYearService.activateAcademicYear({
    schoolId,
    academicYearId: id,
  });

  res.redirect('/admin/academic-years');
});