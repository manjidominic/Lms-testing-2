const asyncHandler = require('../middlewares/asyncHandler');
const Subject = require('../models/Subject');
const School = require('../models/School');
const subjectsService = require('../services/subjects/subjects.service');
const classOfferingsService = require('../services/subjects/classOfferings.service');



exports.listSubjects = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const status = req.query.status || 'Active';
  const subjects = await subjectsService.listSubjects({ schoolId, status, reqScopePhase: req.scopePhase });
  res.render('subjects/index', {
    title: 'Subjects',
    user: req.session?.account,
    schoolId,
    subjects,
    status,
  });
});

exports.createSubject = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  await subjectsService.createSubject({
    schoolId,
    reqScopePhase: req.scopePhase,
    name: req.body?.name,
    code: req.body?.code,
    level: req.body?.level,
    type: req.body?.type,
    tracks: req.body?.tracks,
    status: req.body?.status,
  });
  res.redirect('/admin/subjects');
});

exports.showAddForm = asyncHandler(async (req, res) => {
    const school = await School.findById(req.schoolId).select('phases name').lean();
    res.render('subjects/add', {
        title: 'Add Subjects',
        user: req.session?.account,
        schoolId: req.schoolId,
        scopePhase: req.scopePhase,
        schoolPhases: Array.isArray(school?.phases) ? school.phases : [],
    });

});

exports.showEditForm =  asyncHandler(async (req, res) => {
    const schoolId = req.schoolId;
    const {id} = req.params;
    const subject = await Subject.findOne({_id: id, school: schoolId});
    if(!subject) {
        const err = new Error('Subject not found'); 
        err.statusCode = 403;
        throw err;
    }
    res.render('subjects/edit', {title:'Edit subject', subject, user: req.session?.account, scopePhase: req.scopePhase, schoolId})
})

exports.updateSubject = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const subjectId = req.params.id;

  await subjectsService.updateSubject({
    schoolId,
    subjectId,
    reqScopePhase: req.scopePhase,
    name: req.body?.name,
    code: req.body?.code,
    level: req.body?.level,
    type: req.body?.type,
    tracks: req.body?.tracks,
    status: req.body?.status,
  });

  res.redirect('/admin/subjects');
});


exports.deleteSubject = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const subjectId = req.params.id;

  await subjectsService.deleteSubject({ schoolId, subjectId });

  res.redirect('/admin/subjects');
});

// ✅ Assign classes that offer a subject
exports.showAssignClasses = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const subjectId = req.params.id;
  const { subject, classes, offeredClassIds } = await classOfferingsService.getSubjectClassOfferings({
    schoolId,
    subjectId,
    reqScopePhase: req.scopePhase,
  });

  res.render('subjects/assign-classes', {
    title: `Assign Classes - ${subject.name}`,
    user: req.session?.account,
    subject,
    classes,
    offeredClassIds,
  });
});


exports.viewSubject = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const subjectId = req.params.id;
  const data = await subjectsService.getSubjectOverview({
    schoolId,
    subjectId,
    sessionName: req.session?.currentAcademicYear || null,
  });

  res.render('subjects/view', {
    title: `Subject Overview - ${data.subject.name}`,
    user: req.session?.account,
    ...data,
  });
});

exports.saveAssignClasses = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const subjectId = req.params.id;
  await classOfferingsService.updateSubjectClassOfferings({
    schoolId,
    subjectId,
    classIds: req.body?.classIds,
    reqScopePhase: req.scopePhase,
  });
  res.redirect('/admin/subjects');
});