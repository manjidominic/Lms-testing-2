const asyncHandler = require('../middlewares/asyncHandler');

const School = require('../models/School');
const Subscription = require('../models/Subscription');
const { addMonths } = require('../utils/subscription.util');

function parsePositiveInt(v, fallback) {
  const n = parseInt(String(v || ''), 10);
  if (!Number.isFinite(n) || n <= 0) return fallback;
  return n;
}

// GET /owner/schools
exports.listSchools = asyncHandler(async (req, res) => {
  const schools = await School.find({}).sort({ createdAt: -1 }).lean();

  // Attach subscription info (and ensure a TRIAL exists for older schools)
  const schoolIds = schools.map((s) => String(s._id));
  const subs = await Subscription.find({ school: { $in: schoolIds } }).lean();
  const bySchool = new Map(subs.map((s) => [String(s.school), s]));

  const now = new Date();
  for (const s of schools) {
    let sub = bySchool.get(String(s._id));

    if (!sub) {
      const base = s.createdAt ? new Date(s.createdAt) : now;
      const trialStart = base;
      const trialEnd = addMonths(base, 4);
      const created = await Subscription.create({
        school: s._id,
        status: 'TRIAL',
        trialStart,
        trialEnd,
      });
      await School.updateOne({ _id: s._id }, { $set: { subscription: created._id } });
      sub = created.toObject();
      bySchool.set(String(s._id), sub);
    }

    s.subscriptionInfo = sub;
  }

  res.render('owner/schools', {
    title: 'All Schools',
    schools,
    activeSchoolId: req.session.activeSchoolId || null,
  });
});

// POST /owner/schools/:schoolId/select
exports.selectSchool = asyncHandler(async (req, res) => {
  const { schoolId } = req.params;

  const school = await School.findById(schoolId);
  if (!school) {
    const err = new Error('School not found');
    err.statusCode = 404;
    throw err;
  }

  req.session.activeSchoolId = String(school._id);
  return res.redirect('/dashboard');
});

// POST /owner/clear-school
exports.clearSchool = asyncHandler(async (req, res) => {
  req.session.activeSchoolId = null;
  return res.redirect('/owner/schools');
});

// POST /owner/schools/:schoolId/renew
// Owner can renew a school's plan for N months or years (manual renewal for now).
exports.renewSchoolSubscription = asyncHandler(async (req, res) => {
  const { schoolId } = req.params;
  const { durationValue, durationUnit } = req.body;

  const school = await School.findById(schoolId).select('_id name subscription createdAt');
  if (!school) {
    const err = new Error('School not found');
    err.statusCode = 404;
    throw err;
  }

  let sub = null;
  if (school.subscription) {
    sub = await Subscription.findById(school.subscription);
  }
  if (!sub) {
    const base = school.createdAt ? new Date(school.createdAt) : new Date();
    sub = await Subscription.create({
      school: school._id,
      status: 'TRIAL',
      trialStart: base,
      trialEnd: addMonths(base, 4),
    });
    school.subscription = sub._id;
    await school.save();
  }

  const value = parsePositiveInt(durationValue, 1);
  const unit = String(durationUnit || 'months').toLowerCase();
  const months = unit === 'years' ? value * 12 : value;

  const now = new Date();
  const currentEnd = sub.currentPeriodEnd ? new Date(sub.currentPeriodEnd) : null;
  const base = currentEnd && currentEnd.getTime() > now.getTime() ? currentEnd : now;

  sub.status = 'ACTIVE';
  sub.currentPeriodStart = now;
  sub.currentPeriodEnd = addMonths(base, months);
  sub.lastRenewedBy = req.session?.account?._id || null;
  sub.lastRenewedAt = now;
  sub.lockedReason = null;
  await sub.save();

  return res.redirect('/owner/schools');
});
