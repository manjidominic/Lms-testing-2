const asyncHandler = require('../../middlewares/asyncHandler');
const teacherDashboardService = require('../../services/teachers/dashboard.service');
const notificationService = require('../../services/notifications/notification.service');
const calendarService = require('../../services/calendar/calendar.service');

exports.viewDashboard = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const teacherId = req.session.account.teacher;
  const currentAcademicYear = req.session.currentAcademicYear || null;
  const currentTerm = req.session.currentTerm || null;

  const data = await teacherDashboardService.getDashboardData({
    schoolId,
    teacherId,
    academicYear: currentAcademicYear,
    term: currentTerm,
  });

  const [notificationPanel, calendarPanel] = await Promise.all([
    notificationService.getDashboardPanelData({ schoolId, accountId: req.session.account.id, limit: 5 }),
    calendarService.listUpcomingForRole({ schoolId, role: req.session.account.role, limit: 5 }),
  ]);

  res.render('teachers/dashboard/index', {
    title: 'Teacher Dashboard',
    user: req.session.account,
    currentAcademicYear,
    currentTerm,
    data,
    notificationPanel,
    calendarPanel,
  });
});

exports.viewClassOverview = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const teacherId = req.session.account.teacher;
  const currentAcademicYear = req.session.currentAcademicYear || null;
  const currentTerm = req.session.currentTerm || null;

  const data = await teacherDashboardService.getClassOverviewData({
    schoolId,
    teacherId,
    classId: req.params.classId,
    academicYear: currentAcademicYear,
    term: currentTerm,
  });

  const [notificationPanel, calendarPanel] = await Promise.all([
    notificationService.getDashboardPanelData({ schoolId, accountId: req.session.account.id, limit: 5 }),
    calendarService.listUpcomingForRole({ schoolId, role: req.session.account.role, limit: 5 }),
  ]);

  res.render('teachers/dashboard/class-overview', {
    title: `${data.classInfo.name} Overview`,
    user: req.session.account,
    currentAcademicYear,
    currentTerm,
    data,
    notificationPanel,
    calendarPanel,
  });
});
