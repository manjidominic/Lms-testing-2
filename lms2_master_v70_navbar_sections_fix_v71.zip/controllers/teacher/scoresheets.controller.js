const asyncHandler = require('../../middlewares/asyncHandler');
const scoresheetsService = require('../../services/teachers/scoresheets.service');
const notificationService = require('../../services/notifications/notification.service');

function renderSetupRequired(res, req, details = {}) {
  return res.status(details.statusCode || 400).render('teachers/scoresheets/setup-required', {
    title: 'Scoresheets Need Setup',
    user: req.session?.account,
    currentAcademicYear: req.session?.currentAcademicYear || null,
    currentTerm: req.session?.currentTerm || null,
    details,
  });
}

exports.list = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const teacherId = req.session.account.teacher;
  const data = await scoresheetsService.listTeacherAssignments({ schoolId, teacherId, academicYear: req.session.currentAcademicYear, term: req.session.currentTerm });
  const isTermLocked = req.termDoc && req.termDoc.isResultOpen === false;
  return res.render('teachers/scoresheets/index', {
    title: 'Scoresheets', user: req.session?.account, currentAcademicYear: req.session?.currentAcademicYear || null, currentTerm: req.session?.currentTerm || null, data, isTermLocked
  });
});

exports.showEntry = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const teacherId = req.session.account.teacher;
  const assignmentId = req.params.assignmentId;
  try {
    const data = await scoresheetsService.getEntryPageData({ schoolId, teacherId, assignmentId });
    const isTermLocked = req.termDoc && req.termDoc.isResultOpen === false;
    return res.render('teachers/scoresheets/entry', {
      title: 'Enter Scores',
      user: req.session?.account,
      currentAcademicYear: req.session?.currentAcademicYear || null,
      currentTerm: req.session?.currentTerm || null,
      data,
      isTermLocked,
    });
  } catch (err) {
    if (err && [400, 403].includes(Number(err.statusCode || err.status))) {
      return renderSetupRequired(res, req, {
        statusCode: Number(err.statusCode || err.status || 400),
        message: err.message || 'This scoresheet cannot open yet.',
        actionPath: '/teacher/scoresheets',
      });
    }
    throw err;
  }
});

exports.saveEntry = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const teacherId = req.session.account.teacher;
  const assignmentId = req.params.assignmentId;

  await scoresheetsService.saveScores({
    schoolId,
    teacherId,
    assignmentId,
    scores: req.body.scores || {},
  });

  return res.redirect(`/teacher/scoresheets/${assignmentId}?saved=1`);
});

exports.computeSubject = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const teacherId = req.session.account?.teacher;
  const { assignmentId } = req.params;
  await scoresheetsService.computeSubjectResult({ schoolId, teacherId, assignmentId });
  return res.redirect(`/teacher/scoresheets/${assignmentId}?computed=1`);
});

exports.submitSubject = asyncHandler(async (req, res) => {
  const schoolId = req.schoolId;
  const teacherId = req.session.account?.teacher;
  const actorAccountId = req.session.account?.id;
  const { assignmentId } = req.params;
  const outcome = await scoresheetsService.submitSubjectResult({ schoolId, teacherId, assignmentId, allowIncomplete: String(req.body.allowIncomplete || '').trim() === '1' });
  if (outcome?.classId && outcome?.subjectId) {
    await notificationService.notifySubjectSubmitted({
      schoolId,
      scopePhase: req.session.account?.scopePhase || req.scopePhase || null,
      actorAccountId,
      classId: outcome.classId,
      subjectId: outcome.subjectId,
    });
  }
  return res.redirect(`/teacher/scoresheets?submitted=1`);
});
